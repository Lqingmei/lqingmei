// ---- plugin:send_exam_notification_feishu_1 ----
// ============================================================
// 插件 send_exam_notification_feishu_1 (考试发布飞书通知发送) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export interface SendExamNotificationFeishuOneInput {
  /** 考试名称（用作消息标题） */
  exam_name: string;
  /** 考试说明（markdown格式，用作消息正文） */
  exam_description: string;
  /** 考试页面链接 */
  exam_page_url: string;
  /** 接收通知的用户ID列表 */
  receiver_user_list: string[];
}

/**
 * capabilityClient.load('send_exam_notification_feishu_1').call<SendExamNotificationFeishuOneOutput>('send_feishu_message', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { success } = result;
 */
export interface SendExamNotificationFeishuOneOutput {
  /** [object Object] */
  success: boolean;
}
// ---- end:send_exam_notification_feishu_1 ----