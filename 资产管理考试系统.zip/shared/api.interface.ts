// ===== 试卷管理 =====

export type QuestionType = 'single' | 'multiple' | 'judge';

export interface Question {
  type: QuestionType;
  title: string;
  options: string[];
  correctAnswer: number | number[];
  score?: number;
  explanation?: string;
}

export interface ExamPaperListItem {
  id: string;
  name: string;
  questionCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface ExamPaperListResponse {
  items: ExamPaperListItem[];
  total: number;
}

export interface ExamPaperDetail {
  id: string;
  name: string;
  questions: Question[];
  questionCount: number;
  passScore: number;
  version: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateExamPaperRequest {
  name: string;
  questions: Question[];
  passScore?: number;
}

export interface UpdateExamPaperRequest {
  name?: string;
  questions?: Question[];
  passScore?: number;
}

export interface DeleteResponse {
  success: boolean;
}

// ===== 考试发布 =====

export interface ExamAssignmentListItem {
  id: string;
  examPaperId: string;
  examPaperName: string;
  questionCount: number;
  assignedUserCount: number;
  publishedVersion: number;
  status: string;
  createdAt: string;
}

export interface ExamAssignmentListResponse {
  items: ExamAssignmentListItem[];
  total: number;
}

export interface CreateExamAssignmentRequest {
  examPaperId: string;
  assignedUsers: string[];
}

// ===== 考试名单 =====

export type RosterStatus = 'pending' | 'resolved' | 'duplicate' | 'not_found';

export interface ExamRosterItem {
  id: string;
  name: string;
  userId?: string;
  status: RosterStatus;
  center: string;
}

export interface ExamRosterListResponse {
  items: ExamRosterItem[];
  total: number;
}

export interface SaveExamRosterRequest {
  items: { name: string; userId?: string; status: RosterStatus; center?: string }[];
}

export interface SaveExamRosterResponse {
  success: boolean;
  inserted: number;
  skipped: number;
}

export interface UpdateExamRosterRequest {
  userId?: string;
  status?: RosterStatus;
  center?: string;
}

export interface AddRosterItemRequest {
  name: string;
  userId: string;
  center?: string;
}

// ===== 奖品配置 =====

export interface Prize {
  id: string;
  name: string;
  quantity: number;
  imageUrl?: string;
}

export interface PrizeListResponse {
  items: Prize[];
  totalCount: number;
  maxCount: number;
}

export interface CreatePrizeRequest {
  name: string;
  quantity: number;
  imageUrl?: string;
}

export interface UpdatePrizeRequest {
  name?: string;
  quantity?: number;
  imageUrl?: string | null;
}

// ===== 答题记录 =====

export interface ExamRecord {
  id: string;
  answers: Record<string, number | number[]>;
  status: string;
  score?: number;
  correctRate?: number;
  isPassed?: boolean;
  hasLottery?: boolean;
}

export interface DraftExamRequest {
  examPaperId: string;
  answers: Record<string, number | number[]>;
}

export interface SubmitExamRequest {
  examPaperId: string;
  answers: Record<string, number | number[]>;
}

export interface SubmitExamResponse {
  examRecordId: string;
  score: number;
  totalScore: number;
  correctRate: number;
  isPassed: boolean;
  hasLottery: boolean;
}

// ===== 抽奖 =====

export interface DrawLotteryRequest {
  examRecordId: string;
}

export interface DrawLotteryResponse {
  success: boolean;
  prizeName: string;
  prizeImage?: string;
}

export interface LotteryConfig {
  winProbability: number;
}

export interface UpdateLotteryConfigRequest {
  winProbability: number;
}

// ===== 数据统计 =====

export interface StatisticsOverview {
  totalParticipants: number;
  averageScore: number;
  passRate: number;
  awardedPrizes: number;
}

export interface ScoreDistributionItem {
  scoreRange: string;
  count: number;
}

export interface ScoreDistributionResponse {
  distribution: ScoreDistributionItem[];
}

export interface StatisticsRecord {
  id: string;
  userName: string;
  center: string;
  score: number;
  isPassed: boolean;
  prizeName?: string;
  createdAt: string;
}

export interface StatisticsRecordsResponse {
  items: StatisticsRecord[];
  total: number;
}

export interface QuestionStatItem {
  index: number;
  title: string;
  type: QuestionType;
  correctCount: number;
  totalAnswers: number;
  correctRate: number;
}

export interface QuestionAnalysisResponse {
  paperId: string;
  paperName: string;
  totalParticipants: number;
  questions: QuestionStatItem[];
}

// ===== 按所属中心分布统计 =====

export interface CenterDinnerStat {
  center: string;
  rosterCount: number;
  participantCount: number;
  passedCount: number;
  winnerCount: number;
  passRate: number;
}

export interface CenterDinnerStatsResponse {
  items: CenterDinnerStat[];
}

// ===== 学员完成情况 =====

export interface AssignmentUserStatus {
  userId: string;
  status: 'completed' | 'not_answered';
  score?: number;
  isPassed?: boolean;
  submittedAt?: string;
  center?: string;
}

export interface AssignmentStatusResponse {
  paperId: string;
  paperName: string;
  totalAssigned: number;
  completedCount: number;
  notAnsweredCount: number;
  completionRate: number;
  items: AssignmentUserStatus[];
}

// ===== 认证状态 =====

export interface AuthMeResponse {
  loggedIn: boolean;
  userId: string | null;
}

// ===== Guest 免登录答题 =====

export interface GuestPapersResponse {
  identified: boolean;
  items: ExamPaperListItem[];
}

export interface GuestRecordResponse {
  identified: boolean;
  record: ExamRecord | null;
}

export interface GuestDraftRequest {
  paperId: string;
  answers: Record<string, number | number[]>;
}

export interface GuestSubmitRequest {
  paperId: string;
  answers: Record<string, number | number[]>;
}

export interface GuestLotteryRequest {
  examRecordId: string;
}

// ===== 通知模版 =====

export interface NotificationTemplate {
  id: string;
  titleTemplate: string;
  descriptionTemplate: string;
}

export interface UpdateNotificationTemplateRequest {
  titleTemplate?: string;
  descriptionTemplate?: string;
}
