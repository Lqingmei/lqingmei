# UI 设计指南

> **设计类型**: App 设计（应用架构设计）
> **确认检查**: 本指南适用于可交互的应用/网站/工具。

> ℹ️ Section 1 为设计意图与决策上下文。Code agent 实现时以 Section 2 及之后的具体参数为准。

## 1. Design Archetype (设计原型)

### 1.1 内容理解

- **目标用户**: 小鹏资产管理部管理员（严肃配置/数据复盘）+ 内部学员（答题/抽奖）；双角色情绪差异大
- **核心目的**: 管理端高效管控试卷与奖品配额、数据驱动决策；学员端沉浸答题并获得即时激励反馈
- **情绪基调**: 宁静、从容、精英感——克制中透露品质

### 1.2 设计方向

- **Design Style**: Serene Luxury — 新亚洲极简奢华 × 大面积留白 × 衬线字体 × 超大圆角卡片
- **Application Type**: SaaS/Admin + 轻量互动页混合 — 管理后台优雅克制，答题页沉浸聚焦
- **Aesthetic Direction**: 白色毛玻璃 Header + 白色大圆角卡片 + slate 色系 + lime-400 点睛 + 柔和阴影

## 2. Color System (色彩系统)

**色彩关系**: slate-50 页面底(#F8FAFC) + 白色卡片 + slate-900 主色(#0F172A) + blue-600 强调(#2563EB) + slate-100 边框(#F1F5F9)
**配色设计理由**: 极简奢华需大面积留白与克制色彩，slate 色系传递沉稳品质感，lime-400 作为点睛色打破沉稳
**使用比例**: 60% 浅灰底 / 30% 白色卡片 / 8% 深色强调 / 2% lime 点睛

### 2.1 主题颜色

| Token                | HSL 值                  | 说明                                         |
| -------------------- | ----------------------- | -------------------------------------------- |
| `background`         | hsl(210, 40%, 98%)      | 页面背景，slate-50                            |
| `card`               | hsl(0, 0%, 100%)        | 卡片/容器纯白                                |
| `foreground`         | hsl(222, 47%, 11%)      | 主文字 slate-900                              |
| `muted-foreground`   | hsl(215, 16%, 47%)      | 次级说明 slate-500                            |
| `primary`            | hsl(222, 47%, 11%)      | slate-900，主按钮/标题/图表主色               |
| `primary-foreground` | hsl(0, 0%, 100%)        | 主按钮文字白                                 |
| `accent`             | hsl(221, 83%, 53%)      | blue-600，交互高亮/hover/标签                 |
| `border`             | hsl(210, 40%, 96%)      | slate-100，卡片边框                           |

### 2.2 导航区配色

- **基调关系**: 透明→滚动后白色毛玻璃 `bg-white/90 backdrop-blur-md shadow-sm`
- **关键状态**: 激活项 `bg-slate-900 text-white rounded-full`；hover `text-blue-600`
- **品牌标识**: serif-font 品牌名 + tracking-widest

### 2.3 语义颜色

| 用途     | 色值                     | 说明                         |
| -------- | ------------------------ | ---------------------------- |
| 成功/通过 | hsl(160, 84%, 39%)      | emerald #10B981              |
| 警告/配额 | hsl(38, 92%, 50%)       | amber #F59E0B               |
| 错误/删除 | hsl(0, 84%, 60%)        | red #EF4444                 |
| 庆祝/点睛 | hsl(84, 81%, 60%)       | lime-400 #A3E635             |

### 2.4 图表配色

| 序号 | HEX | 色名 |
|-----|-----|------|
| 1 | #0F172A | slate-900（主色） |
| 2 | #2563EB | blue-600 |
| 3 | #60A5FA | blue-400 |
| 4 | #BFDBFE | blue-200 |
| 5 | #A3E635 | lime-400 |

## 3. Typography (字体排版)

- **正文字体**: `Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`
- **标题字体**: `'Noto Serif SC', serif` — 通过 `.serif-font` 类名应用
- **等宽数值**: `font-mono`（表格中对齐的数值列）
- **字体策略**: 标题 `serif-font font-light`；标签 `font-bold uppercase tracking-widest text-xs`；正文 `font-light leading-relaxed`

### 文字层级

| 层级 | 样式 | 颜色 |
|-----|-----|------|
| 页面主标题 | `serif-font text-3xl font-light` | foreground |
| Section 标题 | `serif-font text-2xl md:text-3xl` | foreground |
| Section 标签 | `text-xs font-bold uppercase tracking-widest` | accent (blue-600) |
| KPI 数值 | `text-3xl font-bold` | foreground |
| KPI 标签 | `text-xs font-bold uppercase tracking-widest` | muted-foreground |
| 表头 | `text-xs font-bold uppercase tracking-wider` | muted-foreground |
| 表格数据 | `text-sm font-medium` | foreground |
| 正文 | `text-base font-light leading-relaxed` | foreground |

## 4. Layout Strategy (布局策略)

- **导航意图**: 透明→毛玻璃 Header，固定顶部 `sticky top-0 z-50`；移动端折叠
- **页面架构**: 统一 `max-w-7xl` 居中容器，`px-6 md:px-12` 内边距，`py-8` 纵向间距
- **响应式**: 桌面端网格3-4列卡片；平板2列；手机单列堆叠

## 5. Visual Language (视觉语言)

- **形态参数**: 超大圆角 `rounded-3xl`(卡片) / `rounded-[3rem]`(面板) / `rounded-full`(按钮标签) · 柔和阴影 `shadow-sm`→hover `shadow-xl`
- **识别签名**: 白色大圆角卡片 + 柔和阴影 + slate 色系 + serif 标题 + lime-400 点睛
- **卡片样式**: `.report-card` 类 — `background: #FFF; border: 1px solid slate-100; border-radius: 1.5rem`
- **极细边框**: `.thin-border` 类 — `border: 1px solid slate-100`
- **滚动条**: 6px 窄轨，slate-400 滑块
- **Hover**: 卡片 `hover:shadow-xl hover:-translate-y-2 transition-all duration-300`；导航 `hover:text-blue-600`

### 圆角系统

| 场景 | 值 |
|------|-----|
| Pill 按钮/标签 | `rounded-full` |
| 小型卡片/按钮 | `rounded-xl` ~ `rounded-2xl` |
| 标准卡片 | `rounded-3xl` |
| 主要面板/图片容器 | `rounded-[3rem]` ~ `rounded-[3.5rem]` |

### 阴影系统

| 场景 | 值 |
|------|-----|
| 卡片默认 | `shadow-sm` |
| 卡片 hover | `shadow-xl` / `shadow-2xl` |
| 浮动主卡片 | `shadow-[0_40px_80px_-20px_rgba(0,0,0,0.06)]` |
| 超大容器 | `shadow-[0_40px_100px_-20px_rgba(0,0,0,0.08)]` |

## 6. Component Principles (组件原则)

- **Card**: `report-card rounded-3xl shadow-sm border border-slate-100`（白色 + 大圆角 + 柔和阴影）；hover `shadow-xl -translate-y-2`
- **Button (CTA)**: `bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 shadow-xl`
- **Button (Outline)**: `border border-slate-200 rounded-2xl font-bold hover:bg-slate-50`
- **Button (Pill)**: `rounded-full px-6 py-2 border border-slate-800`
- **Badge/Tag**: `rounded-full text-xs font-semibold`，蓝/灰底色
- **Input**: `rounded-xl border-slate-200`，`font-medium`
- **Table**: 圆角行，slate 边框，表头 `text-xs font-bold uppercase`
- **Dialog**: `rounded-3xl shadow-xl`
- **Progress**: `rounded-full`，slate-900 填充

## 7. ECharts 主题

- **配色序列**: `['#0F172A', '#2563EB', '#60A5FA', '#BFDBFE', '#A3E635']`
- **坐标轴**: 无轴线、无刻度，标签 `#94A3B8 9px font-weight:700`
- **网格线**: `#F1F5F9` 实线
- **Tooltip**: 白底 + `#F1F5F9` 边框 + `rounded-xl` + `11px font-weight:700`
- **柱状图**: `barWidth: 30`，`borderRadius: [6,6,0,0]`

## 8. 应避免 (Anti-patterns)

- ❌ 使用零圆角（`rounded-none`），静谧奢雅风格需大圆角
- ❌ 使用深蓝渐变 Header 或蓝色顶边线，应使用白色毛玻璃 Header
- ❌ 使用高饱和撞色，应保持 slate 色系 + blue-600/lime-400 克制点缀
- ❌ 在标题处使用无衬线体，标题应使用 `serif-font`（Noto Serif SC）
- ❌ 使用硬阴影（零模糊偏移），应使用柔和带模糊的阴影
