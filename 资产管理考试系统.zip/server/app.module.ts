import { APP_FILTER } from '@nestjs/core';
import { Module } from '@nestjs/common';
import { PlatformModule } from '@lark-apaas/fullstack-nestjs-core';

import { GlobalExceptionFilter } from './common/filters/exception.filter';
import { ExamPaperModule } from './modules/exam-paper/exam-paper.module';
import { PrizeModule } from './modules/prize/prize.module';
import { ExamRecordModule } from './modules/exam-record/exam-record.module';
import { LotteryModule } from './modules/lottery/lottery.module';
import { StatisticsModule } from './modules/statistics/statistics.module';
import { ExamAssignmentModule } from './modules/exam-assignment/exam-assignment.module';
import { ExamRosterModule } from './modules/exam-roster/exam-roster.module';
import { AuthModule } from './modules/auth/auth.module';
import { ExamGuestModule } from './modules/exam-guest/exam-guest.module';
import { NotificationTemplateModule } from './modules/notification-template/notification-template.module';
import { ViewModule } from './modules/view/view.module';

@Module({
  imports: [
    // 平台 Module，提供平台能力
    PlatformModule.forRoot(),
    // ====== @route-section: business-modules START ======
    ExamPaperModule,
    PrizeModule,
    ExamRecordModule,
    LotteryModule,
    StatisticsModule,
    ExamAssignmentModule,
    ExamRosterModule,
    AuthModule,
    ExamGuestModule,
    NotificationTemplateModule,
    // ====== @route-section: business-modules END ======

    // ⚠️ @route-order: last
    // ViewModule is the fallback route module, must be registered last.
    ViewModule,
  ],
  providers: [
    {
      provide: APP_FILTER,
      useClass: GlobalExceptionFilter,
    },
  ],
})
export class AppModule {}
