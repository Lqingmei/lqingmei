import { Injectable, Logger, ConflictException } from '@nestjs/common';
import { Inject } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, desc, count, sql } from 'drizzle-orm';
import { examPaper, examRecord } from '@server/database/schema';
import type {
  ExamPaperListItem,
  ExamPaperListResponse,
  ExamPaperDetail,
  CreateExamPaperRequest,
  UpdateExamPaperRequest,
  Question,
} from '@shared/api.interface';

@Injectable()
export class ExamPaperService {
  private readonly logger = new Logger(ExamPaperService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async findAll(page: number, pageSize: number): Promise<ExamPaperListResponse> {
    const offset = (page - 1) * pageSize;

    const [totalResult] = await this.db
      .select({ count: count() })
      .from(examPaper);
    const total = Number(totalResult?.count ?? 0);

    const rows = await this.db
      .select({
        id: examPaper.id,
        name: examPaper.name,
        questionCount: examPaper.questionCount,
        createdAt: examPaper.createdAt,
        updatedAt: examPaper.updatedAt,
      })
      .from(examPaper)
      .orderBy(desc(examPaper.updatedAt))
      .limit(pageSize)
      .offset(offset);

    const items: ExamPaperListItem[] = rows.map((row) => ({
      id: row.id,
      name: row.name,
      questionCount: row.questionCount,
      createdAt: this.toISOString(row.createdAt),
      updatedAt: this.toISOString(row.updatedAt),
    }));

    this.logger.log(`findAll: page=${page}, pageSize=${pageSize}, total=${total}, returned=${items.length}`);

    return { items, total };
  }

  async findOne(id: string): Promise<ExamPaperDetail | null> {
    const [row] = await this.db
      .select()
      .from(examPaper)
      .where(eq(examPaper.id, id));

    if (!row) {
      this.logger.log(`findOne: id=${id} not found`);
      return null;
    }

    return {
      id: row.id,
      name: row.name,
      questions: (row.questions ?? []) as Question[],
      questionCount: row.questionCount,
      passScore: row.passScore,
      version: row.version,
      createdAt: this.toISOString(row.createdAt),
      updatedAt: this.toISOString(row.updatedAt),
    };
  }

  async create(data: CreateExamPaperRequest, userId: string): Promise<string> {
    const questions: Question[] = data.questions ?? [];
    const passScore = data.passScore ?? 60;

    const [inserted] = await this.db
      .insert(examPaper)
      .values({
        name: data.name,
        questions: questions as unknown as object,
        questionCount: questions.length,
        passScore,
        createdBy: userId,
        updatedBy: userId,
      })
      .returning({ id: examPaper.id });

    this.logger.log(`create: name=${data.name}, id=${inserted.id}, by=${userId}`);
    return inserted.id;
  }

  async update(id: string, data: UpdateExamPaperRequest): Promise<boolean> {
    const updateData: Record<string, unknown> = {};

    if (data.name !== undefined) {
      updateData.name = data.name;
    }
    if (data.questions !== undefined) {
      updateData.questions = data.questions as unknown as object;
      updateData.questionCount = data.questions.length;
    }
    if (data.passScore !== undefined) {
      updateData.passScore = data.passScore;
    }

    if (data.questions !== undefined || data.passScore !== undefined) {
      updateData.version = sql`${examPaper.version} + 1`;
    }

    if (Object.keys(updateData).length === 0) {
      this.logger.log(`update: id=${id} no fields to update`);
      return true;
    }

    const [updated] = await this.db
      .update(examPaper)
      .set(updateData)
      .where(eq(examPaper.id, id))
      .returning({ id: examPaper.id });

    this.logger.log(`update: id=${id}, success=${Boolean(updated)}`);
    return Boolean(updated);
  }

  async remove(id: string): Promise<boolean> {
    const refResult = await this.db
      .select({ total: count() })
      .from(examRecord)
      .where(eq(examRecord.examPaperId, id));
    const refCount: number = Number(refResult[0]?.total ?? 0);
    if (refCount > 0) {
      throw new ConflictException(
        '该试卷已有答题记录，无法删除',
      );
    }

    const [deleted] = await this.db
      .delete(examPaper)
      .where(eq(examPaper.id, id))
      .returning({ id: examPaper.id });

    this.logger.log(`remove: id=${id}, success=${Boolean(deleted)}`);
    return Boolean(deleted);
  }

  private toISOString(value: Date | string): string {
    if (value instanceof Date) return value.toISOString();
    return new Date(value).toISOString();
  }
}
