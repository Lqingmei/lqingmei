import { Controller, Get, Post, Put, Delete, Body, Param, Query, Req } from '@nestjs/common';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';
import { ExamPaperService } from './exam-paper.service';
import type {
  CreateExamPaperRequest,
  UpdateExamPaperRequest,
} from '@shared/api.interface';

interface UserContext {
  userId: string;
  tenantId: string;
  appId: string;
  env: 'preview' | 'runtime';
  userName?: string;
}

@Controller('api/exam-papers')
export class ExamPaperController {
  constructor(private readonly examPaperService: ExamPaperService) {}

  @Get()
  async list(
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ) {
    const pageNum = parseInt(page ?? '1', 10) || 1;
    const pageSizeNum = parseInt(pageSize ?? '20', 10) || 20;
    return this.examPaperService.findAll(pageNum, pageSizeNum);
  }

  @Get(':id')
  async detail(@Param('id') id: string) {
    return this.examPaperService.findOne(id);
  }

  @NeedLogin()
  @Post()
  async create(
    @Req() req: Request,
    @Body() dto: CreateExamPaperRequest,
  ) {
    const { userId } = req.userContext as unknown as UserContext;
    const id = await this.examPaperService.create(dto, userId);
    return { id };
  }

  @NeedLogin()
  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateExamPaperRequest,
  ) {
    const success = await this.examPaperService.update(id, dto);
    return { success };
  }

  @NeedLogin()
  @Delete(':id')
  async remove(@Param('id') id: string) {
    const success = await this.examPaperService.remove(id);
    return { success };
  }
}
