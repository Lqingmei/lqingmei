import { Injectable, Inject, Logger, NotFoundException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { examRecord, lotteryRecord, examPaper, examAssignment, examRoster } from '@server/database/schema';
import { eq, and, sql, desc } from 'drizzle-orm';
import type {
  StatisticsOverview,
  ScoreDistributionResponse,
  ScoreDistributionItem,
  StatisticsRecordsResponse,
  StatisticsRecord,
  QuestionAnalysisResponse,
  QuestionStatItem,
  Question,
  AssignmentStatusResponse,
  AssignmentUserStatus,
  CenterDinnerStatsResponse,
  CenterDinnerStat,
} from '@shared/api.interface';

@Injectable()
export class StatisticsService {
  private readonly logger = new Logger(StatisticsService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async getOverview(): Promise<StatisticsOverview> {
    try {
      const [examStats] = await this.db
        .select({
          totalParticipants: sql<number>`count(distinct (examinee).user_id)::int`,
          averageScore:
            sql<number>`coalesce(round(avg(correct_rate)::numeric, 1)::float8, 0)`,
          passCount: sql<number>`count(*) filter (where is_passed = true)::int`,
          totalCount: sql<number>`count(*)::int`,
        })
        .from(examRecord)
        .where(eq(examRecord.status, 'completed'));

      const [prizeStats] = await this.db
        .select({
          count: sql<number>`count(*)::int`,
        })
        .from(lotteryRecord);

      const totalParticipants: number = examStats?.totalParticipants ?? 0;
      const averageScore: number = Number(examStats?.averageScore ?? 0);
      const passCount: number = examStats?.passCount ?? 0;
      const totalCount: number = examStats?.totalCount ?? 0;
      const passRate: number =
        totalCount > 0 ? Math.round((passCount / totalCount) * 100) : 0;
      const awardedPrizes: number = prizeStats?.count ?? 0;

      return { totalParticipants, averageScore, passRate, awardedPrizes };
    } catch (error) {
      this.logger.error(
        '获取统计概览失败: ' + JSON.stringify(error),
      );
      throw error;
    }
  }

  async getScoreDistribution(): Promise<ScoreDistributionResponse> {
    try {
      const caseExpr = sql<string>`case 
        when correct_rate < 60 then '0-59'
        when correct_rate < 70 then '60-69'
        when correct_rate < 80 then '70-79'
        when correct_rate < 90 then '80-89'
        else '90-100'
      end`;

      const result = await this.db
        .select({
          scoreRange: caseExpr,
          count: sql<number>`count(*)::int`,
        })
        .from(examRecord)
        .where(
          and(eq(examRecord.status, 'completed'), sql`correct_rate is not null`),
        )
        .groupBy(caseExpr);

      const allRanges: string[] = [
        '0-59',
        '60-69',
        '70-79',
        '80-89',
        '90-100',
      ];
      const resultMap: Record<string, number> = {};

      for (const row of result) {
        const range: string = row.scoreRange;
        resultMap[range] = row.count;
      }

      const distribution: ScoreDistributionItem[] = allRanges.map(
        (range: string) => ({
          scoreRange: range,
          count: resultMap[range] ?? 0,
        }),
      );

      return { distribution };
    } catch (error) {
      this.logger.error(
        '获取成绩分布失败: ' + JSON.stringify(error),
      );
      throw error;
    }
  }

  async getRecords(
    page: number,
    pageSize: number,
    keyword?: string,
    department?: string,
    startTime?: string,
    endTime?: string,
  ): Promise<StatisticsRecordsResponse> {
    try {
      const conditions = [eq(examRecord.status, 'completed')];

      if (keyword) {
        conditions.push(
          sql`(${examRecord.examinee}).user_id ilike ${`%${keyword}%`}`,
        );
      }
      if (startTime) {
        conditions.push(
          sql`${examRecord.createdAt} >= ${new Date(startTime).toISOString()}::timestamptz`,
        );
      }
      if (endTime) {
        conditions.push(
          sql`${examRecord.createdAt} <= ${new Date(endTime).toISOString()}::timestamptz`,
        );
      }

      const whereClause = and(...conditions);
      const offset: number = (page - 1) * pageSize;

      const [records, countResult] = await Promise.all([
        this.db
          .select({
            id: examRecord.id,
            userName: sql<string>`(${examRecord.examinee}).user_id`,
            score: examRecord.score,
            isPassed: examRecord.isPassed,
            prizeName: lotteryRecord.prizeName,
            createdAt: examRecord.createdAt,
            center: examRoster.center,
          })
          .from(examRecord)
          .leftJoin(
            lotteryRecord,
            eq(lotteryRecord.examRecordId, examRecord.id),
          )
          .leftJoin(
            examRoster,
            sql`(${examRecord.examinee}).user_id = (${examRoster.userId}).user_id`,
          )
          .where(whereClause)
          .orderBy(desc(examRecord.createdAt))
          .limit(pageSize)
          .offset(offset),
        this.db
          .select({
            count: sql<number>`count(distinct ${examRecord.id})::int`,
          })
          .from(examRecord)
          .leftJoin(
            lotteryRecord,
            eq(lotteryRecord.examRecordId, examRecord.id),
          )
          .where(whereClause),
      ]);

      const total: number = countResult[0]?.count ?? 0;

      const items: StatisticsRecord[] = records.map(
        (r: {
          id: string;
          userName: string;
          score: number | null;
          isPassed: boolean;
          prizeName: string | null;
          createdAt: Date;
          center: string | null;
        }): StatisticsRecord => ({
          id: r.id,
          userName: r.userName,
          center: r.center ?? '',
          score: r.score ?? 0,
          isPassed: r.isPassed,
          prizeName: r.prizeName ?? undefined,
          createdAt:
            r.createdAt instanceof Date
              ? r.createdAt.toISOString()
              : String(r.createdAt),
        }),
      );

      return { items, total };
    } catch (error) {
      this.logger.error(
        '获取统计记录失败: ' + JSON.stringify(error),
      );
      throw error;
    }
  }

  async getQuestionAnalysis(paperId: string): Promise<QuestionAnalysisResponse> {
    const [paper] = await this.db
      .select({
        id: examPaper.id,
        name: examPaper.name,
        questions: examPaper.questions,
      })
      .from(examPaper)
      .where(eq(examPaper.id, paperId));

    if (!paper) {
      throw new NotFoundException('试卷不存在');
    }

    const records = await this.db
      .select({ answers: examRecord.answers })
      .from(examRecord)
      .where(
        and(
          eq(examRecord.examPaperId, paperId),
          eq(examRecord.status, 'completed'),
        ),
      );

    const questions = (paper.questions ?? []) as Question[];
    const totalParticipants = records.length;

    const questionStats: QuestionStatItem[] = questions.map(
      (q: Question, index: number): QuestionStatItem => {
        let correctCount = 0;
        let answeredCount = 0;

        for (const record of records) {
          const userAnswer = (
            record.answers as Record<string, number | number[]>
          )?.[String(index)];
          if (userAnswer === undefined) continue;
          answeredCount++;

          const qType = q.type ?? 'single';
          if (qType === 'multiple') {
            const correctArr = Array.isArray(q.correctAnswer)
              ? q.correctAnswer
              : [q.correctAnswer];
            const userArr = Array.isArray(userAnswer)
              ? userAnswer
              : [userAnswer];
            if (
              correctArr.length === userArr.length &&
              correctArr.every((a: number) => userArr.includes(a))
            ) {
              correctCount++;
            }
          } else {
            if (userAnswer === q.correctAnswer) {
              correctCount++;
            }
          }
        }

        return {
          index,
          title: q.title,
          type: q.type ?? 'single',
          correctCount,
          totalAnswers: answeredCount,
          correctRate:
            answeredCount > 0
              ? Math.round((correctCount / answeredCount) * 100)
              : 0,
        };
      },
    );

    return {
      paperId,
      paperName: paper.name,
      totalParticipants,
      questions: questionStats,
    };
  }

  async getCenterDinnerStats(): Promise<CenterDinnerStatsResponse> {
    try {
      const result = await this.db
        .select({
          center: sql<string>`coalesce(${examRoster.center}, '')`,
          rosterCount: sql<number>`count(distinct ${examRoster.id})::int`,
          participantCount: sql<number>`count(distinct ${examRecord.id}) filter (where ${examRecord.status} = 'completed')::int`,
          passedCount: sql<number>`count(distinct ${examRecord.id}) filter (where ${examRecord.isPassed} = true)::int`,
          winnerCount: sql<number>`count(distinct ${lotteryRecord.id})::int`,
        })
        .from(examRoster)
        .leftJoin(
          examRecord,
          sql`(${examRecord.examinee}).user_id = (${examRoster.userId}).user_id and ${examRecord.status} = 'completed'`,
        )
        .leftJoin(
          lotteryRecord,
          eq(lotteryRecord.examRecordId, examRecord.id),
        )
        .where(eq(examRoster.status, 'resolved'))
        .groupBy(sql`coalesce(${examRoster.center}, '')`);

      const items: CenterDinnerStat[] = result.map(
        (r: {
          center: string;
          rosterCount: number;
          participantCount: number;
          passedCount: number;
          winnerCount: number;
        }): CenterDinnerStat => {
          const rosterCount = Number(r.rosterCount);
          const passedCount = Number(r.passedCount);
          const passRate =
            rosterCount > 0
              ? Number(((passedCount / rosterCount) * 100).toFixed(2))
              : 0;
          return {
            center: r.center || '未分配',
            rosterCount,
            participantCount: Number(r.participantCount),
            passedCount,
            winnerCount: Number(r.winnerCount),
            passRate,
          };
        },
      );

      return { items };
    } catch (error) {
      this.logger.error(
        '获取中心分布统计失败: ' + JSON.stringify(error),
      );
      throw error;
    }
  }

  async getAssignmentStatus(
    paperId: string,
  ): Promise<AssignmentStatusResponse> {
    const assignments = await this.db
      .select({
        assignedUsers: examAssignment.assignedUsers,
      })
      .from(examAssignment)
      .where(
        and(
          eq(examAssignment.examPaperId, paperId),
          eq(examAssignment.status, 'published'),
        ),
      );

    if (assignments.length === 0) {
      throw new NotFoundException('该试卷未发布');
    }

    const [paper] = await this.db
      .select({ name: examPaper.name })
      .from(examPaper)
      .where(eq(examPaper.id, paperId));

    const assignedUserIds: string[] = [];
    const seen = new Set<string>();
    for (const a of assignments) {
      for (const uid of a.assignedUsers ?? []) {
        if (!seen.has(uid)) {
          seen.add(uid);
          assignedUserIds.push(uid);
        }
      }
    }

    const rosterRows = await this.db
      .select({
        userId: sql<string>`(${examRoster.userId}).user_id`,
        center: examRoster.center,
      })
      .from(examRoster);
    const centerMap = new Map<string, string>();
    for (const r of rosterRows) {
      if (r.userId) centerMap.set(r.userId, r.center ?? '');
    }

    const records = await this.db
      .select({
        userId: sql<string>`(${examRecord.examinee}).user_id`,
        score: examRecord.score,
        isPassed: examRecord.isPassed,
        createdAt: examRecord.createdAt,
      })
      .from(examRecord)
      .where(
        and(
          eq(examRecord.examPaperId, paperId),
          eq(examRecord.status, 'completed'),
        ),
      );

    const recordMap = new Map<
      string,
      { score: number | null; isPassed: boolean; createdAt: Date }
    >();
    for (const r of records) {
      recordMap.set(r.userId, {
        score: r.score,
        isPassed: r.isPassed,
        createdAt: r.createdAt,
      });
    }

    let completedCount = 0;
    const items: AssignmentUserStatus[] = assignedUserIds.map(
      (userId: string): AssignmentUserStatus => {
        const record = recordMap.get(userId);
        if (record) {
          completedCount++;
          return {
            userId,
            status: 'completed',
            score: record.score ?? 0,
            isPassed: record.isPassed,
            submittedAt:
              record.createdAt instanceof Date
                ? record.createdAt.toISOString()
                : String(record.createdAt),
            center: centerMap.get(userId) ?? '',
          };
        }
        return { userId, status: 'not_answered', center: centerMap.get(userId) ?? '' };
      },
    );

    const totalAssigned = assignedUserIds.length;
    const notAnsweredCount = totalAssigned - completedCount;
    const completionRate =
      totalAssigned > 0
        ? Math.round((completedCount / totalAssigned) * 100)
        : 0;

    return {
      paperId,
      paperName: paper?.name ?? '',
      totalAssigned,
      completedCount,
      notAnsweredCount,
      completionRate,
      items,
    };
  }
}
