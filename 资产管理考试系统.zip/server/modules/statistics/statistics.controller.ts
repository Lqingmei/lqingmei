import { Controller, Get, Query } from '@nestjs/common';
import { StatisticsService } from './statistics.service';

@Controller('api/statistics')
export class StatisticsController {
  constructor(private readonly statisticsService: StatisticsService) {}

  @Get('overview')
  async getOverview() {
    return this.statisticsService.getOverview();
  }

  @Get('score-distribution')
  async getScoreDistribution() {
    return this.statisticsService.getScoreDistribution();
  }

  @Get('center-dinner')
  async getCenterDinnerStats() {
    return this.statisticsService.getCenterDinnerStats();
  }

  @Get('records')
  async getRecords(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '20',
    @Query('keyword') keyword?: string,
    @Query('department') department?: string,
    @Query('startTime') startTime?: string,
    @Query('endTime') endTime?: string,
  ) {
    return this.statisticsService.getRecords(
      parseInt(page, 10) || 1,
      parseInt(pageSize, 10) || 20,
      keyword,
      department,
      startTime,
      endTime,
    );
  }

  @Get('question-analysis')
  async getQuestionAnalysis(@Query('paperId') paperId: string) {
    return this.statisticsService.getQuestionAnalysis(paperId);
  }

  @Get('assignment-status')
  async getAssignmentStatus(@Query('paperId') paperId: string) {
    return this.statisticsService.getAssignmentStatus(paperId);
  }
}
