import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  Req,
  UnauthorizedException,
} from '@nestjs/common';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';
import { ExamAssignmentService } from './exam-assignment.service';
import type { CreateExamAssignmentRequest } from '@shared/api.interface';

interface UserContext {
  userId: string;
  tenantId: string;
  appId: string;
  env: 'preview' | 'runtime';
  userName?: string;
}

@Controller('api/exam-assignments')
export class ExamAssignmentController {
  constructor(
    private readonly examAssignmentService: ExamAssignmentService,
  ) {}

  @NeedLogin()
  @Get()
  async list() {
    return this.examAssignmentService.findAll();
  }

  @NeedLogin()
  @Get('my')
  async myAssignments(@Req() req: Request) {
    const { userId } = req.userContext as unknown as UserContext;
    if (!userId) throw new UnauthorizedException('请先登录');
    return this.examAssignmentService.findMyAssignments(userId);
  }

  @NeedLogin()
  @Post()
  async publish(
    @Req() req: Request,
    @Body() dto: CreateExamAssignmentRequest,
  ) {
    const { userId } = req.userContext as unknown as UserContext;
    const id = await this.examAssignmentService.publish(dto, userId);
    return { id };
  }

  @NeedLogin()
  @Delete(':id')
  async remove(@Param('id') id: string) {
    const success = await this.examAssignmentService.remove(id);
    return { success };
  }
}
