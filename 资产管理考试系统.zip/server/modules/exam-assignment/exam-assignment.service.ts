import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { Inject } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, sql, desc, count } from 'drizzle-orm';
import { examAssignment, examPaper } from '@server/database/schema';
import type {
  ExamAssignmentListItem,
  ExamAssignmentListResponse,
  ExamPaperListItem,
  CreateExamAssignmentRequest,
} from '@shared/api.interface';

@Injectable()
export class ExamAssignmentService {
  private readonly logger = new Logger(ExamAssignmentService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async publish(
    data: CreateExamAssignmentRequest,
    userId: string,
  ): Promise<string> {
    const [paper] = await this.db
      .select({ version: examPaper.version })
      .from(examPaper)
      .where(eq(examPaper.id, data.examPaperId));
    const publishedVersion = paper?.version ?? 1;

    const [inserted] = await this.db
      .insert(examAssignment)
      .values({
        examPaperId: data.examPaperId,
        assignedUsers: data.assignedUsers,
        status: 'published',
        publishedVersion,
        createdBy: userId,
        updatedBy: userId,
      })
      .returning({ id: examAssignment.id });

    this.logger.log(
      `publish: created assignment id=${inserted.id}, paper=${data.examPaperId}, version=${publishedVersion}, users=${data.assignedUsers.length}, by=${userId}`,
    );
    return inserted.id;
  }

  async findAll(): Promise<ExamAssignmentListResponse> {
    const rows = await this.db
      .select({
        id: examAssignment.id,
        examPaperId: examAssignment.examPaperId,
        examPaperName: examPaper.name,
        questionCount: examPaper.questionCount,
        status: examAssignment.status,
        createdAt: examAssignment.createdAt,
        publishedVersion: examAssignment.publishedVersion,
        assignedUserCount: sql<number>`array_length(${examAssignment.assignedUsers}, 1)`,
      })
      .from(examAssignment)
      .innerJoin(examPaper, eq(examAssignment.examPaperId, examPaper.id))
      .where(eq(examAssignment.status, 'published'))
      .orderBy(desc(examAssignment.createdAt));

    const items: ExamAssignmentListItem[] = rows.map((row) => ({
      id: row.id,
      examPaperId: row.examPaperId,
      examPaperName: row.examPaperName,
      questionCount: row.questionCount,
      assignedUserCount: Number(row.assignedUserCount ?? 0),
      publishedVersion: row.publishedVersion,
      status: row.status,
      createdAt: this.toISOString(row.createdAt),
    }));

    this.logger.log(`findAll: returned ${items.length} assignments`);
    return { items, total: items.length };
  }

  async findMyAssignments(userId: string): Promise<ExamPaperListItem[]> {
    if (!userId) return [];
    const rows = await this.db
      .select({
        id: examPaper.id,
        name: examPaper.name,
        questionCount: examPaper.questionCount,
        createdAt: examPaper.createdAt,
        updatedAt: examPaper.updatedAt,
      })
      .from(examAssignment)
      .innerJoin(examPaper, eq(examAssignment.examPaperId, examPaper.id))
      .where(
        and(
          eq(examAssignment.status, 'published'),
          sql`${examAssignment.assignedUsers} @> ARRAY[ROW(${userId})::user_profile]::user_profile[]`,
        ),
      )
      .orderBy(desc(examPaper.updatedAt));

    const seen = new Set<string>();
    const items: ExamPaperListItem[] = [];
    for (const row of rows) {
      if (seen.has(row.id)) continue;
      seen.add(row.id);
      items.push({
        id: row.id,
        name: row.name,
        questionCount: row.questionCount,
        createdAt: this.toISOString(row.createdAt),
        updatedAt: this.toISOString(row.updatedAt),
      });
    }

    this.logger.log(
      `findMyAssignments: user=${userId}, returned ${items.length} papers`,
    );
    return items;
  }

  async getAssignmentByPaperId(
    paperId: string,
  ): Promise<{ assignedUsers: string[] } | null> {
    const [row] = await this.db
      .select({
        assignedUsers: examAssignment.assignedUsers,
      })
      .from(examAssignment)
      .where(
        and(
          eq(examAssignment.examPaperId, paperId),
          eq(examAssignment.status, 'published'),
        ),
      );

    if (!row) return null;
    return { assignedUsers: row.assignedUsers ?? [] };
  }

  async remove(id: string): Promise<boolean> {
    const [deleted] = await this.db
      .delete(examAssignment)
      .where(eq(examAssignment.id, id))
      .returning({ id: examAssignment.id });

    if (!deleted) {
      throw new NotFoundException('发布记录不存在');
    }

    this.logger.log(`remove: id=${id}, success=true`);
    return true;
  }

  private toISOString(value: Date | string): string {
    if (value instanceof Date) return value.toISOString();
    return new Date(value).toISOString();
  }
}
