import { Module } from '@nestjs/common';
import { ExamAssignmentController } from './exam-assignment.controller';
import { ExamAssignmentService } from './exam-assignment.service';

@Module({
  controllers: [ExamAssignmentController],
  providers: [ExamAssignmentService],
  exports: [ExamAssignmentService],
})
export class ExamAssignmentModule {}
