import {
  Injectable,
  Inject,
  Logger,
  BadRequestException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { notificationTemplate } from '@server/database/schema';
import { eq } from 'drizzle-orm';
import type {
  NotificationTemplate,
  UpdateNotificationTemplateRequest,
} from '@shared/api.interface';

const DEFAULT_TITLE = '考试通知：{examName}';
const DEFAULT_DESCRIPTION =
  '您被分配参加考试**《{examName}》**，共 {questionCount} 道题目，及格分 {passScore} 分。\n\n请点击下方「开始考试」按钮进入答题界面。通过考试后可参与抽奖！';

@Injectable()
export class NotificationTemplateService {
  private readonly logger = new Logger(NotificationTemplateService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async get(): Promise<NotificationTemplate> {
    const rows = await this.db
      .select({
        id: notificationTemplate.id,
        titleTemplate: notificationTemplate.titleTemplate,
        descriptionTemplate: notificationTemplate.descriptionTemplate,
      })
      .from(notificationTemplate)
      .limit(1);

    if (rows.length === 0) {
      return {
        id: '',
        titleTemplate: DEFAULT_TITLE,
        descriptionTemplate: DEFAULT_DESCRIPTION,
      };
    }

    return {
      id: rows[0].id,
      titleTemplate: rows[0].titleTemplate,
      descriptionTemplate: rows[0].descriptionTemplate,
    };
  }

  async update(
    data: UpdateNotificationTemplateRequest,
    userId: string,
  ): Promise<NotificationTemplate> {
    this.logger.log(`Updating notification template by user ${userId}`);

    if (
      data.titleTemplate !== undefined &&
      data.titleTemplate.trim().length === 0
    ) {
      throw new BadRequestException('标题模版不能为空');
    }
    if (
      data.descriptionTemplate !== undefined &&
      data.descriptionTemplate.trim().length === 0
    ) {
      throw new BadRequestException('正文模版不能为空');
    }

    const existing = await this.db
      .select({ id: notificationTemplate.id })
      .from(notificationTemplate)
      .limit(1);

    const updateData: Record<string, unknown> = { updatedBy: userId };
    if (data.titleTemplate !== undefined)
      updateData.titleTemplate = data.titleTemplate.trim();
    if (data.descriptionTemplate !== undefined)
      updateData.descriptionTemplate = data.descriptionTemplate.trim();

    if (existing.length === 0) {
      const [created] = await this.db
        .insert(notificationTemplate)
        .values({
          titleTemplate: data.titleTemplate?.trim() ?? DEFAULT_TITLE,
          descriptionTemplate:
            data.descriptionTemplate?.trim() ?? DEFAULT_DESCRIPTION,
          createdBy: userId,
          updatedBy: userId,
        })
        .returning({
          id: notificationTemplate.id,
          titleTemplate: notificationTemplate.titleTemplate,
          descriptionTemplate: notificationTemplate.descriptionTemplate,
        });

      return {
        id: created.id,
        titleTemplate: created.titleTemplate,
        descriptionTemplate: created.descriptionTemplate,
      };
    }

    const [updated] = await this.db
      .update(notificationTemplate)
      .set(updateData)
      .where(eq(notificationTemplate.id, existing[0].id))
      .returning({
        id: notificationTemplate.id,
        titleTemplate: notificationTemplate.titleTemplate,
        descriptionTemplate: notificationTemplate.descriptionTemplate,
      });

    return {
      id: updated.id,
      titleTemplate: updated.titleTemplate,
      descriptionTemplate: updated.descriptionTemplate,
    };
  }
}
