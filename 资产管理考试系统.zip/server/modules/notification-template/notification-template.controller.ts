import {
  Controller,
  Get,
  Put,
  Body,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import { NotificationTemplateService } from './notification-template.service';
import type { UpdateNotificationTemplateRequest } from '@shared/api.interface';

interface UserContext {
  userId: string;
  tenantId: string;
  appId: string;
  env: 'preview' | 'runtime';
}

@Controller('api/notification-template')
export class NotificationTemplateController {
  constructor(
    private readonly notificationTemplateService: NotificationTemplateService,
  ) {}

  @Get()
  async get() {
    return this.notificationTemplateService.get();
  }

  @NeedLogin()
  @Put()
  async update(
    @Req() req: Request,
    @Body() dto: UpdateNotificationTemplateRequest,
  ) {
    const { userId } = req.userContext as unknown as UserContext;
    return this.notificationTemplateService.update(dto, userId);
  }
}
