import {
  Injectable,
  Inject,
  Logger,
  BadRequestException,
  NotFoundException,
  ConflictException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { lotteryRecord, examRecord, examPaper, prize, lotteryConfig } from '@server/database/schema';
import { eq, and, sql } from 'drizzle-orm';
import type { DrawLotteryResponse, LotteryConfig, Question } from '@shared/api.interface';

interface PrizeRow {
  id: string;
  name: string;
  quantity: number;
  imageUrl: string | null;
}

@Injectable()
export class LotteryService {
  private readonly logger = new Logger(LotteryService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async draw(
    examRecordId: string,
    userId: string,
  ): Promise<DrawLotteryResponse> {
    // 1. Check if user already won any prize (每人只能抽中一张)
    const [existingWin] = await this.db
      .select({
        id: lotteryRecord.id,
        prizeId: lotteryRecord.prizeId,
        prizeName: lotteryRecord.prizeName,
      })
      .from(lotteryRecord)
      .where(sql`(${lotteryRecord.winner}).user_id = ${userId}`);

    if (existingWin) {
      this.logger.log(
        `draw: user already won, userId=${userId}, prize=${existingWin.prizeName}`,
      );

      const [prizeRow] = await this.db
        .select({ imageUrl: prize.imageUrl })
        .from(prize)
        .where(eq(prize.id, existingWin.prizeId));

      return {
        success: true,
        prizeName: existingWin.prizeName,
        prizeImage: prizeRow?.imageUrl ?? undefined,
      };
    }

    // 2. Get exam record with paper questions, verify ownership and pass status
    const [record] = await this.db
      .select({
        id: examRecord.id,
        score: examRecord.score,
        status: examRecord.status,
        lotteryDrawn: examRecord.lotteryDrawn,
        questions: examPaper.questions,
      })
      .from(examRecord)
      .leftJoin(examPaper, eq(examRecord.examPaperId, examPaper.id))
      .where(
        and(
          eq(examRecord.id, examRecordId),
          sql`(${examRecord.examinee}).user_id = ${userId}`,
        ),
      );

    if (!record) {
      throw new NotFoundException('答题记录不存在');
    }

    if (record.status !== 'completed') {
      throw new BadRequestException('考试尚未完成，无法抽奖');
    }

    // 2.5. Already drew (win or lose) — return result without re-drawing
    if (record.lotteryDrawn) {
      this.logger.log(
        `draw: already drawn, userId=${userId}, returning existing result`,
      );
      // existingWin was checked in step 1; if reached here, user drew but didn't win
      return {
        success: false,
        prizeName: '',
      };
    }

    const questions = (record.questions ?? []) as Question[];
    const hasCustomScores = questions.some(
      (q: Question) => q.score !== undefined && q.score > 0,
    );
    const totalScore = hasCustomScores
      ? questions.reduce(
          (sum: number, q: Question) => sum + (q.score ?? 0),
          0,
        )
      : 100;

    if (record.score !== totalScore) {
      throw new BadRequestException('需满分才能抽奖');
    }

    // 3. Get all prizes with remaining quantity (quantity - won count > 0)
    const prizes: PrizeRow[] = await this.db
      .select({
        id: prize.id,
        name: prize.name,
        quantity: prize.quantity,
        imageUrl: prize.imageUrl,
      })
      .from(prize);

    if (prizes.length === 0) {
      throw new BadRequestException('暂无可用奖品');
    }

    // 4. Calculate remaining quantity for each prize
    const availablePrizes: PrizeRow[] = [];
    for (const p of prizes) {
      const [{ count: wonCount }] = await this.db
        .select({ count: sql<number>`count(*)::int` })
        .from(lotteryRecord)
        .where(eq(lotteryRecord.prizeId, p.id));

      const remaining = p.quantity - wonCount;
      if (remaining > 0) {
        availablePrizes.push(p);
      }
    }

    if (availablePrizes.length === 0) {
      throw new BadRequestException('奖品已抽完');
    }

    // 5. Win probability check — not every draw wins
    const config = await this.getConfig();
    const drawResult = Math.random();
    const isWin = drawResult < config.winProbability;

    let selectedPrize: PrizeRow | null = null;
    if (isWin) {
      // 6. Randomly select one prize from available
      const randomIndex = Math.floor(Math.random() * availablePrizes.length);
      selectedPrize = availablePrizes[randomIndex];
    }

    // 7. Atomic: mark lottery_drawn + insert winning record if applicable
    const result = await this.db.transaction(async (tx) => {
      // Mark exam_record as lottery_drawn = true (prevents re-draw)
      const [updated] = await tx
        .update(examRecord)
        .set({ lotteryDrawn: true })
        .where(
          and(
            eq(examRecord.id, examRecordId),
            eq(examRecord.lotteryDrawn, false),
          ),
        )
        .returning({ id: examRecord.id });

      if (!updated) {
        throw new ConflictException('您已抽过奖');
      }

      if (!isWin || !selectedPrize) {
        return null;
      }

      // Re-check user hasn't won inside transaction (race condition guard)
      const [recheckWin] = await tx
        .select({ id: lotteryRecord.id })
        .from(lotteryRecord)
        .where(sql`(${lotteryRecord.winner}).user_id = ${userId}`)
        .limit(1);

      if (recheckWin) {
        throw new ConflictException('您已抽过奖');
      }

      // Re-check remaining quantity inside transaction
      const [{ count: currentWon }] = await tx
        .select({ count: sql<number>`count(*)::int` })
        .from(lotteryRecord)
        .where(eq(lotteryRecord.prizeId, selectedPrize.id));

      if (currentWon >= selectedPrize.quantity) {
        throw new ConflictException('该奖品已抽完');
      }

      const [inserted] = await tx
        .insert(lotteryRecord)
        .values({
          examRecordId,
          winner: userId,
          prizeId: selectedPrize.id,
          prizeName: selectedPrize.name,
        })
        .returning({ id: lotteryRecord.id });

      return inserted;
    });

    if (!isWin || !selectedPrize) {
      this.logger.log(
        `draw: not won, userId=${userId}, drawResult=${drawResult.toFixed(3)}`,
      );
      return {
        success: false,
        prizeName: '',
      };
    }

    this.logger.log(
      `draw: new lottery created, recordId=${examRecordId}, lotteryId=${result?.id}, prize=${selectedPrize.name}, user=${userId}`,
    );

    return {
      success: true,
      prizeName: selectedPrize.name,
      prizeImage: selectedPrize.imageUrl ?? undefined,
    };
  }

  async getConfig(): Promise<LotteryConfig> {
    const [row] = await this.db
      .select({ winProbability: lotteryConfig.winProbability })
      .from(lotteryConfig)
      .limit(1);

    if (!row) {
      this.logger.log('getConfig: no config row found, using default 0.5');
      return { winProbability: 0.5 };
    }

    return { winProbability: row.winProbability };
  }

  async updateConfig(winProbability: number): Promise<LotteryConfig> {
    if (winProbability < 0.01 || winProbability > 1) {
      throw new BadRequestException('中奖概率必须在 1% 到 100% 之间');
    }

    const [existing] = await this.db
      .select({ id: lotteryConfig.id })
      .from(lotteryConfig)
      .limit(1);

    if (existing) {
      const [updated] = await this.db
        .update(lotteryConfig)
        .set({ winProbability })
        .where(eq(lotteryConfig.id, existing.id))
        .returning({ winProbability: lotteryConfig.winProbability });

      this.logger.log(`updateConfig: winProbability updated to ${winProbability}`);
      return { winProbability: updated.winProbability };
    }

    const [inserted] = await this.db
      .insert(lotteryConfig)
      .values({ winProbability })
      .returning({ winProbability: lotteryConfig.winProbability });

    this.logger.log(`updateConfig: config created with winProbability=${winProbability}`);
    return { winProbability: inserted.winProbability };
  }
}
