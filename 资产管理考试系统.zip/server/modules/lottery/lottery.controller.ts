import { Controller, Post, Get, Put, Body, Req } from '@nestjs/common';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';
import { LotteryService } from './lottery.service';
import type { DrawLotteryRequest, UpdateLotteryConfigRequest } from '@shared/api.interface';

interface UserContext {
  userId: string;
  tenantId: string;
  appId: string;
  env: 'preview' | 'runtime';
  userName?: string;
}

@Controller('api/lottery')
export class LotteryController {
  constructor(private readonly lotteryService: LotteryService) {}

  /**
   * POST /api/lottery/draw
   * Draw lottery for a completed exam record.
   * Returns existing prize if already drawn.
   */
  @NeedLogin()
  @Post('draw')
  async draw(@Body() body: DrawLotteryRequest, @Req() req: Request) {
    const { userId } = req.userContext as unknown as UserContext;
    return this.lotteryService.draw(body.examRecordId, userId);
  }

  @Get('config')
  async getConfig() {
    return this.lotteryService.getConfig();
  }

  @NeedLogin()
  @Put('config')
  async updateConfig(@Body() body: UpdateLotteryConfigRequest) {
    return this.lotteryService.updateConfig(body.winProbability);
  }
}
