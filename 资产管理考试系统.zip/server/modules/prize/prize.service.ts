import {
  Injectable,
  Inject,
  Logger,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { prize } from '@server/database/schema';
import { eq, desc, count } from 'drizzle-orm';
import type {
  Prize,
  PrizeListResponse,
  CreatePrizeRequest,
  UpdatePrizeRequest,
  DeleteResponse,
} from '@shared/api.interface';

const MAX_PRIZE_COUNT = 24;

@Injectable()
export class PrizeService {
  private readonly logger = new Logger(PrizeService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async findAll(): Promise<PrizeListResponse> {
    this.logger.log('Fetching all prizes');

    const rows = await this.db
      .select({
        id: prize.id,
        name: prize.name,
        quantity: prize.quantity,
        imageUrl: prize.imageUrl,
      })
      .from(prize)
      .orderBy(desc(prize.createdAt));

    const totalResult = await this.db
      .select({ total: count() })
      .from(prize);
    const totalCount: number = Number(totalResult[0]?.total ?? 0);

    const items: Prize[] = rows.map((row) => ({
      id: row.id,
      name: row.name,
      quantity: row.quantity,
      imageUrl: row.imageUrl ?? undefined,
    }));

    return { items, totalCount, maxCount: MAX_PRIZE_COUNT };
  }

  async create(
    data: CreatePrizeRequest,
    userId: string,
  ): Promise<{ id: string }> {
    this.logger.log(
      `Creating prize by user ${userId}: ${JSON.stringify(data)}`,
    );

    if (!data.name || data.name.trim().length === 0) {
      throw new BadRequestException('奖品名称不能为空');
    }
    if (
      typeof data.quantity !== 'number' ||
      !Number.isInteger(data.quantity) ||
      data.quantity < 1
    ) {
      throw new BadRequestException('数量必须为正整数');
    }

    const totalResult = await this.db
      .select({ total: count() })
      .from(prize);
    const currentCount: number = Number(totalResult[0]?.total ?? 0);

    if (currentCount >= MAX_PRIZE_COUNT) {
      throw new BadRequestException(
        `奖品配置已达上限（${MAX_PRIZE_COUNT}个），无法继续添加`,
      );
    }

    const [created] = await this.db
      .insert(prize)
      .values({
        name: data.name.trim(),
        quantity: data.quantity,
        imageUrl: data.imageUrl ?? null,
        createdBy: userId,
        updatedBy: userId,
      })
      .returning({ id: prize.id });

    this.logger.log(`Prize created with id: ${created.id}`);
    return { id: created.id };
  }

  async update(
    id: string,
    data: UpdatePrizeRequest,
    userId: string,
  ): Promise<Prize> {
    this.logger.log(`Updating prize ${id} by user ${userId}`);

    const [existing] = await this.db
      .select({ id: prize.id })
      .from(prize)
      .where(eq(prize.id, id));

    if (!existing) {
      throw new NotFoundException('奖品不存在');
    }

    if (
      data.name !== undefined &&
      (!data.name || data.name.trim().length === 0)
    ) {
      throw new BadRequestException('奖品名称不能为空');
    }

    if (
      data.quantity !== undefined &&
      (!Number.isInteger(data.quantity) || data.quantity < 1)
    ) {
      throw new BadRequestException('数量必须为正整数');
    }

    const updateData: Record<string, unknown> = { updatedBy: userId };
    if (data.name !== undefined) updateData.name = data.name.trim();
    if (data.quantity !== undefined) updateData.quantity = data.quantity;
    if (data.imageUrl !== undefined) updateData.imageUrl = data.imageUrl;

    const [updated] = await this.db
      .update(prize)
      .set(updateData)
      .where(eq(prize.id, id))
      .returning({
        id: prize.id,
        name: prize.name,
        quantity: prize.quantity,
        imageUrl: prize.imageUrl,
      });

    return {
      id: updated.id,
      name: updated.name,
      quantity: updated.quantity,
      imageUrl: updated.imageUrl ?? undefined,
    };
  }

  async remove(id: string): Promise<DeleteResponse> {
    this.logger.log(`Deleting prize: ${id}`);

    const [deleted] = await this.db
      .delete(prize)
      .where(eq(prize.id, id))
      .returning({ id: prize.id });

    if (!deleted) {
      throw new NotFoundException('奖品不存在');
    }

    return { success: true };
  }
}
