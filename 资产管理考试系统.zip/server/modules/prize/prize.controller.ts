import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import { PrizeService } from './prize.service';
import type {
  CreatePrizeRequest,
  UpdatePrizeRequest,
} from '@shared/api.interface';

interface UserContext {
  userId: string;
  tenantId: string;
  appId: string;
  env: 'preview' | 'runtime';
}

@Controller('api/prizes')
export class PrizeController {
  constructor(private readonly prizeService: PrizeService) {}

  @Get()
  async findAll() {
    return this.prizeService.findAll();
  }

  @NeedLogin()
  @Post()
  async create(
    @Req() req: Request,
    @Body() dto: CreatePrizeRequest,
  ) {
    const { userId } = req.userContext as unknown as UserContext;
    return this.prizeService.create(dto, userId);
  }

  @NeedLogin()
  @Patch(':id')
  async update(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdatePrizeRequest,
  ) {
    const { userId } = req.userContext as unknown as UserContext;
    return this.prizeService.update(id, dto, userId);
  }

  @NeedLogin()
  @Delete(':id')
  async remove(@Param('id') id: string) {
    return this.prizeService.remove(id);
  }
}
