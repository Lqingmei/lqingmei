import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Req,
} from '@nestjs/common';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';
import { ExamRosterService } from './exam-roster.service';
import type { SaveExamRosterRequest, UpdateExamRosterRequest, AddRosterItemRequest } from '@shared/api.interface';

interface UserContext {
  userId: string;
  tenantId: string;
  appId: string;
  env: 'preview' | 'runtime';
  userName?: string;
}

@Controller('api/exam-roster')
export class ExamRosterController {
  constructor(private readonly examRosterService: ExamRosterService) {}

  @Get()
  async findAll() {
    return this.examRosterService.findAll();
  }

  @Get('resolved')
  async findAllResolved() {
    return this.examRosterService.findAllResolved();
  }

  @NeedLogin()
  @Post()
  async save(@Body() body: SaveExamRosterRequest, @Req() req: Request) {
    const { userId } = req.userContext as unknown as UserContext;
    return this.examRosterService.save(body, userId);
  }

  @NeedLogin()
  @Post('item')
  async addItem(@Body() body: AddRosterItemRequest, @Req() req: Request) {
    const { userId } = req.userContext as unknown as UserContext;
    return this.examRosterService.addItem(body, userId);
  }

  @NeedLogin()
  @Put(':id')
  async updateItem(
    @Param('id') id: string,
    @Body() body: UpdateExamRosterRequest,
    @Req() req: Request,
  ) {
    const { userId } = req.userContext as unknown as UserContext;
    return this.examRosterService.updateItem(id, body, userId);
  }

  @NeedLogin()
  @Delete(':id')
  async remove(@Param('id') id: string) {
    return this.examRosterService.remove(id);
  }

  @NeedLogin()
  @Delete()
  async clearAll() {
    return this.examRosterService.clearAll();
  }
}
