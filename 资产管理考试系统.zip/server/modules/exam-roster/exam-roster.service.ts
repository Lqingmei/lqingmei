import {
  Injectable,
  Inject,
  Logger,
  NotFoundException,
  ConflictException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { examRoster } from '@server/database/schema';
import { eq, sql } from 'drizzle-orm';
import type {
  ExamRosterItem,
  ExamRosterListResponse,
  SaveExamRosterRequest,
  SaveExamRosterResponse,
  UpdateExamRosterRequest,
  AddRosterItemRequest,
} from '@shared/api.interface';

@Injectable()
export class ExamRosterService {
  private readonly logger = new Logger(ExamRosterService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async findAll(): Promise<ExamRosterListResponse> {
    const rows = await this.db
      .select({
        id: examRoster.id,
        name: examRoster.name,
        userId: examRoster.userId,
        status: examRoster.status,
        center: examRoster.center,
      })
      .from(examRoster)
      .orderBy(examRoster.name);

    const items: ExamRosterItem[] = rows.map((row) => ({
      id: row.id,
      name: row.name,
      userId: row.userId ?? undefined,
      status: row.status as ExamRosterItem['status'],
      center: row.center ?? '',
    }));

    this.logger.log(`findAll: returned ${items.length} roster items`);
    return { items, total: items.length };
  }

  async findAllResolved(): Promise<{ userIds: string[] }> {
    const rows = await this.db
      .select({ userId: examRoster.userId })
      .from(examRoster)
      .where(eq(examRoster.status, 'resolved'));

    const userIds: string[] = rows
      .map((r) => r.userId)
      .filter((id): id is string => id !== null);

    this.logger.log(`findAllResolved: ${userIds.length} resolved users`);
    return { userIds };
  }

  async save(
    data: SaveExamRosterRequest,
    userId: string,
  ): Promise<SaveExamRosterResponse> {
    if (data.items.length === 0) {
      return { success: true, inserted: 0, skipped: 0 };
    }

    const existing = await this.db
      .select({ userId: examRoster.userId, name: examRoster.name })
      .from(examRoster);

    const existingUserIds = new Set(
      existing
        .map((r) => r.userId)
        .filter((id): id is string => id !== null),
    );
    const existingNames = new Set(
      existing.map((r) => r.name),
    );

    const newItems = data.items.filter((item) =>
      item.userId
        ? !existingUserIds.has(item.userId)
        : !existingNames.has(item.name),
    );

    const skipped = data.items.length - newItems.length;

    if (newItems.length > 0) {
      const values = newItems.map((item) => ({
        name: item.name,
        userId: item.userId ?? null,
        status: item.status,
        center: item.center ?? '',
        createdBy: userId,
        updatedBy: userId,
      }));
      await this.db.insert(examRoster).values(values);
    }

    this.logger.log(
      `save: ${newItems.length} inserted, ${skipped} skipped by user=${userId}`,
    );
    return { success: true, inserted: newItems.length, skipped };
  }

  async remove(id: string): Promise<boolean> {
    const [deleted] = await this.db
      .delete(examRoster)
      .where(eq(examRoster.id, id))
      .returning({ id: examRoster.id });

    if (!deleted) {
      throw new NotFoundException('名单项不存在');
    }

    this.logger.log(`remove: id=${id}, success=true`);
    return true;
  }

  async updateItem(
    id: string,
    data: UpdateExamRosterRequest,
    userId: string,
  ): Promise<ExamRosterItem> {
    const updateData: Record<string, unknown> = { updatedBy: userId };
    if (data.userId !== undefined) updateData.userId = data.userId;
    if (data.status !== undefined) updateData.status = data.status;
    if (data.center !== undefined) updateData.center = data.center;

    const [updated] = await this.db
      .update(examRoster)
      .set(updateData)
      .where(eq(examRoster.id, id))
      .returning({
        id: examRoster.id,
        name: examRoster.name,
        userId: examRoster.userId,
        status: examRoster.status,
        center: examRoster.center,
      });

    if (!updated) {
      throw new NotFoundException('名单项不存在');
    }

    this.logger.log(`updateItem: id=${id}, by=${userId}`);
    return {
      id: updated.id,
      name: updated.name,
      userId: updated.userId ?? undefined,
      status: updated.status as ExamRosterItem['status'],
      center: updated.center ?? '',
    };
  }

  async addItem(
    data: AddRosterItemRequest,
    userId: string,
  ): Promise<ExamRosterItem> {
    const [existing] = await this.db
      .select({ id: examRoster.id })
      .from(examRoster)
      .where(sql`(${examRoster.userId}).user_id = ${data.userId}`)
      .limit(1);

    if (existing) {
      throw new ConflictException('该用户已在名单中');
    }

    const [inserted] = await this.db
      .insert(examRoster)
      .values({
        name: data.name,
        userId: data.userId,
        status: 'resolved',
        center: data.center ?? '',
        createdBy: userId,
        updatedBy: userId,
      })
      .returning({
        id: examRoster.id,
        name: examRoster.name,
        userId: examRoster.userId,
        status: examRoster.status,
        center: examRoster.center,
      });

    this.logger.log(`addItem: name=${data.name}, userId=${data.userId}, by=${userId}`);
    return {
      id: inserted.id,
      name: inserted.name,
      userId: inserted.userId ?? undefined,
      status: inserted.status as ExamRosterItem['status'],
      center: inserted.center ?? '',
    };
  }

  async clearAll(): Promise<boolean> {
    await this.db.delete(examRoster);
    this.logger.log('clearAll: all roster items deleted');
    return true;
  }
}
