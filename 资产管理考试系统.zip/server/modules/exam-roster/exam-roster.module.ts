import { Module } from '@nestjs/common';
import { ExamRosterController } from './exam-roster.controller';
import { ExamRosterService } from './exam-roster.service';

@Module({
  controllers: [ExamRosterController],
  providers: [ExamRosterService],
})
export class ExamRosterModule {}
