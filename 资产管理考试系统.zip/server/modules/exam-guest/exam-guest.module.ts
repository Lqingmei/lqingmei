import { Module } from '@nestjs/common';
import { ExamGuestController } from './exam-guest.controller';
import { ExamGuestService } from './exam-guest.service';
import { ExamAssignmentModule } from '../exam-assignment/exam-assignment.module';
import { ExamRecordModule } from '../exam-record/exam-record.module';
import { LotteryModule } from '../lottery/lottery.module';

@Module({
  imports: [ExamAssignmentModule, ExamRecordModule, LotteryModule],
  controllers: [ExamGuestController],
  providers: [ExamGuestService],
})
export class ExamGuestModule {}
