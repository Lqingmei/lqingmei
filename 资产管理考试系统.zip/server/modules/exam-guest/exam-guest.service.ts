import { Injectable } from '@nestjs/common';
import { ExamAssignmentService } from '../exam-assignment/exam-assignment.service';
import { ExamRecordService } from '../exam-record/exam-record.service';
import { LotteryService } from '../lottery/lottery.service';
import type {
  ExamPaperListItem,
  ExamRecord,
  SubmitExamResponse,
  DrawLotteryResponse,
} from '@shared/api.interface';

@Injectable()
export class ExamGuestService {
  constructor(
    private readonly examAssignmentService: ExamAssignmentService,
    private readonly examRecordService: ExamRecordService,
    private readonly lotteryService: LotteryService,
  ) {}

  async getMyPapers(
    userId: string,
  ): Promise<{ identified: boolean; items: ExamPaperListItem[] }> {
    const items = await this.examAssignmentService.findMyAssignments(userId);
    return { identified: true, items };
  }

  async getMyRecord(
    paperId: string,
    userId: string,
  ): Promise<{ identified: boolean; record: ExamRecord | null }> {
    const completed = await this.examRecordService.findMyRecord(paperId, userId);
    if (completed) {
      return { identified: true, record: completed };
    }
    const draft = await this.examRecordService.findMyDraft(paperId, userId);
    return { identified: true, record: draft };
  }

  async saveDraft(
    paperId: string,
    answers: Record<string, number | number[]>,
    userId: string,
  ): Promise<{ success: boolean }> {
    return this.examRecordService.saveDraft(paperId, answers, userId);
  }

  async submit(
    paperId: string,
    answers: Record<string, number | number[]>,
    userId: string,
  ): Promise<SubmitExamResponse> {
    return this.examRecordService.submit(paperId, answers, userId);
  }

  async drawLottery(
    examRecordId: string,
    userId: string,
  ): Promise<DrawLotteryResponse> {
    return this.lotteryService.draw(examRecordId, userId);
  }
}
