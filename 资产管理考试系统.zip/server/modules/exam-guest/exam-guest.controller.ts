import {
  Controller,
  Get,
  Post,
  Body,
  Query,
  Req,
  BadRequestException,
} from '@nestjs/common';
import type { Request } from 'express';
import { ExamGuestService } from './exam-guest.service';
import type {
  GuestDraftRequest,
  GuestSubmitRequest,
  GuestLotteryRequest,
} from '@shared/api.interface';

interface UserContext {
  userId: string;
  tenantId: string;
  appId: string;
  env: 'preview' | 'runtime';
  userName?: string;
}

@Controller('api/exam/guest')
export class ExamGuestController {
  constructor(private readonly examGuestService: ExamGuestService) {}

  @Get('my-papers')
  async getMyPapers(@Req() req: Request) {
    const { userId } = (req.userContext as unknown as UserContext | undefined) ?? {};
    if (!userId) {
      return { identified: false, items: [] };
    }
    return this.examGuestService.getMyPapers(userId);
  }

  @Get('my-record')
  async getMyRecord(
    @Query('paperId') paperId: string,
    @Req() req: Request,
  ) {
    if (!paperId) {
      throw new BadRequestException('paperId is required');
    }
    const { userId } = (req.userContext as unknown as UserContext | undefined) ?? {};
    if (!userId) {
      return { identified: false, record: null };
    }
    return this.examGuestService.getMyRecord(paperId, userId);
  }

  @Post('draft')
  async saveDraft(@Body() body: GuestDraftRequest, @Req() req: Request) {
    const { userId } = (req.userContext as unknown as UserContext | undefined) ?? {};
    if (!userId) {
      throw new BadRequestException('请通过飞书通知中的链接进入考试');
    }
    return this.examGuestService.saveDraft(body.paperId, body.answers, userId);
  }

  @Post('submit')
  async submit(@Body() body: GuestSubmitRequest, @Req() req: Request) {
    const { userId } = (req.userContext as unknown as UserContext | undefined) ?? {};
    if (!userId) {
      throw new BadRequestException('请通过飞书通知中的链接进入考试');
    }
    return this.examGuestService.submit(body.paperId, body.answers, userId);
  }

  @Post('lottery')
  async drawLottery(@Body() body: GuestLotteryRequest, @Req() req: Request) {
    const { userId } = (req.userContext as unknown as UserContext | undefined) ?? {};
    if (!userId) {
      throw new BadRequestException('请通过飞书通知中的链接进入考试');
    }
    return this.examGuestService.drawLottery(body.examRecordId, userId);
  }
}
