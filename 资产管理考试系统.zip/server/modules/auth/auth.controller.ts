import { Controller, Get, Req } from '@nestjs/common';
import type { Request } from 'express';
import type { AuthMeResponse } from '@shared/api.interface';

interface UserContext {
  userId: string;
  tenantId: string;
  appId: string;
  env: 'preview' | 'runtime';
  userName?: string;
}

@Controller('api/auth')
export class AuthController {
  @Get('me')
  async getMe(@Req() req: Request): Promise<AuthMeResponse> {
    const userContext = req.userContext as unknown as UserContext | undefined;
    const userId = userContext?.userId;
    if (!userId) {
      return { loggedIn: false, userId: null };
    }
    return { loggedIn: true, userId };
  }
}
