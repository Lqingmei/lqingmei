import { Injectable, Inject, Logger, BadRequestException, NotFoundException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { examRecord, examPaper, examAssignment } from '@server/database/schema';
import { eq, and, sql, desc } from 'drizzle-orm';
import type {
  ExamRecord,
  SubmitExamResponse,
  Question,
  DeleteResponse,
} from '@shared/api.interface';

const DEFAULT_QUESTION_SCORE = 10;

const hasCustomScores = (questions: Question[]): boolean =>
  questions.some((q: Question) => q.score !== undefined && q.score > 0);

const getTotalScore = (questions: Question[]): number =>
  hasCustomScores(questions)
    ? questions.reduce(
        (sum: number, q: Question) => sum + (q.score ?? 0),
        0,
      )
    : 100;

@Injectable()
export class ExamRecordService {
  private readonly logger = new Logger(ExamRecordService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  /**
   * Find the user's completed record for a paper.
   * Returns record with score/correctRate/isPassed/hasLottery, or null.
   */
  async findMyRecord(
    examPaperId: string,
    userId: string,
  ): Promise<ExamRecord | null> {
    const [assignment] = await this.db
      .select({ publishedVersion: examAssignment.publishedVersion })
      .from(examAssignment)
      .where(
        and(
          eq(examAssignment.examPaperId, examPaperId),
          eq(examAssignment.status, 'published'),
        ),
      )
      .orderBy(desc(examAssignment.createdAt))
      .limit(1);

    if (!assignment) {
      return null;
    }

    const [row] = await this.db
      .select({
        id: examRecord.id,
        answers: examRecord.answers,
        status: examRecord.status,
        score: examRecord.score,
        correctRate: examRecord.correctRate,
        isPassed: examRecord.isPassed,
        lotteryDrawn: examRecord.lotteryDrawn,
      })
      .from(examRecord)
      .where(
        and(
          eq(examRecord.examPaperId, examPaperId),
          eq(examRecord.status, 'completed'),
          eq(examRecord.paperVersion, assignment.publishedVersion),
          sql`(${examRecord.examinee}).user_id = ${userId}`,
        ),
      );

    if (!row) {
      return null;
    }

    return {
      id: row.id,
      answers: (row.answers ?? {}) as Record<string, number | number[]>,
      status: row.status,
      score: row.score ?? undefined,
      correctRate: row.correctRate ?? undefined,
      isPassed: row.isPassed,
      hasLottery: row.lotteryDrawn,
    };
  }

  /**
   * Find the user's draft record for a paper.
   * Returns { id, answers, status } or null.
   */
  async findMyDraft(
    examPaperId: string,
    userId: string,
  ): Promise<ExamRecord | null> {
    const [assignment] = await this.db
      .select({ publishedVersion: examAssignment.publishedVersion })
      .from(examAssignment)
      .where(
        and(
          eq(examAssignment.examPaperId, examPaperId),
          eq(examAssignment.status, 'published'),
        ),
      )
      .orderBy(desc(examAssignment.createdAt))
      .limit(1);

    if (!assignment) {
      return null;
    }

    const [row] = await this.db
      .select({
        id: examRecord.id,
        answers: examRecord.answers,
        status: examRecord.status,
      })
      .from(examRecord)
      .where(
        and(
          eq(examRecord.examPaperId, examPaperId),
          eq(examRecord.status, 'draft'),
          eq(examRecord.paperVersion, assignment.publishedVersion),
          sql`(${examRecord.examinee}).user_id = ${userId}`,
        ),
      );

    if (!row) {
      return null;
    }

    return {
      id: row.id,
      answers: (row.answers ?? {}) as Record<string, number | number[]>,
      status: row.status,
    };
  }

  /**
   * Find the user's record for a paper (any status).
   */
  async findMyAnyRecord(
    examPaperId: string,
    userId: string,
  ): Promise<{ id: string; status: string } | null> {
    const [row] = await this.db
      .select({
        id: examRecord.id,
        status: examRecord.status,
      })
      .from(examRecord)
      .where(
        and(
          eq(examRecord.examPaperId, examPaperId),
          sql`(${examRecord.examinee}).user_id = ${userId}`,
        ),
      );

    return row ?? null;
  }

  /**
   * Save or update draft answers.
   * If a completed record exists, reset it to draft (for retake).
   */
  async saveDraft(
    examPaperId: string,
    answers: Record<string, number | number[]>,
    userId: string,
  ): Promise<{ success: boolean }> {
    const [paper] = await this.db
      .select({ version: examPaper.version })
      .from(examPaper)
      .where(eq(examPaper.id, examPaperId));
    const paperVersion = paper?.version ?? 1;

    const existing = await this.findMyAnyRecord(examPaperId, userId);

    if (existing) {
      await this.db
        .update(examRecord)
        .set({
          answers: answers as unknown as object,
          status: 'draft',
          score: null,
          correctRate: null,
          isPassed: false,
          paperVersion,
        })
        .where(eq(examRecord.id, existing.id));

      this.logger.log(
        `saveDraft: reset record id=${existing.id} to draft, paper=${examPaperId}, version=${paperVersion}, user=${userId}`,
      );
    } else {
      await this.db.insert(examRecord).values({
        examPaperId,
        examinee: userId,
        answers: answers as unknown as object,
        status: 'draft',
        paperVersion,
      });

      this.logger.log(
        `saveDraft: created new draft, paper=${examPaperId}, version=${paperVersion}, user=${userId}`,
      );
    }

    return { success: true };
  }

  /**
   * Submit exam: calculate score, mark as completed.
   * Allows re-submission to overwrite previous result (for retake).
   */
  async submit(
    examPaperId: string,
    answers: Record<string, number | number[]>,
    userId: string,
  ): Promise<SubmitExamResponse> {
    // 1. Get exam paper for questions and pass score
    const [paper] = await this.db
      .select({
        id: examPaper.id,
        questions: examPaper.questions,
        passScore: examPaper.passScore,
        version: examPaper.version,
      })
      .from(examPaper)
      .where(eq(examPaper.id, examPaperId));

    if (!paper) {
      throw new BadRequestException('试卷不存在');
    }

    // 2. Calculate score
    const questions = (paper.questions ?? []) as Question[];
    const useCustomScores = hasCustomScores(questions);
    const totalScore = getTotalScore(questions);
    let correctCount = 0;
    let earnedScore = 0;
    questions.forEach((q: Question, index: number) => {
      const userAnswer = answers[String(index)];
      if (userAnswer === undefined) return;

      const qType = q.type ?? 'single';
      let isCorrect = false;
      if (qType === 'multiple') {
        const correctArr = Array.isArray(q.correctAnswer)
          ? q.correctAnswer
          : [q.correctAnswer];
        const userArr = Array.isArray(userAnswer) ? userAnswer : [userAnswer];
        if (
          correctArr.length === userArr.length &&
          correctArr.every((a: number) => userArr.includes(a))
        ) {
          isCorrect = true;
        }
      } else {
        if (userAnswer === q.correctAnswer) {
          isCorrect = true;
        }
      }
      if (isCorrect) {
        correctCount++;
        if (useCustomScores) {
          earnedScore += q.score ?? 0;
        }
      }
    });

    const totalQuestions = questions.length;
    const rate = totalQuestions > 0 ? (correctCount / totalQuestions) * 100 : 0;
    const score = useCustomScores ? earnedScore : Math.round(rate);
    const correctRate = Math.round(rate * 10) / 10;
    const isPassed = score >= paper.passScore;

    // 3. Update existing record or insert new
    const existing = await this.findMyAnyRecord(examPaperId, userId);
    let recordId: string;

    if (existing) {
      const [updated] = await this.db
        .update(examRecord)
        .set({
          answers: answers as unknown as object,
          score,
          correctRate,
          isPassed,
          status: 'completed',
          paperVersion: paper.version,
        })
        .where(eq(examRecord.id, existing.id))
        .returning({ id: examRecord.id });
      recordId = updated.id;
    } else {
      const [inserted] = await this.db
        .insert(examRecord)
        .values({
          examPaperId,
          examinee: userId,
          answers: answers as unknown as object,
          score,
          correctRate,
          isPassed,
          status: 'completed',
          paperVersion: paper.version,
        })
        .returning({ id: examRecord.id });
      recordId = inserted.id;
    }

    this.logger.log(
      `submit: recordId=${recordId}, score=${score}, correctRate=${correctRate}, isPassed=${isPassed}, user=${userId}`,
    );

    return {
      examRecordId: recordId,
      score,
      totalScore,
      correctRate,
      isPassed,
      hasLottery: false,
    };
  }

  async remove(id: string): Promise<DeleteResponse> {
    this.logger.log(`Deleting exam record: ${id}`);

    const [deleted] = await this.db
      .delete(examRecord)
      .where(eq(examRecord.id, id))
      .returning({ id: examRecord.id });

    if (!deleted) {
      throw new NotFoundException('成绩记录不存在');
    }

    this.logger.log(`Exam record deleted: ${id}`);
    return { success: true };
  }
}
