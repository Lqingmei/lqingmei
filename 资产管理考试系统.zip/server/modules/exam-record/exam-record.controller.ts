import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Query,
  Req,
  Param,
  BadRequestException,
  ForbiddenException,
  UnauthorizedException,
} from '@nestjs/common';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';
import { ExamRecordService } from './exam-record.service';
import { isAdmin } from '@server/common/utils/admin-users';
import type { DraftExamRequest, SubmitExamRequest, DeleteResponse } from '@shared/api.interface';

interface UserContext {
  userId: string;
  tenantId: string;
  appId: string;
  env: 'preview' | 'runtime';
  userName?: string;
}

@Controller('api/exam-records')
export class ExamRecordController {
  constructor(private readonly examRecordService: ExamRecordService) {}

  /**
   * GET /api/exam-records/my?examPaperId=xxx
   * Returns completed record (with score/isPassed/hasLottery) if exists,
   * otherwise draft record (with answers for restoration), or null.
   */
  @NeedLogin()
  @Get('my')
  async getMyRecord(
    @Query('examPaperId') examPaperId: string,
    @Req() req: Request,
  ) {
    if (!examPaperId) {
      throw new BadRequestException('examPaperId is required');
    }

    const { userId } = req.userContext as unknown as UserContext;
    if (!userId) throw new UnauthorizedException('请先登录');

    // Check completed first
    const completed = await this.examRecordService.findMyRecord(
      examPaperId,
      userId,
    );
    if (completed) {
      return completed;
    }

    // Return draft (or null)
    return this.examRecordService.findMyDraft(examPaperId, userId);
  }

  /**
   * POST /api/exam-records/draft
   * Save or update draft answers.
   */
  @NeedLogin()
  @Post('draft')
  async saveDraft(@Body() body: DraftExamRequest, @Req() req: Request) {
    const { userId } = req.userContext as unknown as UserContext;
    if (!userId) throw new UnauthorizedException('请先登录');
    return this.examRecordService.saveDraft(
      body.examPaperId,
      body.answers,
      userId,
    );
  }

  /**
   * POST /api/exam-records/submit
   * Submit exam and get score result.
   */
  @NeedLogin()
  @Post('submit')
  async submit(@Body() body: SubmitExamRequest, @Req() req: Request) {
    const { userId } = req.userContext as unknown as UserContext;
    if (!userId) throw new UnauthorizedException('请先登录');
    return this.examRecordService.submit(
      body.examPaperId,
      body.answers,
      userId,
    );
  }

  @NeedLogin()
  @Delete(':id')
  async remove(
    @Param('id') id: string,
    @Req() req: Request,
  ): Promise<DeleteResponse> {
    const { userId } = req.userContext as unknown as UserContext;
    if (!isAdmin(userId)) {
      throw new ForbiddenException('仅管理员可删除成绩记录');
    }
    return this.examRecordService.remove(id);
  }
}
