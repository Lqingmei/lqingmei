import { Module } from '@nestjs/common';
import { ExamRecordController } from './exam-record.controller';
import { ExamRecordService } from './exam-record.service';

@Module({
  controllers: [ExamRecordController],
  providers: [ExamRecordService],
  exports: [ExamRecordService],
})
export class ExamRecordModule {}
