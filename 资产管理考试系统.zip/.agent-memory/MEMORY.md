# 项目记忆

## 抽奖防重复机制

- 现象：未中奖用户退出重新进入后可反复抽奖，直到中奖
- 根因：`lottery.service.ts` 的 `draw()` 未中奖时直接 return 不写记录，`hasLottery` 由查 `lottery_record` 表动态计算，未中奖时为 false
- 修复：`exam_record` 表加 `lottery_drawn` 布尔字段，抽奖时（无论中奖与否）事务内设为 true，`hasLottery` 改为读该字段
- 迁移：已有中奖记录需 `UPDATE exam_record SET lottery_drawn = true WHERE id IN (SELECT exam_record_id FROM lottery_record)`
