import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  GuestPapersResponse,
  GuestRecordResponse,
  SubmitExamResponse,
  DrawLotteryResponse,
  GuestDraftRequest,
  GuestSubmitRequest,
  GuestLotteryRequest,
} from '@shared/api.interface';

export const getGuestMyPapers = async (): Promise<GuestPapersResponse> => {
  const res = await axiosForBackend.get<GuestPapersResponse>(
    '/api/exam/guest/my-papers',
  );
  return res.data;
};

export const getGuestMyRecord = async (
  paperId: string,
): Promise<GuestRecordResponse> => {
  const res = await axiosForBackend.get<GuestRecordResponse>(
    '/api/exam/guest/my-record',
    { params: { paperId } },
  );
  return res.data;
};

export const guestSaveDraft = async (
  paperId: string,
  answers: Record<string, number | number[]>,
): Promise<{ success: boolean }> => {
  const body: GuestDraftRequest = { paperId, answers };
  const res = await axiosForBackend.post<{ success: boolean }>(
    '/api/exam/guest/draft',
    body,
  );
  return res.data;
};

export const guestSubmitExam = async (
  paperId: string,
  answers: Record<string, number | number[]>,
): Promise<SubmitExamResponse> => {
  const body: GuestSubmitRequest = { paperId, answers };
  const res = await axiosForBackend.post<SubmitExamResponse>(
    '/api/exam/guest/submit',
    body,
  );
  return res.data;
};

export const guestDrawLottery = async (
  examRecordId: string,
): Promise<DrawLotteryResponse> => {
  const body: GuestLotteryRequest = { examRecordId };
  const res = await axiosForBackend.post<DrawLotteryResponse>(
    '/api/exam/guest/lottery',
    body,
  );
  return res.data;
};
