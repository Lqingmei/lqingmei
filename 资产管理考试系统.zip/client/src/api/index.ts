import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';

export * as examPaperApi from './exam-paper';
export * as prizeApi from './prize';
export * as examRecordApi from './exam-record';
export * as lotteryApi from './lottery';
export * as statisticsApi from './statistics';
export * as examAssignmentApi from './exam-assignment';
export * as examRosterApi from './exam-roster';
export * as authApi from './auth';
export * as examGuestApi from './exam-guest';
export * as notificationTemplateApi from './notification-template';
