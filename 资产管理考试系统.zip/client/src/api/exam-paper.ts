import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  ExamPaperListResponse,
  ExamPaperDetail,
  CreateExamPaperRequest,
  UpdateExamPaperRequest,
} from '@shared/api.interface';

export const getExamPapers = async (
  page: number = 1,
  pageSize: number = 20,
): Promise<ExamPaperListResponse> => {
  const res = await axiosForBackend.get<ExamPaperListResponse>(
    '/api/exam-papers',
    { params: { page, pageSize } },
  );
  return res.data;
};

export const getExamPaperDetail = async (
  id: string,
): Promise<ExamPaperDetail> => {
  const res = await axiosForBackend.get<ExamPaperDetail>(
    `/api/exam-papers/${id}`,
  );
  return res.data;
};

export const createExamPaper = async (
  data: CreateExamPaperRequest,
): Promise<{ id: string }> => {
  const res = await axiosForBackend.post<{ id: string }>(
    '/api/exam-papers',
    data,
  );
  return res.data;
};

export const updateExamPaper = async (
  id: string,
  data: UpdateExamPaperRequest,
): Promise<{ success: boolean }> => {
  const res = await axiosForBackend.put<{ success: boolean }>(
    `/api/exam-papers/${id}`,
    data,
  );
  return res.data;
};

export const deleteExamPaper = async (
  id: string,
): Promise<{ success: boolean }> => {
  const res = await axiosForBackend.delete<{ success: boolean }>(
    `/api/exam-papers/${id}`,
  );
  return res.data;
};
