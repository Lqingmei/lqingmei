import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type { AuthMeResponse } from '@shared/api.interface';

export const getAuthMe = async (): Promise<AuthMeResponse> => {
  const res = await axiosForBackend.get<AuthMeResponse>('/api/auth/me');
  return res.data;
};
