import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type { ExamRecord, SubmitExamResponse, DeleteResponse } from '@shared/api.interface';

/**
 * Get current user's exam record for a paper.
 * Returns completed record (with score/isPassed/hasLottery) if exists,
 * otherwise draft record (with answers), or null.
 */
export const getMyExamRecord = async (
  examPaperId: string,
): Promise<ExamRecord | null> => {
  const res = await axiosForBackend.get<ExamRecord | null>(
    '/api/exam-records/my',
    { params: { examPaperId } },
  );
  return res.data;
};

/**
 * Save draft answers for a paper.
 */
export const saveDraft = async (
  examPaperId: string,
  answers: Record<string, number | number[]>,
): Promise<{ success: boolean }> => {
  const res = await axiosForBackend.post<{ success: boolean }>(
    '/api/exam-records/draft',
    { examPaperId, answers },
  );
  return res.data;
};

/**
 * Submit exam answers and get score result.
 */
export const submitExam = async (
  examPaperId: string,
  answers: Record<string, number | number[]>,
): Promise<SubmitExamResponse> => {
  const res = await axiosForBackend.post<SubmitExamResponse>(
    '/api/exam-records/submit',
    { examPaperId, answers },
  );
  return res.data;
};

export const deleteExamRecord = async (id: string): Promise<DeleteResponse> => {
  const res = await axiosForBackend.delete<DeleteResponse>(
    `/api/exam-records/${id}`,
  );
  return res.data;
};
