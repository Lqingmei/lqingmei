import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  Prize,
  PrizeListResponse,
  CreatePrizeRequest,
  UpdatePrizeRequest,
  DeleteResponse,
} from '@shared/api.interface';

export const getPrizes = async (): Promise<PrizeListResponse> => {
  const res = await axiosForBackend.get<PrizeListResponse>('/api/prizes');
  return res.data;
};

export const createPrize = async (
  data: CreatePrizeRequest,
): Promise<{ id: string }> => {
  const res = await axiosForBackend.post<{ id: string }>('/api/prizes', data);
  return res.data;
};

export const updatePrize = async (
  id: string,
  data: UpdatePrizeRequest,
): Promise<Prize> => {
  const res = await axiosForBackend.patch<Prize>(
    `/api/prizes/${id}`,
    data,
  );
  return res.data;
};

export const deletePrize = async (id: string): Promise<DeleteResponse> => {
  const res = await axiosForBackend.delete<DeleteResponse>(
    `/api/prizes/${id}`,
  );
  return res.data;
};
