import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  NotificationTemplate,
  UpdateNotificationTemplateRequest,
} from '@shared/api.interface';

export const getNotificationTemplate =
  async (): Promise<NotificationTemplate> => {
    const res = await axiosForBackend.get<NotificationTemplate>(
      '/api/notification-template',
    );
    return res.data;
  };

export const updateNotificationTemplate = async (
  data: UpdateNotificationTemplateRequest,
): Promise<NotificationTemplate> => {
  const res = await axiosForBackend.put<NotificationTemplate>(
    '/api/notification-template',
    data,
  );
  return res.data;
};
