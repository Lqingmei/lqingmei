import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  ExamRosterListResponse,
  SaveExamRosterRequest,
  SaveExamRosterResponse,
  UpdateExamRosterRequest,
  AddRosterItemRequest,
  RosterStatus,
} from '@shared/api.interface';

export const getRoster = async (): Promise<ExamRosterListResponse> => {
  const res = await axiosForBackend.get<ExamRosterListResponse>(
    '/api/exam-roster',
  );
  return res.data;
};

export const getResolvedRosterUsers = async (): Promise<{ userIds: string[] }> => {
  const res = await axiosForBackend.get<{ userIds: string[] }>(
    '/api/exam-roster/resolved',
  );
  return res.data;
};

export const addRosterItem = async (
  data: AddRosterItemRequest,
): Promise<ExamRosterListResponse['items'][number]> => {
  const res = await axiosForBackend.post<
    ExamRosterListResponse['items'][number]
  >('/api/exam-roster/item', data);
  return res.data;
};

export const saveRoster = async (
  items: { name: string; userId?: string; status: RosterStatus; center?: string }[],
): Promise<SaveExamRosterResponse> => {
  const res = await axiosForBackend.post<SaveExamRosterResponse>(
    '/api/exam-roster',
    { items } as SaveExamRosterRequest,
  );
  return res.data;
};

export const updateRosterItem = async (
  id: string,
  data: UpdateExamRosterRequest,
): Promise<ExamRosterListResponse['items'][number]> => {
  const res = await axiosForBackend.put<
    ExamRosterListResponse['items'][number]
  >(`/api/exam-roster/${id}`, data);
  return res.data;
};

export const deleteRosterItem = async (
  id: string,
): Promise<{ success: boolean }> => {
  const res = await axiosForBackend.delete<{ success: boolean }>(
    `/api/exam-roster/${id}`,
  );
  return res.data;
};

export const clearRoster = async (): Promise<{ success: boolean }> => {
  const res = await axiosForBackend.delete<{ success: boolean }>(
    '/api/exam-roster',
  );
  return res.data;
};
