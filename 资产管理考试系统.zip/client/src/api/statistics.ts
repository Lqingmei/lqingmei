import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  StatisticsOverview,
  ScoreDistributionResponse,
  StatisticsRecordsResponse,
  QuestionAnalysisResponse,
  AssignmentStatusResponse,
  CenterDinnerStatsResponse,
} from '@shared/api.interface';

export const getOverview = async (): Promise<StatisticsOverview> => {
  const res = await axiosForBackend.get<StatisticsOverview>(
    '/api/statistics/overview',
  );
  return res.data;
};

export const getScoreDistribution = async (): Promise<ScoreDistributionResponse> => {
  const res = await axiosForBackend.get<ScoreDistributionResponse>(
    '/api/statistics/score-distribution',
  );
  return res.data;
};

export interface GetRecordsParams {
  page: number;
  pageSize: number;
  keyword?: string;
  department?: string;
  startTime?: string;
  endTime?: string;
}

export const getRecords = async (
  params: GetRecordsParams,
): Promise<StatisticsRecordsResponse> => {
  const res = await axiosForBackend.get<StatisticsRecordsResponse>(
    '/api/statistics/records',
    { params },
  );
  return res.data;
};

export const getQuestionAnalysis = async (
  paperId: string,
): Promise<QuestionAnalysisResponse> => {
  const res = await axiosForBackend.get<QuestionAnalysisResponse>(
    '/api/statistics/question-analysis',
    { params: { paperId } },
  );
  return res.data;
};

export const getCenterDinnerStats = async (): Promise<CenterDinnerStatsResponse> => {
  const res = await axiosForBackend.get<CenterDinnerStatsResponse>(
    '/api/statistics/center-dinner',
  );
  return res.data;
};

export const getAssignmentStatus = async (
  paperId: string,
): Promise<AssignmentStatusResponse> => {
  const res = await axiosForBackend.get<AssignmentStatusResponse>(
    '/api/statistics/assignment-status',
    { params: { paperId } },
  );
  return res.data;
};
