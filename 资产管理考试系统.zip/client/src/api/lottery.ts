import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type { DrawLotteryResponse, LotteryConfig, UpdateLotteryConfigRequest } from '@shared/api.interface';

/**
 * Draw lottery for a completed exam record.
 * Returns existing prize if already drawn.
 */
export const drawLottery = async (
  examRecordId: string,
): Promise<DrawLotteryResponse> => {
  const res = await axiosForBackend.post<DrawLotteryResponse>(
    '/api/lottery/draw',
    { examRecordId },
  );
  return res.data;
};

export const getLotteryConfig = async (): Promise<LotteryConfig> => {
  const res = await axiosForBackend.get<LotteryConfig>('/api/lottery/config');
  return res.data;
};

export const updateLotteryConfig = async (
  data: UpdateLotteryConfigRequest,
): Promise<LotteryConfig> => {
  const res = await axiosForBackend.put<LotteryConfig>(
    '/api/lottery/config',
    data,
  );
  return res.data;
};
