import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  ExamAssignmentListResponse,
  ExamPaperListItem,
  CreateExamAssignmentRequest,
} from '@shared/api.interface';

export const getExamAssignments = async (): Promise<ExamAssignmentListResponse> => {
  const res = await axiosForBackend.get<ExamAssignmentListResponse>(
    '/api/exam-assignments',
  );
  return res.data;
};

export const getMyAssignedExams = async (): Promise<ExamPaperListItem[]> => {
  const res = await axiosForBackend.get<ExamPaperListItem[]>(
    '/api/exam-assignments/my',
  );
  return res.data;
};

export const publishExam = async (
  data: CreateExamAssignmentRequest,
): Promise<{ id: string }> => {
  const res = await axiosForBackend.post<{ id: string }>(
    '/api/exam-assignments',
    data,
  );
  return res.data;
};

export const removeExamAssignment = async (
  id: string,
): Promise<{ success: boolean }> => {
  const res = await axiosForBackend.delete<{ success: boolean }>(
    `/api/exam-assignments/${id}`,
  );
  return res.data;
};
