import React, { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useCurrentUserProfile } from '@lark-apaas/client-toolkit/hooks/useCurrentUserProfile';
import { useEffectiveAdmin } from '@client/src/hooks/useEffectiveAdmin';
import { authClient } from '@lark-apaas/client-toolkit/auth';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireAdmin?: boolean;
}

const AUTH_TIMEOUT_MS = 3000;

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  requireAdmin = true,
}) => {
  const { effectiveAdmin } = useEffectiveAdmin();
  const userInfo = useCurrentUserProfile();
  const [timedOut, setTimedOut] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setTimedOut(true), AUTH_TIMEOUT_MS);
    return () => clearTimeout(timer);
  }, []);

  const isLoggedIn = Boolean(userInfo?.user_id);
  const loading = !isLoggedIn && !timedOut;

  useEffect(() => {
    if (timedOut && !isLoggedIn) {
      authClient.session.redirectToLogin({ returnUrl: window.location.href });
    }
  }, [timedOut, isLoggedIn]);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="size-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!isLoggedIn) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="size-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (requireAdmin && !effectiveAdmin) {
    return <Navigate to="/exam" replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
