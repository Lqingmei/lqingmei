import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { FileText, Gift, ClipboardCheck, BarChart3, Menu, X, UserPlus, AlertCircle, Shield, User, Mail } from 'lucide-react';
import { useCurrentUserProfile } from '@lark-apaas/client-toolkit/hooks/useCurrentUserProfile';
import { authClient } from '@lark-apaas/client-toolkit/auth';
import { useEffectiveAdmin } from '@client/src/hooks/useEffectiveAdmin';
import { Image } from '@client/src/components/ui/image';

interface NavItem {
  path: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const ADMIN_NAV_ITEMS: NavItem[] = [
  { path: '/', label: '试卷管理', icon: FileText },
  { path: '/roster', label: '考试名单', icon: UserPlus },
  { path: '/reward-config', label: '奖励配置', icon: Gift },
  { path: '/exam', label: '答题考试', icon: ClipboardCheck },
  { path: '/statistics', label: '数据统计', icon: BarChart3 },
  { path: '/notification-template', label: '通知模版', icon: Mail },
];

const USER_NAV_ITEMS: NavItem[] = [
  { path: '/exam', label: '答题考试', icon: ClipboardCheck },
  { path: '/statistics', label: '数据统计', icon: BarChart3 },
];

const Layout: React.FC = () => {
  const userInfo = useCurrentUserProfile();
  const { effectiveAdmin, toggle, canToggle } = useEffectiveAdmin();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = effectiveAdmin ? ADMIN_NAV_ITEMS : USER_NAV_ITEMS;

  const isLoggedIn = Boolean(userInfo?.user_id);
  const displayName = isLoggedIn ? userInfo?.name : '游客';
  const avatarUrl = isLoggedIn
    ? userInfo?.avatar
    : 'https://lf3-static.bytednsdoc.com/obj/eden-cn/LMfspH/ljhwZthlaukjlkulzlp/miao/no-person.svg';

  const handleNavClick = () => setMobileOpen(false);

  const handleToggleView = () => {
    toggle();
    if (effectiveAdmin) {
      navigate('/exam');
    }
    setMobileOpen(false);
  };

  const ToggleButton: React.FC<{ className?: string }> = ({ className }) => (
    <button
      onClick={handleToggleView}
      className={`flex items-center gap-1.5 rounded-full border border-slate-300 px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900 ${className ?? ''}`}
    >
      {effectiveAdmin ? <Shield className="size-3" /> : <User className="size-3" />}
      <span>{effectiveAdmin ? '管理员视图' : '学员视图'}</span>
      <span className="text-slate-400">⇄</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full bg-white/90 backdrop-blur-md shadow-sm">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6 md:px-12">
          <div className="flex items-center gap-3">
            <span className="serif-font text-xl font-black tracking-widest text-slate-900">
              XP资产管理考试系统
            </span>
          </div>

          <nav className="hidden items-center gap-1 md:flex">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.path === '/'}
                  className={({ isActive }) =>
                    `flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                      isActive
                        ? 'bg-slate-900 text-white'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-blue-600'
                    }`
                  }
                >
                  <Icon className="size-4" />
                  <span>{item.label}</span>
                </NavLink>
              );
            })}
          </nav>

          <div className="hidden items-center gap-3 md:flex">
            {canToggle && <ToggleButton />}
            <div className="flex items-center gap-2">
              <Image
                src={avatarUrl}
                alt={displayName || '用户头像'}
                className="size-8 rounded-full object-cover border border-slate-200"
              />
              <span className="text-sm font-medium text-slate-700">
                {displayName}
              </span>
            </div>
          </div>

          <button
            className="flex items-center justify-center rounded-full p-2 text-slate-600 hover:bg-slate-100 md:hidden"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="切换菜单"
          >
            {mobileOpen ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>

        {mobileOpen && (
          <nav className="border-t border-slate-100 px-6 py-4 md:hidden">
            <div className="flex flex-col gap-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    end={item.path === '/'}
                    onClick={handleNavClick}
                    className={({ isActive }) =>
                      `flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-colors ${
                        isActive
                          ? 'bg-slate-900 text-white'
                          : 'text-slate-600 hover:bg-slate-100'
                      }`
                    }
                  >
                    <Icon className="size-4" />
                    <span>{item.label}</span>
                  </NavLink>
                );
              })}
            </div>
            <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4">
              <div className="flex items-center gap-2">
                <Image
                  src={avatarUrl}
                  alt={displayName || '用户头像'}
                  className="size-9 rounded-full object-cover border border-slate-200"
                />
                <span className="text-sm font-medium text-slate-700">
                  {displayName}
                </span>
              </div>
              {canToggle && <ToggleButton />}
            </div>
          </nav>
        )}
      </header>

      {!isLoggedIn && (
        <div className="flex items-center justify-center gap-3 bg-amber-50 px-8 py-2 text-center">
          <AlertCircle className="size-4 shrink-0 text-amber-600" />
          <span className="text-xs font-bold text-amber-800">
            当前为游客状态，请登录以获取完整功能
          </span>
          <button
            onClick={() => authClient.session.redirectToLogin({ returnUrl: window.location.href })}
            className="text-xs font-bold text-blue-600 underline hover:text-blue-700"
          >
            点击登录
          </button>
        </div>
      )}

      <main className="mx-auto max-w-7xl px-6 py-8 md:px-12">
        <Outlet />
      </main>
    </div>
  );
};

export default Layout;
