import React from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { ClipboardCheck, Shield, BarChart3 } from 'lucide-react';
import { useEffectiveAdmin } from '@client/src/hooks/useEffectiveAdmin';

const ExamLayout: React.FC = () => {
  const { canToggle, toggle, effectiveAdmin } = useEffectiveAdmin();
  const navigate = useNavigate();

  const handleBackToAdmin = () => {
    if (!effectiveAdmin) {
      toggle();
    }
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full bg-white/90 backdrop-blur-md shadow-sm">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6 md:px-12">
          <Link to="/" className="serif-font text-xl font-black tracking-widest text-slate-900 hover:text-blue-600 transition-colors">
            {'XP资产管理考试系统'}
          </Link>

          <nav className="flex items-center gap-2">
            {canToggle && !effectiveAdmin && (
              <button
                onClick={handleBackToAdmin}
                className="flex items-center gap-1.5 rounded-full border border-slate-300 px-4 py-2 text-xs font-bold uppercase tracking-wide text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900"
              >
                <Shield className="size-3.5" />
                <span>返回管理后台</span>
              </button>
            )}
            <NavLink
              to="/exam"
              className={({ isActive }) =>
                `flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-blue-600'
                }`
              }
            >
              <ClipboardCheck className="size-4" />
              <span className="hidden md:inline">答题考试</span>
            </NavLink>
            <NavLink
              to="/statistics"
              className={({ isActive }) =>
                `flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-blue-600'
                }`
              }
            >
              <BarChart3 className="size-4" />
              <span className="hidden md:inline">数据统计</span>
            </NavLink>
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-6 py-8 md:px-12">
        <Outlet />
      </main>
    </div>
  );
};

export default ExamLayout;
