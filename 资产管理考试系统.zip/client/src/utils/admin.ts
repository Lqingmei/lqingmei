export const ADMIN_USER_IDS: string[] = [
  '1841475341687899',
];

export function isAdmin(userId: string | undefined | null): boolean {
  return !!userId && ADMIN_USER_IDS.includes(userId);
}
