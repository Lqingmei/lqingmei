import { capabilityClient } from '@lark-apaas/client-toolkit';
import { resolveAppUrl } from '@lark-apaas/client-toolkit/utils/resolveAppUrl';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type { SendExamNotificationFeishuOneOutput } from '@shared/plugin-types';
import { getNotificationTemplate } from '@client/src/api/notification-template';

const DEFAULT_TITLE_TEMPLATE = '考试通知：{examName}';
const DEFAULT_DESCRIPTION_TEMPLATE =
  '您被分配参加考试**《{examName}》**，共 {questionCount} 道题目，及格分 {passScore} 分。\n\n请点击下方「开始考试」按钮进入答题界面。通过考试后可参与抽奖！';

function replacePlaceholders(
  template: string,
  examName: string,
  questionCount: number,
  passScore: number,
): string {
  return template
    .replace(/\{examName\}/g, examName)
    .replace(/\{questionCount\}/g, String(questionCount))
    .replace(/\{passScore\}/g, String(passScore));
}

function getPublicExamUrl(): string {
  return resolveAppUrl('/exam');
}

const BATCH_SIZE = 200;

export interface BatchSendResult {
  totalSent: number;
  totalFailed: number;
  failedBatches: number[];
}

export interface BatchSendProgress {
  current: number;
  total: number;
}

function chunkArray<T>(arr: T[], size: number): T[][] {
  const chunks: T[][] = [];
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size));
  }
  return chunks;
}

export async function batchSendExamNotifications(
  userIds: string[],
  examName: string,
  questionCount: number,
  passScore: number,
  onProgress?: (progress: BatchSendProgress) => void,
): Promise<BatchSendResult> {
  const batches = chunkArray(userIds, BATCH_SIZE);
  const totalBatches = batches.length;
  let totalSent = 0;
  let totalFailed = 0;
  const failedBatches: number[] = [];

  const examPageUrl = getPublicExamUrl();

  let titleTemplate = DEFAULT_TITLE_TEMPLATE;
  let descriptionTemplate = DEFAULT_DESCRIPTION_TEMPLATE;
  try {
    const tpl = await getNotificationTemplate();
    titleTemplate = tpl.titleTemplate || DEFAULT_TITLE_TEMPLATE;
    descriptionTemplate = tpl.descriptionTemplate || DEFAULT_DESCRIPTION_TEMPLATE;
  } catch {
    logger.warn('Failed to fetch notification template, using defaults');
  }

  const examTitle = replacePlaceholders(titleTemplate, examName, questionCount, passScore);
  const description = replacePlaceholders(descriptionTemplate, examName, questionCount, passScore);

  for (let i = 0; i < batches.length; i++) {
    const batch = batches[i];
    onProgress?.({ current: i + 1, total: totalBatches });

    try {
      const result = await capabilityClient
        .load('send_exam_notification_feishu_1')
        .call<SendExamNotificationFeishuOneOutput>('send_feishu_message', {
          receiver_user_list: batch,
          exam_name: examTitle,
          exam_description: description,
          exam_page_url: examPageUrl,
        });

      if (result?.success) {
        totalSent += batch.length;
      } else {
        totalFailed += batch.length;
        failedBatches.push(i + 1);
        logger.error('Feishu notification batch failed', {
          pluginInstanceId: 'send_exam_notification_feishu_1',
          actionKey: 'send_feishu_message',
          batchIndex: i + 1,
          batchSize: batch.length,
          result,
        });
      }
    } catch (err) {
      totalFailed += batch.length;
      failedBatches.push(i + 1);
      logger.error('Feishu notification batch error', {
        pluginInstanceId: 'send_exam_notification_feishu_1',
        actionKey: 'send_feishu_message',
        batchIndex: i + 1,
        batchSize: batch.length,
        error: err instanceof Error ? err.message : 'Unknown error',
      });
    }
  }

  return { totalSent, totalFailed, failedBatches };
}
