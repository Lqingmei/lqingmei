import { useCurrentUserProfile } from '@lark-apaas/client-toolkit/hooks/useCurrentUserProfile';
import { isAdmin } from '@client/src/utils/admin';

export function useIsAdmin(): boolean {
  const userInfo = useCurrentUserProfile();
  return isAdmin(userInfo?.user_id);
}
