import { useState, useCallback } from 'react';

const STORAGE_KEY = 'exam_view_mode';

export type ViewMode = 'admin' | 'user';

export function useViewMode(isAdmin: boolean) {
  const [viewMode, setViewMode] = useState<ViewMode>(
    () => (localStorage.getItem(STORAGE_KEY) as ViewMode | null) ?? 'admin',
  );

  const toggle = useCallback(() => {
    setViewMode((prev) => {
      const next: ViewMode = prev === 'admin' ? 'user' : 'admin';
      localStorage.setItem(STORAGE_KEY, next);
      return next;
    });
  }, []);

  const effective: ViewMode = isAdmin ? viewMode : 'user';

  return { viewMode: effective, toggle, canToggle: isAdmin };
}
