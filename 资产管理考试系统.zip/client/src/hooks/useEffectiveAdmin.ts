import { useIsAdmin } from './useIsAdmin';
import { useViewMode } from './useViewMode';

export function useEffectiveAdmin() {
  const isAdmin = useIsAdmin();
  const { viewMode, toggle, canToggle } = useViewMode(isAdmin);
  return {
    isAdmin,
    effectiveAdmin: isAdmin && viewMode === 'admin',
    toggle,
    canToggle,
  };
}
