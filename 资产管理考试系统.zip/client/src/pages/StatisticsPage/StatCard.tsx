import React from 'react';
import { ArrowUp, ArrowDown, type LucideIcon } from 'lucide-react';
import { Card } from '@client/src/components/ui/card';
import { cn } from '@/lib/utils';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: 'up' | 'down';
  trendLabel?: string;
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  icon: Icon,
  trend,
  trendLabel,
}) => {
  return (
    <Card data-ai-section-type="card-stat" className="rounded-3xl shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-300 p-6">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <p className="text-[9px] font-black uppercase tracking-tight text-muted-foreground">{title}</p>
          <p className="text-2xl font-bold text-foreground">{value}</p>
          {trend && trendLabel && (
            <p
              className={cn(
                'text-[10px] font-bold flex items-center gap-1',
                trend === 'up' ? 'text-success' : 'text-destructive',
              )}
            >
              {trend === 'up' ? (
                <ArrowUp className="w-3 h-3" />
              ) : (
                <ArrowDown className="w-3 h-3" />
              )}
              {trendLabel}
            </p>
          )}
        </div>
        <div className="h-10 w-10 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0">
          <Icon className="w-5 h-5 text-primary" />
        </div>
      </div>
    </Card>
  );
};

export default StatCard;
