import React, { useState } from 'react';
import { Trash2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@client/src/components/ui/alert-dialog';
import { deleteExamRecord } from '@client/src/api/exam-record';

const DELETE_BTN_CLASS =
  'bg-destructive text-white hover:bg-destructive/90 rounded-2xl';

interface RecordDeleteButtonProps {
  recordId: string;
  recordName: string;
  onDeleted: () => void;
}

const RecordDeleteButton: React.FC<RecordDeleteButtonProps> = ({
  recordId,
  recordName,
  onDeleted,
}) => {
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteExamRecord(recordId);
      toast.success('成绩已删除');
      setConfirmOpen(false);
      onDeleted();
    } catch (err) {
      logger.error(`删除成绩失败: ${String(err)}`);
      const msg =
        (err as { response?: { data?: { message?: string } } })
          .response?.data?.message ?? '删除成绩失败';
      toast.error(msg);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
      <AlertDialogTrigger asChild>
        <button
          className="flex h-7 w-7 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
          aria-label="删除成绩"
        >
          <Trash2 className="size-3.5" />
        </button>
      </AlertDialogTrigger>
      <AlertDialogContent className="rounded-3xl">
        <AlertDialogHeader>
          <AlertDialogTitle>确认删除成绩</AlertDialogTitle>
          <AlertDialogDescription>
            确定要删除「{recordName}」的考试成绩吗？关联的抽奖记录将一并删除，此操作不可撤销。
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>取消</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={deleting}
            className={DELETE_BTN_CLASS}
          >
            {deleting ? (
              <Loader2 className="size-4 animate-spin" />
            ) : null}
            确认删除
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default RecordDeleteButton;
