import React, { useState, useEffect, useCallback, useRef } from 'react';
import { toast } from 'sonner';
import dayjs from 'dayjs';
import { Users, TrendingUp, Award, Gift, RotateCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { getOverview, getScoreDistribution } from '@client/src/api/statistics';
import type {
  StatisticsOverview,
  ScoreDistributionResponse,
} from '@shared/api.interface';
import StatCard from './StatCard';
import ScoreChart from './ScoreChart';
import { useEffectiveAdmin } from '@client/src/hooks/useEffectiveAdmin';
import RecordsTable, { type RecordsTableRef } from './RecordsTable';
import QuestionAnalysis, { type QuestionAnalysisRef } from './QuestionAnalysis';
import AssignmentStatus, { type AssignmentStatusRef } from './AssignmentStatus';
import CenterDinnerStats, { type CenterDinnerStatsRef } from './CenterDinnerStats';

const POLL_INTERVAL: number = 15000;

interface StatisticsPageProps {
  isAdmin?: boolean;
}

const StatisticsPage: React.FC<StatisticsPageProps> = () => {
  const { effectiveAdmin } = useEffectiveAdmin();
  const [overview, setOverview] = useState<StatisticsOverview | null>(null);
  const [distribution, setDistribution] =
    useState<ScoreDistributionResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [lastRefreshTime, setLastRefreshTime] = useState<Date | null>(null);

  const recordsTableRef = useRef<RecordsTableRef>(null);
  const assignmentStatusRef = useRef<AssignmentStatusRef>(null);
  const questionAnalysisRef = useRef<QuestionAnalysisRef>(null);
  const centerDinnerRef = useRef<CenterDinnerStatsRef>(null);

  const fetchPageData = useCallback(async (): Promise<void> => {
    try {
      const [overviewRes, distRes] = await Promise.all([
        getOverview(),
        getScoreDistribution(),
      ]);
      setOverview(overviewRes);
      setDistribution(distRes);
      setLastRefreshTime(new Date());
    } catch {
      toast.error('获取统计数据失败');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  const refreshAll = useCallback((): void => {
    setRefreshing(true);
    void fetchPageData();
    recordsTableRef.current?.refresh();
    assignmentStatusRef.current?.refresh();
    questionAnalysisRef.current?.refresh();
    centerDinnerRef.current?.refresh();
  }, [fetchPageData]);

  useEffect(() => {
    void fetchPageData();
  }, [fetchPageData]);

  useEffect(() => {
    const interval = setInterval(() => {
      refreshAll();
    }, POLL_INTERVAL);
    return () => clearInterval(interval);
  }, [refreshAll]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 text-muted-foreground">
        加载中...
      </div>
    );
  }

  const passRate: number = overview?.passRate ?? 0;
  const passRateTrend: 'up' | 'down' = passRate >= 80 ? 'up' : 'down';
  const passRateTrendLabel: string =
    passRate >= 80 ? '高于平均' : '低于平均';

  return (
    <div className="space-y-6">
      {/* Refresh bar */}
      <div className="flex items-center justify-end gap-3">
        {lastRefreshTime && (
          <span className="text-xs font-black uppercase tracking-widest text-slate-600">
            上次更新 {dayjs(lastRefreshTime).format('HH:mm:ss')}
          </span>
        )}
        <Button
          variant="outline"
          size="sm"
          onClick={refreshAll}
          disabled={refreshing}
        >
          <RotateCw
            className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`}
          />
          刷新
        </Button>
      </div>

      {/* Stat cards */}
      <div
        className="grid grid-cols-2 md:grid-cols-4 gap-4"
        data-ai-section-type="card-list"
      >
        <StatCard
          title="参考人数"
          value={overview?.totalParticipants ?? 0}
          icon={Users}
        />
        <StatCard
          title="平均正确率(%)"
          value={overview?.averageScore ?? 0}
          icon={TrendingUp}
        />
        <StatCard
          title="通过率"
          value={`${passRate}%`}
          icon={Award}
          trend={passRateTrend}
          trendLabel={passRateTrendLabel}
        />
        <StatCard
          title="已发奖"
          value={overview?.awardedPrizes ?? 0}
          icon={Gift}
        />
      </div>

      {/* Score distribution chart */}
      <Card className="rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300">
        <CardHeader>
          <CardTitle className="serif-font">成绩分布</CardTitle>
        </CardHeader>
        <CardContent>
          <ScoreChart data={distribution} />
        </CardContent>
      </Card>

      {/* Center dinner stats */}
      <Card className="rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300">
        <CardHeader>
          <CardTitle className="serif-font">按所属中心分布</CardTitle>
        </CardHeader>
        <CardContent>
          <CenterDinnerStats ref={centerDinnerRef} isAdmin={effectiveAdmin} />
        </CardContent>
      </Card>

      {/* Assignment status */}
      <Card className="rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300">
        <CardHeader>
          <CardTitle className="serif-font">学员完成情况</CardTitle>
        </CardHeader>
        <CardContent>
          <AssignmentStatus ref={assignmentStatusRef} isAdmin={effectiveAdmin} />
        </CardContent>
      </Card>

      {/* Records table */}
      <Card className="rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300">
        <CardHeader>
          <CardTitle className="serif-font">成绩明细</CardTitle>
        </CardHeader>
        <CardContent>
          <RecordsTable ref={recordsTableRef} isAdmin={effectiveAdmin} />
        </CardContent>
      </Card>

      {/* Question analysis */}
      <Card className="rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300">
        <CardHeader>
          <CardTitle className="serif-font">题目分析</CardTitle>
        </CardHeader>
        <CardContent>
          <QuestionAnalysis ref={questionAnalysisRef} />
        </CardContent>
      </Card>
    </div>
  );
};

export default StatisticsPage;
