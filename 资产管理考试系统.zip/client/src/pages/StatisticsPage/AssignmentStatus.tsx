import React, { useState, useEffect, useCallback, forwardRef, useImperativeHandle } from 'react';
import { toast } from 'sonner';
import dayjs from 'dayjs';
import { Loader2, Users, CheckCircle2, Circle, TrendingUp, Download } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import { UserDisplay } from '@client/src/components/business-ui/user-display';
import * as XLSX from 'xlsx';
import { getExamAssignments } from '@client/src/api/exam-assignment';
import { getAssignmentStatus } from '@client/src/api/statistics';
import { listUsersByIds } from '@client/src/components/business-ui/api/users/service';
import { getI18nText } from '@client/src/components/business-ui/utils/user';
import type {
  ExamAssignmentListItem,
  AssignmentStatusResponse,
} from '@shared/api.interface';

export interface AssignmentStatusRef {
  refresh: () => void;
}

interface AssignmentStatusProps {
  isAdmin?: boolean;
}

const AssignmentStatus = forwardRef<AssignmentStatusRef, AssignmentStatusProps>(({ isAdmin = false }, ref) => {
  const [assignments, setAssignments] = useState<ExamAssignmentListItem[]>([]);
  const [selectedPaperId, setSelectedPaperId] = useState<string>('');
  const [statusData, setStatusData] = useState<AssignmentStatusResponse | null>(
    null,
  );
  const [loadingAssignments, setLoadingAssignments] = useState<boolean>(true);
  const [loadingStatus, setLoadingStatus] = useState<boolean>(false);
  const [exporting, setExporting] = useState<boolean>(false);

  useEffect(() => {
    const fetchAssignments = async (): Promise<void> => {
      try {
        const res = await getExamAssignments();
        const seen = new Set<string>();
        const deduped: ExamAssignmentListItem[] = [];
        for (const item of res.items) {
          if (!seen.has(item.examPaperId)) {
            seen.add(item.examPaperId);
            deduped.push(item);
          }
        }
        setAssignments(deduped);
      } catch {
        toast.error('加载已发布试卷列表失败');
      } finally {
        setLoadingAssignments(false);
      }
    };
    fetchAssignments();
  }, []);

  const fetchStatus = useCallback(async (paperId: string) => {
    if (!paperId) return;
    setLoadingStatus(true);
    try {
      const res = await getAssignmentStatus(paperId);
      setStatusData(res);
    } catch {
      toast.error('加载学员完成情况失败');
      setStatusData(null);
    } finally {
      setLoadingStatus(false);
    }
  }, []);

  useEffect(() => {
    if (selectedPaperId) {
      void fetchStatus(selectedPaperId);
    } else {
      setStatusData(null);
    }
  }, [selectedPaperId, fetchStatus]);

  useImperativeHandle(ref, () => ({
    refresh: () => {
      if (selectedPaperId) {
        void fetchStatus(selectedPaperId);
      }
    },
  }), [selectedPaperId, fetchStatus]);

  const handleExport = useCallback(async (): Promise<void> => {
    if (!statusData || statusData.items.length === 0) return;
    setExporting(true);
    try {
      const userIds = statusData.items.map((i) => i.userId);
      const userResp = await listUsersByIds(userIds);
      const userInfoMap = userResp?.data?.userInfoMap ?? {};
      const nameMap = new Map<string, string>();
      for (const uid of userIds) {
        const info = userInfoMap[uid];
        const name = info ? getI18nText(info.name) : '';
        nameMap.set(uid, name || uid);
      }

      const header = ['学员姓名', '所属中心', '状态', '分数', '是否通过', '提交时间'];
      const rows: (string | number)[][] = statusData.items.map((item) => [
        nameMap.get(item.userId) ?? item.userId,
        item.center ?? '',
        item.status === 'completed' ? '已答题' : '未作答',
        item.status === 'completed' ? (item.score ?? 0) : '',
        item.status === 'completed'
          ? item.isPassed
            ? '通过'
            : '未通过'
          : '',
        item.submittedAt
          ? dayjs(item.submittedAt).format('YYYY-MM-DD HH:mm')
          : '',
      ]);
      const aoa: (string | number)[][] = [header, ...rows];
      const ws = XLSX.utils.aoa_to_sheet(aoa);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, '学员完成情况');
      const dateStr = dayjs().format('YYYYMMDD');
      XLSX.writeFile(wb, `${statusData.paperName}_学员完成情况_${dateStr}.xlsx`);
    } catch {
      toast.error('导出失败');
    } finally {
      setExporting(false);
    }
  }, [statusData]);

  const summaryCards: {
    label: string;
    value: string | number;
    icon: React.ReactNode;
    color: string;
  }[] = [
    {
      label: '已分配学员',
      value: statusData?.totalAssigned ?? 0,
      icon: <Users className="size-4 text-muted-foreground" />,
      color: 'text-foreground',
    },
    {
      label: '已答题',
      value: statusData?.completedCount ?? 0,
      icon: <CheckCircle2 className="size-4 text-success" />,
      color: 'text-success',
    },
    {
      label: '未作答',
      value: statusData?.notAnsweredCount ?? 0,
      icon: <Circle className="size-4 text-muted-foreground" />,
      color: 'text-muted-foreground',
    },
    {
      label: '完成率',
      value: `${statusData?.completionRate ?? 0}%`,
      icon: <TrendingUp className="size-4 text-primary" />,
      color: 'text-primary',
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <span className="text-sm font-black uppercase tracking-wide text-foreground whitespace-nowrap">
          选择试卷
        </span>
        {loadingAssignments ? (
          <Loader2 className="size-4 animate-spin text-muted-foreground" />
        ) : (
          <Select value={selectedPaperId} onValueChange={setSelectedPaperId}>
            <SelectTrigger className="w-[300px] rounded-xl">
              <SelectValue placeholder="请选择已发布的试卷" />
            </SelectTrigger>
            <SelectContent>
              {assignments.map((a: ExamAssignmentListItem) => (
                <SelectItem key={a.id} value={a.examPaperId}>
                  {a.examPaperName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
        {isAdmin && statusData && statusData.items.length > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => void handleExport()}
            disabled={exporting}
            className="ml-auto rounded-xl"
          >
            {exporting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Download className="w-4 h-4" />
            )}
            导出Excel
          </Button>
        )}
      </div>

      {!selectedPaperId ? (
        <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
          <Users className="mb-3 size-10 text-muted-foreground/40" />
          <p className="text-sm font-bold uppercase tracking-wide">请选择已发布的试卷查看学员完成情况</p>
        </div>
      ) : loadingStatus ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="size-6 animate-spin text-primary" />
        </div>
      ) : statusData ? (
        <>
          <div
            className="grid grid-cols-2 md:grid-cols-4 gap-3"
            data-ai-section-type="card-stat"
          >
            {summaryCards.map((card) => (
              <Card key={card.label} className="rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300 p-6">
                <div className="flex items-center gap-2">
                  {card.icon}
                  <span className="text-xs font-black uppercase tracking-widest text-muted-foreground">
                    {card.label}
                  </span>
                </div>
                <p className={`mt-2 font-bold text-2xl ${card.color}`}>
                  {card.value}
                </p>
              </Card>
            ))}
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>学员</TableHead>
                <TableHead>所属中心</TableHead>
                <TableHead>状态</TableHead>
                <TableHead>分数</TableHead>
                <TableHead>是否通过</TableHead>
                <TableHead>提交时间</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {statusData.items.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={6}
                    className="text-center py-8 text-muted-foreground"
                  >
                    暂无分配学员
                  </TableCell>
                </TableRow>
              ) : (
                statusData.items.map((item, index: number) => (
                  <TableRow
                    key={item.userId}
                    className={index % 2 === 0 ? 'bg-muted/30' : ''}
                  >
                    <TableCell>
                      <UserDisplay value={[item.userId]} size="small" />
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {item.center || '—'}
                    </TableCell>
                    <TableCell>
                      {item.status === 'completed' ? (
                        <Badge variant="default" className="bg-green-600">
                          已答题
                        </Badge>
                      ) : (
                        <Badge variant="secondary">未作答</Badge>
                      )}
                    </TableCell>
                    <TableCell className="font-mono font-black">
                      {item.status === 'completed' ? item.score : '—'}
                    </TableCell>
                    <TableCell>
                      {item.status === 'completed' ? (
                        <Badge
                          variant={item.isPassed ? 'default' : 'destructive'}
                        >
                          {item.isPassed ? '通过' : '未通过'}
                        </Badge>
                      ) : (
                        '—'
                      )}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {item.submittedAt
                        ? dayjs(item.submittedAt).format('YYYY-MM-DD HH:mm')
                        : '—'}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </>
      ) : null}
    </div>
  );
});

export default AssignmentStatus;
