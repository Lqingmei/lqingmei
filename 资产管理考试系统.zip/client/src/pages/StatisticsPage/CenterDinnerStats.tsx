import React, { useState, useEffect, useCallback, forwardRef, useImperativeHandle } from 'react';
import { Loader2, Download } from 'lucide-react';
import * as XLSX from 'xlsx';
import dayjs from 'dayjs';
import { toast } from 'sonner';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { getCenterDinnerStats } from '@client/src/api/statistics';
import type { CenterDinnerStat } from '@shared/api.interface';

export interface CenterDinnerStatsRef {
  refresh: () => void;
}

interface CenterDinnerStatsProps {
  isAdmin?: boolean;
}

const CenterDinnerStats = forwardRef<CenterDinnerStatsRef, CenterDinnerStatsProps>(
  ({ isAdmin = false }, ref) => {
    const [items, setItems] = useState<CenterDinnerStat[]>([]);
    const [loading, setLoading] = useState<boolean>(false);

    const fetchData = useCallback(async (): Promise<void> => {
      setLoading(true);
      try {
        const res = await getCenterDinnerStats();
        setItems(res.items);
      } catch {
        setItems([]);
      } finally {
        setLoading(false);
      }
    }, []);

    useEffect(() => {
      void fetchData();
    }, [fetchData]);

    useImperativeHandle(ref, () => ({
      refresh: () => { void fetchData(); },
    }), [fetchData]);

    const totalRoster = items.reduce((sum: number, i: CenterDinnerStat) => sum + i.rosterCount, 0);
    const totalParticipant = items.reduce((sum: number, i: CenterDinnerStat) => sum + i.participantCount, 0);
    const totalPassed = items.reduce((sum: number, i: CenterDinnerStat) => sum + i.passedCount, 0);
    const totalWinner = items.reduce((sum: number, i: CenterDinnerStat) => sum + i.winnerCount, 0);
    const totalPassRate = totalRoster > 0
      ? Number(((totalPassed / totalRoster) * 100).toFixed(2))
      : 0;

    const handleExport = useCallback((): void => {
      if (items.length === 0) return;
      try {
        const header = ['所属中心', '名单人数', '参考人数', '通过人数', '中奖人数', '完成率%'];
        const rows: (string | number)[][] = items.map((item: CenterDinnerStat) => [
          item.center,
          item.rosterCount,
          item.participantCount,
          item.passedCount,
          item.winnerCount,
          item.passRate.toFixed(2),
        ]);
        rows.push(['合计', totalRoster, totalParticipant, totalPassed, totalWinner, totalPassRate.toFixed(2)]);
        const aoa: (string | number)[][] = [header, ...rows];
        const ws = XLSX.utils.aoa_to_sheet(aoa);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, '按所属中心分布');
        const dateStr = dayjs().format('YYYYMMDD');
        XLSX.writeFile(wb, `按所属中心分布_${dateStr}.xlsx`);
      } catch {
        toast.error('导出失败');
      }
    }, [items, totalRoster, totalParticipant, totalPassed, totalWinner, totalPassRate]);

    return (
      <div className="space-y-3">
        {isAdmin && items.length > 0 && (
          <div className="flex justify-end">
            <Button variant="outline" size="sm" onClick={handleExport}>
              <Download className="w-4 h-4" />
              导出 Excel
            </Button>
          </div>
        )}
        {loading ? (
          <div className="flex justify-center py-6">
            <Loader2 className="size-5 animate-spin text-muted-foreground" />
          </div>
        ) : items.length === 0 ? (
          <div className="py-6 text-center text-xs text-muted-foreground">
            暂无数据
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>所属中心</TableHead>
                <TableHead className="text-right">名单人数</TableHead>
                <TableHead className="text-right">参考人数</TableHead>
                <TableHead className="text-right">通过人数</TableHead>
                <TableHead className="text-right">中奖人数</TableHead>
                <TableHead className="text-right">完成率%</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((item: CenterDinnerStat, index: number) => (
                <TableRow key={item.center} className={index % 2 === 0 ? 'bg-muted/30' : ''}>
                  <TableCell className="font-bold">{item.center}</TableCell>
                  <TableCell className="text-right font-mono">{item.rosterCount}</TableCell>
                  <TableCell className="text-right font-mono">{item.participantCount}</TableCell>
                  <TableCell className="text-right font-mono">
                    <Badge variant={item.passedCount > 0 ? 'default' : 'secondary'}>
                      {item.passedCount}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    <span className={item.winnerCount > 0 ? 'font-black text-primary' : 'text-muted-foreground'}>
                      {item.winnerCount}
                    </span>
                  </TableCell>
                  <TableCell className="text-right font-mono">{item.passRate.toFixed(2)}%</TableCell>
                </TableRow>
              ))}
              <TableRow className="border-t-2 border-border">
                <TableCell className="font-black">合计</TableCell>
                <TableCell className="text-right font-mono font-black">{totalRoster}</TableCell>
                <TableCell className="text-right font-mono font-black">{totalParticipant}</TableCell>
                <TableCell className="text-right font-mono font-black">{totalPassed}</TableCell>
                <TableCell className="text-right font-mono font-black text-primary">{totalWinner}</TableCell>
                <TableCell className="text-right font-mono font-black">{totalPassRate.toFixed(2)}%</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        )}
      </div>
    );
  },
);

export default CenterDinnerStats;
