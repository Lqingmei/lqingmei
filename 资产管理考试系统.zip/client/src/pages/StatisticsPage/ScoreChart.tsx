import React from 'react';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import type { CallbackDataParams, TopLevelFormatterParams } from 'echarts/types/dist/shared';
import type { ScoreDistributionResponse } from '@shared/api.interface';

interface ScoreChartProps {
  data: ScoreDistributionResponse | null;
}

const BAR_COLORS: string[] = [
  '#0F172A',
  '#2563EB',
  '#60A5FA',
  '#BFDBFE',
  '#A3E635',
];

const ScoreChart: React.FC<ScoreChartProps> = ({ data }) => {
  const ranges: string[] =
    data?.distribution.map((d) => d.scoreRange) ?? [];
  const counts: number[] = data?.distribution.map((d) => d.count) ?? [];

  if (!data || data.distribution.length === 0) {
    return (
      <div className="h-[240px] flex items-center justify-center text-muted-foreground text-[11px] font-medium">
        暂无数据
      </div>
    );
  }

  const option: EChartsOption = {
    color: BAR_COLORS,
    textStyle: {
      fontFamily: 'Inter, sans-serif',
      color: '#94A3B8',
    },
    tooltip: {
      trigger: 'axis',
      backgroundColor: '#FFFFFF',
      borderColor: '#F1F5F9',
      borderWidth: 1,
      borderRadius: 8,
      padding: 12,
      textStyle: {
        fontFamily: 'Inter',
        color: '#1A1A1A',
        fontSize: 11,
        fontWeight: 700,
      },
      formatter: (params: TopLevelFormatterParams) => {
        const list = Array.isArray(params) ? params : [params];
        return list
          .map((p) => `${p.name}: ${p.value}人`)
          .join('<br/>');
      },
    },
    grid: {
      left: 0,
      right: 0,
      top: 20,
      bottom: 16,
      containLabel: true,
    },
    xAxis: {
      type: 'category',
      data: ranges,
      boundaryGap: true,
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: {
        color: '#94A3B8',
        fontSize: 9,
        fontWeight: 700,
        margin: 10,
      },
      splitLine: { show: false },
    },
    yAxis: {
      type: 'value',
      minInterval: 1,
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: { show: false },
      splitLine: {
        lineStyle: {
          color: '#F1F5F9',
          type: 'solid',
        },
      },
    },
    series: [
      {
        type: 'bar',
        data: counts,
        barWidth: 30,
        itemStyle: {
          color: (params: CallbackDataParams) => {
            return BAR_COLORS[params.dataIndex] ?? '#0F172A';
          },
          borderRadius: [6, 6, 0, 0],
        },
      },
    ],
  };

  return (
    <div className="w-full">
      <ReactECharts
        option={option}
        theme="ud"
        className="h-[240px]"
      />
    </div>
  );
};

export default ScoreChart;
