import React, { useState, useEffect, useCallback, forwardRef, useImperativeHandle } from 'react';
import { toast } from 'sonner';
import dayjs from 'dayjs';
import { Search, RotateCcw, ChevronLeft, ChevronRight } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import { Input } from '@client/src/components/ui/input';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import { Calendar } from '@client/src/components/ui/calendar';
import {
  Popover,
  PopoverTrigger,
  PopoverContent,
} from '@client/src/components/ui/popover';
import { UserDisplay } from '@client/src/components/business-ui/user-display';
import { getRecords } from '@client/src/api/statistics';
import type { StatisticsRecord } from '@shared/api.interface';
import RecordDeleteButton from './RecordDeleteButton';

const PAGE_SIZE: number = 10;

export interface RecordsTableRef {
  refresh: () => void;
}

interface RecordsTableProps {
  isAdmin?: boolean;
}

const RecordsTable = forwardRef<RecordsTableRef, RecordsTableProps>(({ isAdmin = false }, ref) => {
  const [records, setRecords] = useState<StatisticsRecord[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(false);

  const [inputKeyword, setInputKeyword] = useState<string>('');
  const [inputStartDate, setInputStartDate] = useState<
    Date | undefined
  >(undefined);
  const [inputEndDate, setInputEndDate] = useState<Date | undefined>(
    undefined,
  );

  const [appliedKeyword, setAppliedKeyword] = useState<string>('');
  const [appliedStartDate, setAppliedStartDate] = useState<
    Date | undefined
  >(undefined);
  const [appliedEndDate, setAppliedEndDate] = useState<
    Date | undefined
  >(undefined);

  const fetchRecords = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const res = await getRecords({
        page,
        pageSize: PAGE_SIZE,
        keyword: appliedKeyword || undefined,
        startTime: appliedStartDate
          ? dayjs(appliedStartDate).startOf('day').toISOString()
          : undefined,
        endTime: appliedEndDate
          ? dayjs(appliedEndDate).endOf('day').toISOString()
          : undefined,
      });
      setRecords(res.items);
      setTotal(res.total);
    } catch {
      toast.error('获取记录失败');
    } finally {
      setLoading(false);
    }
  }, [page, appliedKeyword, appliedStartDate, appliedEndDate]);

  useEffect(() => {
    void fetchRecords();
  }, [fetchRecords]);

  useImperativeHandle(ref, () => ({
    refresh: () => { void fetchRecords(); },
  }), [fetchRecords]);

  const handleSearch = (): void => {
    setPage(1);
    setAppliedKeyword(inputKeyword);
    setAppliedStartDate(inputStartDate);
    setAppliedEndDate(inputEndDate);
  };

  const handleReset = (): void => {
    setInputKeyword('');
    setInputStartDate(undefined);
    setInputEndDate(undefined);
    setPage(1);
    setAppliedKeyword('');
    setAppliedStartDate(undefined);
    setAppliedEndDate(undefined);
  };

  const totalPages: number = Math.ceil(total / PAGE_SIZE);

  return (
    <div className="space-y-4">
      {/* Filter area */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="搜索姓名"
            value={inputKeyword}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
              setInputKeyword(e.target.value)
            }
            onKeyDown={(e: React.KeyboardEvent) => {
              if (e.key === 'Enter') handleSearch();
            }}
            className="pl-9 rounded-xl"
          />
        </div>

        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="default" className="w-[150px] justify-start font-bold rounded-2xl">
              {inputStartDate
                ? dayjs(inputStartDate).format('YYYY-MM-DD')
                : '开始日期'}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={inputStartDate}
              onSelect={(date: Date | undefined) =>
                setInputStartDate(date)
              }
            />
          </PopoverContent>
        </Popover>

        <span className="text-muted-foreground text-sm">至</span>

        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="default" className="w-[150px] justify-start font-bold rounded-2xl">
              {inputEndDate
                ? dayjs(inputEndDate).format('YYYY-MM-DD')
                : '结束日期'}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={inputEndDate}
              onSelect={(date: Date | undefined) =>
                setInputEndDate(date)
              }
            />
          </PopoverContent>
        </Popover>

        <Button onClick={handleSearch} size="default" className="rounded-2xl">
          <Search className="w-4 h-4" />
          查询
        </Button>
        <Button onClick={handleReset} variant="outline" size="default" className="rounded-2xl">
          <RotateCcw className="w-4 h-4" />
          重置
        </Button>
      </div>

      {/* Table */}
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>姓名</TableHead>
            <TableHead>所属中心</TableHead>
            <TableHead>分数</TableHead>
            <TableHead>是否通过</TableHead>
            <TableHead>中奖奖品</TableHead>
            <TableHead>时间</TableHead>
            {isAdmin && <TableHead>操作</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {loading ? (
            <TableRow>
              <TableCell colSpan={isAdmin ? 7 : 6} className="text-center py-8 text-muted-foreground">
                加载中...
              </TableCell>
            </TableRow>
          ) : records.length === 0 ? (
            <TableRow>
              <TableCell colSpan={isAdmin ? 7 : 6} className="text-center py-8 text-muted-foreground">
                暂无数据
              </TableCell>
            </TableRow>
          ) : (
            records.map(
              (record: StatisticsRecord, index: number) => (
                <TableRow
                  key={record.id}
                  className={index % 2 === 0 ? 'bg-muted/30' : ''}
                >
                  <TableCell>
                    <UserDisplay
                      value={[record.userName]}
                      size="small"
                    />
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {record.center || '—'}
                  </TableCell>
                  <TableCell className="font-mono font-black">
                    {record.score}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        record.isPassed ? 'default' : 'destructive'
                      }
                    >
                      {record.isPassed ? '通过' : '未通过'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {record.prizeName || '—'}
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {dayjs(record.createdAt).format('YYYY-MM-DD HH:mm')}
                  </TableCell>
                  {isAdmin && (
                    <TableCell>
                      <RecordDeleteButton
                        recordId={record.id}
                        recordName={record.userName}
                        onDeleted={() => { void fetchRecords(); }}
                      />
                    </TableCell>
                  )}
                </TableRow>
              ),
            )
          )}
        </TableBody>
      </Table>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">
          共 {total} 条
        </span>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="rounded-xl"
            disabled={page <= 1 || loading}
            onClick={() => setPage(page - 1)}
          >
            <ChevronLeft className="w-4 h-4" />
            上一页
          </Button>
          <span className="text-sm text-muted-foreground min-w-[60px] text-center">
            {page} / {totalPages || 1}
          </span>
          <Button
            variant="outline"
            size="sm"
            className="rounded-xl"
            disabled={page >= totalPages || loading}
            onClick={() => setPage(page + 1)}
          >
            下一页
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
});

export default RecordsTable;
