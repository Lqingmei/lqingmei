import React, { useState, useEffect, useCallback, forwardRef, useImperativeHandle } from 'react';
import { toast } from 'sonner';
import { Loader2, BarChart3 } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { Progress } from '@client/src/components/ui/progress';
import { Badge } from '@client/src/components/ui/badge';
import { getExamPapers } from '@client/src/api/exam-paper';
import { getQuestionAnalysis } from '@client/src/api/statistics';
import type {
  ExamPaperListItem,
  QuestionAnalysisResponse,
} from '@shared/api.interface';

const TYPE_LABELS: Record<string, string> = {
  single: '单选题',
  multiple: '多选题',
  judge: '判断题',
};

export interface QuestionAnalysisRef {
  refresh: () => void;
}

const QuestionAnalysis = forwardRef<QuestionAnalysisRef>((_props, ref) => {
  const [papers, setPapers] = useState<ExamPaperListItem[]>([]);
  const [selectedPaperId, setSelectedPaperId] = useState<string>('');
  const [analysis, setAnalysis] = useState<QuestionAnalysisResponse | null>(
    null,
  );
  const [loadingPapers, setLoadingPapers] = useState<boolean>(true);
  const [loadingAnalysis, setLoadingAnalysis] = useState<boolean>(false);

  useEffect(() => {
    const fetchPapers = async (): Promise<void> => {
      try {
        const res = await getExamPapers();
        setPapers(res.items);
      } catch {
        toast.error('加载试卷列表失败');
      } finally {
        setLoadingPapers(false);
      }
    };
    fetchPapers();
  }, []);

  const fetchAnalysis = useCallback(async (paperId: string) => {
    if (!paperId) return;
    setLoadingAnalysis(true);
    try {
      const res = await getQuestionAnalysis(paperId);
      setAnalysis(res);
    } catch {
      toast.error('加载题目分析失败');
      setAnalysis(null);
    } finally {
      setLoadingAnalysis(false);
    }
  }, []);

  useEffect(() => {
    if (selectedPaperId) {
      void fetchAnalysis(selectedPaperId);
    }
  }, [selectedPaperId, fetchAnalysis]);

  useImperativeHandle(ref, () => ({
    refresh: () => {
      if (selectedPaperId) {
        void fetchAnalysis(selectedPaperId);
      }
    },
  }), [selectedPaperId, fetchAnalysis]);

  return (
    <div className="space-y-4">
      {/* Paper selector */}
      <div className="flex items-center gap-3">
        <span className="text-sm font-black uppercase tracking-wide text-foreground whitespace-nowrap">
          选择试卷
        </span>
        {loadingPapers ? (
          <Loader2 className="size-4 animate-spin text-muted-foreground" />
        ) : (
          <Select value={selectedPaperId} onValueChange={setSelectedPaperId}>
            <SelectTrigger className="w-[300px] rounded-xl">
              <SelectValue placeholder="请选择试卷" />
            </SelectTrigger>
            <SelectContent>
              {papers.map((paper: ExamPaperListItem) => (
                <SelectItem key={paper.id} value={paper.id}>
                  {paper.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Analysis content */}
      {!selectedPaperId ? (
        <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
          <BarChart3 className="mb-3 size-10 text-muted-foreground/40" />
          <p className="text-sm">请选择试卷查看题目分析</p>
        </div>
      ) : loadingAnalysis ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="size-6 animate-spin text-primary" />
        </div>
      ) : analysis ? (
        <div className="space-y-4">
          {/* Summary */}
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className="font-bold">参考人数: <span className="font-mono font-black text-foreground">{analysis.totalParticipants}</span></span>
            <span className="font-bold">题目数: <span className="font-mono font-black text-foreground">{analysis.questions.length}</span></span>
          </div>

          {/* Question stats table */}
          <div className="space-y-3">
            {analysis.questions.map((q, index: number) => {
              const rateColor =
                q.correctRate >= 80
                  ? 'text-green-600'
                  : q.correctRate >= 50
                    ? 'text-orange-500'
                    : 'text-red-500';
              const barColor =
                q.correctRate >= 80
                  ? 'bg-green-500'
                  : q.correctRate >= 50
                    ? 'bg-orange-500'
                    : 'bg-red-500';

              return (
                <div
                  key={index}
                  className="rounded-2xl border border-border bg-card p-4 shadow-sm"
                >
                  <div className="mb-2 flex items-start gap-2">
                    <span className="inline-block shrink-0 bg-primary/10 px-2 py-0.5 font-mono text-[10px] font-bold text-primary">
                      第 {q.index + 1} 题
                    </span>
                    <Badge variant="secondary" className="shrink-0 text-xs">
                      {TYPE_LABELS[q.type] ?? '单选题'}
                    </Badge>
                    <p className="min-w-0 flex-1 text-sm leading-relaxed text-foreground">
                      {q.title}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex-1">
                      <div className="relative h-2.5 w-full overflow-hidden rounded-full bg-muted">
                        <div
                          className={`h-full rounded-full transition-all ${barColor}`}
                          style={{ width: `${q.correctRate}%` }}
                        />
                      </div>
                    </div>
                    <span className={`font-mono text-sm font-bold ${rateColor}`}>
                      {q.correctRate}%
                    </span>
                    <span className="whitespace-nowrap text-xs text-muted-foreground">
                      {q.correctCount}/{q.totalAnswers} 正确
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : null}
    </div>
  );
});

export default QuestionAnalysis;
