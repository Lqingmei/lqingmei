import React, { useState, useEffect, useCallback } from 'react';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@client/src/components/ui/dialog';
import {
  Gift,
  Award,
  RotateCcw,
  Loader2,
  ChevronLeft,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import type {
  SubmitExamResponse,
  DrawLotteryResponse,
  Question,
} from '@shared/api.interface';
import { guestDrawLottery } from '@client/src/api/exam-guest';
import { Image } from '@client/src/components/ui/image';
import { QuestionReview } from './QuestionReview';

interface ExamResultProps {
  result: SubmitExamResponse;
  paperName: string;
  questions: Question[];
  answers: Record<string, number | number[]>;
  onBack: () => void;
  onRetake: () => void;
}

type LotteryPhase = 'idle' | 'spinning' | 'revealing' | 'done';

const CONFETTI_COLORS: string[] = [
  'hsl(217, 91%, 60%)',
  'hsl(35, 92%, 55%)',
  'hsl(142, 71%, 45%)',
  'hsl(45, 93%, 47%)',
];

const Confetti: React.FC = () => {
  const particles: number[] = Array.from({ length: 30 }, (_, i) => i);

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {particles.map((i: number) => {
        const left: number = Math.random() * 100;
        const delay: number = Math.random() * 0.5;
        const duration: number = 1.5 + Math.random() * 1.5;
        const color: string = CONFETTI_COLORS[i % CONFETTI_COLORS.length];
        const size: number = 8 + Math.random() * 8;

        return (
          <motion.div
            key={i}
            className="absolute rounded-sm"
            style={{
              left: `${left}%`,
              top: '-20px',
              width: `${size}px`,
              height: `${size}px`,
              backgroundColor: color,
            }}
            initial={{ y: 0, opacity: 1, rotate: 0 }}
            animate={{ y: '100vh', opacity: 0, rotate: 720 }}
            transition={{
              duration,
              delay,
              repeat: Infinity,
              ease: 'linear',
            }}
          />
        );
      })}
    </div>
  );
};

const ExamResult: React.FC<ExamResultProps> = ({
  result,
  paperName,
  questions,
  answers,
  onBack,
  onRetake,
}) => {
  const [lotteryPhase, setLotteryPhase] = useState<LotteryPhase>('idle');
  const [prize, setPrize] = useState<DrawLotteryResponse | null>(null);

  const { score, totalScore, correctRate, isPassed, hasLottery, examRecordId } = result;

  // If already drawn lottery, fetch existing prize on mount
  useEffect(() => {
    if (!hasLottery) return;

    setLotteryPhase('idle');
    guestDrawLottery(examRecordId)
      .then((res: DrawLotteryResponse) => {
        setPrize(res);
        setLotteryPhase('done');
      })
      .catch(() => {
        toast.error('获取奖品信息失败');
      });
  }, [hasLottery, examRecordId]);

  // Handle lottery draw button click
  const handleDraw = useCallback(async () => {
    setLotteryPhase('spinning');

    // Spin animation duration
    await new Promise<void>((resolve) => {
      setTimeout(resolve, 2000);
    });

    setLotteryPhase('revealing');

    try {
      const res = await guestDrawLottery(examRecordId);
      setPrize(res);

      // Brief reveal transition
      setTimeout(() => {
        setLotteryPhase('done');
      }, 500);
    } catch {
      toast.error('抽奖失败，请稍后重试');
      setLotteryPhase('idle');
    }
  }, [examRecordId]);

  return (
    <div className="relative mx-auto max-w-2xl">
      {/* Confetti for passed */}
      {score === totalScore && lotteryPhase !== 'spinning' && (
        <Confetti />
      )}

      {/* Back button */}
      <button
        onClick={onBack}
        className="mb-4 flex items-center gap-1 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
      >
        <ChevronLeft className="size-4" />
        返回选择
      </button>

      {/* Score card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: 'spring', stiffness: 200, damping: 20 }}
      >
        <Card className="relative rounded-3xl shadow-sm border border-slate-100">
          <CardContent className="p-8 text-center">
            {/* Score */}
            <div className="serif-font mb-2 text-5xl font-light text-foreground">
              {score}
              <span className="text-2xl font-bold text-muted-foreground">/{totalScore}分</span>
            </div>

            {/* Correct rate */}
            <p className="mb-1 text-sm font-medium text-muted-foreground">
              正确率: {correctRate}%
            </p>
            {/* Paper name */}
            <p className="mb-4 text-xs font-medium text-muted-foreground">
              {paperName}
            </p>

            {/* Pass/fail message */}
            <div className="mb-6 flex flex-col items-center gap-2">
              {score === totalScore ? (
                <Badge className="rounded-full bg-success text-success-foreground px-4 py-1.5 text-base">
                  🎉 满分通关！获得抽奖资格
                </Badge>
              ) : isPassed ? (
                <Badge className="rounded-full bg-success text-success-foreground px-4 py-1.5 text-base">
                  🎉 恭喜通关！
                </Badge>
              ) : (
                <Badge variant="destructive" className="rounded-full px-4 py-1.5 text-base">
                  再接再厉，继续加油
                </Badge>
              )}
              {isPassed && score < totalScore && (
                <p className="text-xs font-medium text-muted-foreground">
                  满分即可解锁抽奖资格
                </p>
              )}
            </div>

            {/* Review suggestions for failed */}
            {!isPassed && (
              <div className="mb-6 rounded-2xl border border-border bg-muted/50 p-4 text-left shadow-sm">
                <p className="mb-2 text-[11px] font-black uppercase tracking-[0.15em] text-blue-600">
                  复习建议
                </p>
                <ul className="space-y-1 text-xs font-medium text-muted-foreground">
                  <li>• 仔细回顾错题相关的知识点</li>
                  <li>• 查阅资产管理相关规章制度</li>
                  <li>• 与同学交流讨论薄弱环节</li>
                </ul>
              </div>
            )}

            {/* Lottery section - only for perfect score */}
            {score === totalScore && (
              <LotterySection
                lotteryPhase={lotteryPhase}
                prize={prize}
                onDraw={handleDraw}
              />
            )}

            {/* Retake button - only when score < 100 */}
            {score < totalScore && (
              <Button
                className="mt-4 w-full rounded-2xl"
                onClick={onRetake}
              >
                <RotateCcw className="size-4" />
                重新答题
              </Button>
            )}

            {/* Back to select */}
            <Button
              variant="outline"
              className="mt-2 w-full rounded-2xl"
              onClick={onBack}
            >
              返回试卷列表
            </Button>

            {/* Question review */}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="mt-2 w-full rounded-2xl">
                  题目回顾go
                </Button>
              </DialogTrigger>
              <DialogContent className="max-h-[80vh] overflow-y-auto max-w-2xl rounded-3xl">
                <DialogHeader>
                  <DialogTitle>答题回顾</DialogTitle>
                </DialogHeader>
                <QuestionReview questions={questions} answers={answers} />
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>
      </motion.div>

    </div>
  );
};

// ===== Lottery sub-component =====

interface LotterySectionProps {
  lotteryPhase: LotteryPhase;
  prize: DrawLotteryResponse | null;
  onDraw: () => void;
}

const LotterySection: React.FC<LotterySectionProps> = ({
  lotteryPhase,
  prize,
  onDraw,
}) => {
  // Idle: show draw button
  if (lotteryPhase === 'idle') {
    return (
      <div className="mb-4">
        <Button
          size="lg"
          className="w-full rounded-2xl"
          onClick={onDraw}
        >
          <Gift className="size-5" />
          点击抽奖
        </Button>
      </div>
    );
  }

  // Spinning: show spinning animation
  if (lotteryPhase === 'spinning') {
    return (
      <div className="mb-4 flex flex-col items-center py-4">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{
            duration: 0.6,
            repeat: Infinity,
            ease: 'linear',
          }}
        >
          <Gift className="size-16 text-primary" />
        </motion.div>
        <p className="mt-3 text-sm font-bold text-primary">
          正在抽奖中...
        </p>
      </div>
    );
  }

  // Revealing: brief transition
  if (lotteryPhase === 'revealing') {
    return (
      <div className="mb-4 flex flex-col items-center py-4">
        <Loader2 className="size-12 animate-spin text-primary" />
        <p className="mt-3 text-sm font-medium text-muted-foreground">
          揭晓中...
        </p>
      </div>
    );
  }

  // Done: show prize result
  if (lotteryPhase === 'done' && prize) {
    if (!prize.success) {
      return (
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, damping: 15 }}
            className="mb-4 rounded-2xl border border-border bg-muted/30 p-6 shadow-sm"
          >
            <div className="mb-2 flex justify-center">
              <div className="flex size-14 items-center justify-center rounded-2xl bg-muted shadow-sm">
                <Award className="size-7 text-muted-foreground" />
              </div>
            </div>
            <p className="mb-1 text-center text-xs font-medium text-muted-foreground">
              很遗憾，未中奖
            </p>
            <p className="text-center text-sm font-medium text-muted-foreground">
              感谢您的参与，下次再接再厉
            </p>
          </motion.div>
        </AnimatePresence>
      );
    }

    return (
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: 'spring', stiffness: 200, damping: 15 }}
            className="mb-4 rounded-2xl border border-border bg-accent/30 p-6 shadow-sm"
        >
          <p className="serif-font mb-1 text-center text-2xl font-light text-primary">
            🎁 恭喜获得
          </p>
          <p className="text-center text-lg font-extrabold text-foreground">
            {prize.prizeName}
          </p>
          {prize.prizeImage && (
            <div className="mt-3 flex justify-center">
              <Image
                src={prize.prizeImage}
                alt={prize.prizeName}
                width={120}
                height={120}
                className="object-cover shadow-sm rounded-2xl"
              />
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    );
  }

  return null;
};

export { ExamResult };
