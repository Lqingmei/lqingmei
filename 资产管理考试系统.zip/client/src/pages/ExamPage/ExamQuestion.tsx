import React from 'react';
import { Check } from 'lucide-react';
import { motion } from 'framer-motion';
import type { Question } from '@shared/api.interface';

interface ExamQuestionProps {
  question: Question;
  questionIndex: number;
  selectedAnswer: number | number[] | undefined;
  onAnswer: (optionIndex: number) => void;
}

const OPTION_LABELS: string[] = ['A', 'B', 'C', 'D', 'E', 'F'];

const TYPE_LABELS: Record<string, string> = {
  single: '单选题',
  multiple: '多选题',
  judge: '判断题',
};

const ExamQuestion: React.FC<ExamQuestionProps> = ({
  question,
  questionIndex,
  selectedAnswer,
  onAnswer,
}) => {
  const qType: string = question.type ?? 'single';
  const isMultiple: boolean = qType === 'multiple';

  return (
    <motion.div
      initial={{ opacity: 0, x: 30 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -30 }}
      transition={{ duration: 0.2 }}
    >
      {/* Question title */}
      <div className="mb-6">
        <div className="mb-2 flex items-center gap-2">
          <span className="inline-block rounded-full border border-border bg-muted px-2.5 py-1 text-[11px] font-black uppercase tracking-wide text-blue-600">
            第 {questionIndex + 1} 题
          </span>
          <span className="inline-block rounded-full border border-border bg-primary/5 px-2.5 py-1 text-[11px] font-black uppercase tracking-wide text-blue-600">
            {TYPE_LABELS[qType] ?? '单选题'}
          </span>
          {isMultiple && (
            <span className="text-xs font-medium text-muted-foreground">
              （可多选）
            </span>
          )}
        </div>
        <h2 className="text-xl font-bold leading-relaxed text-foreground">
          {question.title}
        </h2>
      </div>

      {/* Options */}
      <div className="space-y-3">
        {question.options.map(
          (option: string, index: number) => {
            const isSelected = isMultiple
              ? Array.isArray(selectedAnswer) && selectedAnswer.includes(index)
              : selectedAnswer === index;

            return (
              <button
                key={index}
                onClick={() => onAnswer(index)}
                className={`flex w-full items-center gap-3 rounded-2xl border border-border bg-white p-4 text-left text-foreground transition-all ${
                  isSelected
                    ? 'border-primary bg-primary/5'
                    : 'hover:border-primary/40'
                }`}
              >
                <span
                  className={`flex size-8 shrink-0 items-center justify-center rounded-lg font-mono text-sm font-black transition-colors ${
                    isSelected
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground'
                  }`}
                >
                  {isSelected ? (
                    <Check className="size-4" />
                  ) : (
                    OPTION_LABELS[index] ?? String(index + 1)
                  )}
                </span>
                <span className="text-sm font-medium leading-relaxed">
                  {option}
                </span>
              </button>
            );
          },
        )}
      </div>
    </motion.div>
  );
};

export { ExamQuestion };
