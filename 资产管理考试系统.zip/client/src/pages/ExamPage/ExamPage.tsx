import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Progress } from '@client/src/components/ui/progress';
import { Badge } from '@client/src/components/ui/badge';
import {
  ClipboardCheck,
  ChevronLeft,
  ChevronRight,
  Check,
  PartyPopper,
  Gift,
  Award,
  RotateCcw,
  Loader2,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import type {
  ExamPaperListItem,
  ExamPaperDetail,
  ExamRecord,
  SubmitExamResponse,
  DrawLotteryResponse,
  Question,
} from '@shared/api.interface';
import { getExamPapers, getExamPaperDetail } from '@client/src/api/exam-paper';
import {
  guestSaveDraft,
  guestSubmitExam,
} from '@client/src/api/exam-guest';
import { ExamPaperSelect } from './ExamPaperSelect';
import { ExamQuestion } from './ExamQuestion';
import { ExamResult } from './ExamResult';

type Phase = 'select' | 'exam' | 'result';

const ExamPage: React.FC = () => {
  const [phase, setPhase] = useState<Phase>('select');
  const [selectedPaper, setSelectedPaper] = useState<ExamPaperDetail | null>(
    null,
  );
  const [answers, setAnswers] = useState<Record<string, number | number[]>>({});
  const [currentQuestion, setCurrentQuestion] = useState<number>(0);
  const [submitResult, setSubmitResult] = useState<SubmitExamResponse | null>(
    null,
  );
  const [loadingPaper, setLoadingPaper] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);

  // Handle paper selection from the selection grid
  const handleSelectPaper = useCallback(
    async (paper: ExamPaperListItem, record: ExamRecord | null) => {
      setLoadingPaper(true);
      try {
        const detail = await getExamPaperDetail(paper.id);

        if (record && record.status === 'completed') {
          // Already completed — go straight to result with answers
          const paperQuestions = (detail.questions ?? []) as Question[];
          const hasCustomScores = paperQuestions.some(
            (q: Question) => q.score !== undefined && q.score > 0,
          );
          const computedTotalScore = hasCustomScores
            ? paperQuestions.reduce(
                (sum: number, q: Question) => sum + (q.score ?? 0),
                0,
              )
            : 100;
          setSubmitResult({
            examRecordId: record.id,
            score: record.score ?? 0,
            totalScore: computedTotalScore,
            correctRate: record.correctRate ?? 0,
            isPassed: record.isPassed ?? false,
            hasLottery: record.hasLottery ?? false,
          });
          setSelectedPaper(detail);
          setAnswers(record.answers ?? {});
          setPhase('result');
        } else {
          // Enter exam — restore draft answers if available
          setSelectedPaper(detail);
          setAnswers(record?.answers ?? {});
          setCurrentQuestion(0);
          setSubmitResult(null);
          setPhase('exam');
        }
      } catch {
        toast.error('加载试卷失败，请稍后重试');
      } finally {
        setLoadingPaper(false);
      }
    },
    [],
  );

  // Auto-save draft with 2s debounce
  useEffect(() => {
    if (phase !== 'exam' || !selectedPaper) return;
    if (Object.keys(answers).length === 0) return;

    const timer = setTimeout(() => {
      guestSaveDraft(selectedPaper.id, answers).catch(() => {
        // Silent fail — draft save is non-critical
      });
    }, 2000);

    return () => clearTimeout(timer);
  }, [answers, phase, selectedPaper]);

  // Handle answer selection
  const handleAnswer = useCallback((optionIndex: number) => {
    const question = selectedPaper?.questions[currentQuestion];
    if (!question) return;
    const qType = question.type ?? 'single';
    if (qType === 'multiple') {
      setAnswers((prev) => {
        const current = prev[String(currentQuestion)];
        const currentArr: number[] = Array.isArray(current) ? current : [];
        const newArr = currentArr.includes(optionIndex)
          ? currentArr.filter((i: number) => i !== optionIndex)
          : [...currentArr, optionIndex];
        return { ...prev, [String(currentQuestion)]: newArr };
      });
    } else {
      setAnswers((prev) => ({
        ...prev,
        [String(currentQuestion)]: optionIndex,
      }));
    }
  }, [currentQuestion, selectedPaper]);

  // Navigate to previous question
  const handlePrev = useCallback(() => {
    setCurrentQuestion((prev) => Math.max(0, prev - 1));
  }, []);

  // Navigate to next question
  const handleNext = useCallback(() => {
    if (!selectedPaper) return;
    setCurrentQuestion((prev) =>
      Math.min(selectedPaper.questions.length - 1, prev + 1),
    );
  }, [selectedPaper]);

  // Perform the actual submission
  const doSubmit = useCallback(async () => {
    if (!selectedPaper) return;

    setSubmitting(true);
    try {
      const result = await guestSubmitExam(selectedPaper.id, answers);
      setSubmitResult(result);
      setPhase('result');
    } catch {
      toast.error('提交试卷失败，请稍后重试');
    } finally {
      setSubmitting(false);
    }
  }, [selectedPaper, answers]);

  // Submit exam (with confirmation if unanswered questions remain)
  const handleSubmit = useCallback(async () => {
    if (!selectedPaper) return;

    const totalQuestions = selectedPaper.questions.length;
    const answeredCount = Object.values(answers).filter(
      (v: number | number[]) => Array.isArray(v) ? v.length > 0 : true,
    ).length;

    if (answeredCount < totalQuestions) {
      toast.warning(
        `还有 ${totalQuestions - answeredCount} 题未作答，确定要提交吗？`,
        {
          action: {
            label: '确定提交',
            onClick: () => {
              void doSubmit();
            },
          },
        },
      );
      return;
    }

    await doSubmit();
  }, [selectedPaper, answers, doSubmit]);

  // Retake exam: reset answers and go back to exam phase
  const handleRetake = useCallback(() => {
    if (!selectedPaper) return;
    setAnswers({});
    setCurrentQuestion(0);
    setSubmitResult(null);
    setPhase('exam');
    guestSaveDraft(selectedPaper.id, {}).catch(() => {
      // Silent fail — draft save is non-critical
    });
  }, [selectedPaper]);

  // Return to paper selection
  const handleBackToSelect = useCallback(() => {
    setPhase('select');
    setSelectedPaper(null);
    setAnswers({});
    setCurrentQuestion(0);
    setSubmitResult(null);
  }, []);

  // ===== Render =====

  if (phase === 'select') {
    return (
      <ExamPaperSelect
        onSelectPaper={handleSelectPaper}
        loading={loadingPaper}
      />
    );
  }

  if (phase === 'exam' && selectedPaper) {
    const questions: Question[] = selectedPaper.questions;
    const totalQuestions: number = questions.length;
    const currentQ: Question = questions[currentQuestion];
    const progressValue: number =
      totalQuestions > 0
        ? ((currentQuestion + 1) / totalQuestions) * 100
        : 0;
    const answeredCount: number = Object.values(answers).filter(
      (v: number | number[]) => Array.isArray(v) ? v.length > 0 : true,
    ).length;
    const isLast: boolean = currentQuestion === totalQuestions - 1;
    const isFirst: boolean = currentQuestion === 0;
    const selectedAnswer: number | number[] | undefined = answers[String(currentQuestion)];

    return (
      <div className="mx-auto max-w-2xl">
        {/* Header: paper name + progress */}
        <div className="mb-6">
          <div className="mb-3 flex items-center justify-between">
            <button
              onClick={handleBackToSelect}
              className="flex items-center gap-1 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              <ChevronLeft className="size-4" />
              返回选择
            </button>
            <span className="font-mono text-sm font-medium text-muted-foreground">
              已答 {answeredCount} / {totalQuestions} 题
            </span>
          </div>
          <h1 className="serif-font mb-3 text-2xl font-light tracking-tight text-foreground">
            {selectedPaper.name}
          </h1>
          <div className="flex items-center gap-3">
            <Progress value={progressValue} className="h-3" />
            <span className="shrink-0 font-mono text-sm font-bold text-primary">
              {currentQuestion + 1} / {totalQuestions}
            </span>
          </div>
        </div>

        {/* Question area */}
        <AnimatePresence mode="wait">
          <ExamQuestion
            key={currentQuestion}
            question={currentQ}
            questionIndex={currentQuestion}
            selectedAnswer={selectedAnswer}
            onAnswer={handleAnswer}
          />
        </AnimatePresence>

        {/* Navigation buttons */}
        <div className="mt-8 flex items-center justify-between">
            <Button
              variant="outline"
              className="rounded-2xl"
              onClick={handlePrev}
              disabled={isFirst}
            >
            <ChevronLeft className="size-4" />
            上一题
          </Button>

          {isLast ? (
            <Button
              className="rounded-2xl"
              onClick={handleSubmit}
              disabled={submitting}
            >
              {submitting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Check className="size-4" />
              )}
              提交试卷
            </Button>
          ) : (
            <Button className="rounded-2xl" onClick={handleNext}>
              下一题
              <ChevronRight className="size-4" />
            </Button>
          )}
        </div>
      </div>
    );
  }

  if (phase === 'result' && submitResult) {
    return (
      <ExamResult
        result={submitResult}
        paperName={selectedPaper?.name ?? ''}
        questions={selectedPaper?.questions ?? []}
        answers={answers}
        onBack={handleBackToSelect}
        onRetake={handleRetake}
      />
    );
  }

  return null;
};

export default ExamPage;
