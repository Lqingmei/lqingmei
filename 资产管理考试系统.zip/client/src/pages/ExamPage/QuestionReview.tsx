import React from 'react';
import { Check, X } from 'lucide-react';
import { Badge } from '@client/src/components/ui/badge';
import type { Question } from '@shared/api.interface';

interface QuestionReviewProps {
  questions: Question[];
  answers: Record<string, number | number[]>;
}

const OPTION_LABELS: string[] = ['A', 'B', 'C', 'D', 'E', 'F'];

const TYPE_LABELS: Record<string, string> = {
  single: '单选题',
  multiple: '多选题',
  judge: '判断题',
};

function isCorrect(
  question: Question,
  userAnswer: number | number[] | undefined,
): boolean {
  if (userAnswer === undefined) return false;
  const qType = question.type ?? 'single';
  if (qType === 'multiple') {
    const correctArr = Array.isArray(question.correctAnswer)
      ? question.correctAnswer
      : [question.correctAnswer];
    const userArr = Array.isArray(userAnswer) ? userAnswer : [userAnswer];
    return (
      correctArr.length === userArr.length &&
      correctArr.every((a: number) => userArr.includes(a))
    );
  }
  return userAnswer === question.correctAnswer;
}

function isOptionSelected(
  answer: number | number[] | undefined,
  index: number,
): boolean {
  if (answer === undefined) return false;
  if (Array.isArray(answer)) return answer.includes(index);
  return answer === index;
}

function isOptionCorrect(
  question: Question,
  index: number,
): boolean {
  const qType = question.type ?? 'single';
  if (qType === 'multiple') {
    const correctArr = Array.isArray(question.correctAnswer)
      ? question.correctAnswer
      : [question.correctAnswer];
    return correctArr.includes(index);
  }
  return question.correctAnswer === index;
}

const QuestionReview: React.FC<QuestionReviewProps> = ({
  questions,
  answers,
}) => {
  return (
    <div className="space-y-4">
      {questions.map((question: Question, index: number) => {
        const userAnswer = answers[String(index)];
        const correct = isCorrect(question, userAnswer);
        const qType = question.type ?? 'single';

        return (
          <div
            key={index}
            className={`rounded-2xl border border-border p-4 shadow-sm ${
              correct
                ? 'bg-success/10'
                : 'bg-destructive/10'
            }`}
          >
            {/* Question header */}
            <div className="mb-3 flex items-center gap-2">
              <span className="inline-block rounded-full border border-border bg-muted px-2.5 py-1 text-[11px] font-black uppercase tracking-wide text-blue-600">
                第 {index + 1} 题
              </span>
              <span className="inline-block rounded-full border border-border bg-primary/5 px-2.5 py-1 text-[11px] font-black uppercase tracking-wide text-blue-600">
                {TYPE_LABELS[qType] ?? '单选题'}
              </span>
              <Badge
                variant={correct ? 'default' : 'destructive'}
                className={`ml-auto rounded-full ${correct ? 'bg-success text-success-foreground' : ''}`}
              >
                {correct ? (
                  <>
                    <Check className="mr-1 size-3" />
                    正确
                  </>
                ) : (
                  <>
                    <X className="mr-1 size-3" />
                    错误
                  </>
                )}
              </Badge>
            </div>

            {/* Question title */}
            <p className="mb-3 text-sm font-medium leading-relaxed text-foreground">
              {question.title}
            </p>

            {/* Options */}
            <div className="space-y-2">
              {question.options.map((option: string, optIndex: number) => {
                const selected = isOptionSelected(userAnswer, optIndex);
                const isCorrectOption = isOptionCorrect(question, optIndex);

                let bgClass = 'bg-card';
                let labelClass = 'bg-muted text-muted-foreground';
                let icon: React.ReactNode = null;

                if (isCorrectOption) {
                  bgClass = 'bg-success/20';
                  labelClass = 'bg-success text-success-foreground';
                  icon = <Check className="size-4" />;
                } else if (selected) {
                  bgClass = 'bg-destructive/20';
                  labelClass = 'bg-destructive text-destructive-foreground';
                  icon = <X className="size-4" />;
                }

                return (
                  <div
                    key={optIndex}
                    className={`flex items-center gap-3 rounded-xl border border-border p-3 ${bgClass}`}
                  >
                    <span
                      className={`flex size-7 shrink-0 items-center justify-center rounded-lg font-mono text-xs font-black ${labelClass}`}
                    >
                      {icon ?? OPTION_LABELS[optIndex] ?? String(optIndex + 1)}
                    </span>
                    <span className="text-sm font-medium leading-relaxed text-foreground">
                      {option}
                    </span>
                    {isCorrectOption && (
                      <span className="ml-auto text-[9px] font-black uppercase tracking-wide text-success">
                        正确答案
                      </span>
                    )}
                    {selected && !isCorrectOption && (
                      <span className="ml-auto text-[9px] font-black uppercase tracking-wide text-destructive">
                        你的选择
                      </span>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Explanation */}
            {question.explanation && (
              <div className="mt-3 rounded-xl border border-blue-100 bg-blue-50/50 p-3">
                <span className="text-[11px] font-bold uppercase tracking-wide text-blue-600">解析</span>
                <p className="mt-1 text-sm font-medium leading-relaxed text-foreground">
                  {question.explanation}
                </p>
              </div>
            )}

            {/* Unanswered hint */}
            {userAnswer === undefined && (
              <p className="mt-2 text-xs font-medium text-muted-foreground">
                未作答
              </p>
            )}
          </div>
        );
      })}
    </div>
  );
};

export { QuestionReview };
