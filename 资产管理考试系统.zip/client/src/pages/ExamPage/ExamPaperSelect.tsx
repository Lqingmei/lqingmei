import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import {
  ClipboardCheck,
  Check,
  Loader2,
  FileText,
  LinkIcon,
} from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import type {
  ExamPaperListItem,
  ExamRecord,
} from '@shared/api.interface';
import { getGuestMyPapers } from '@client/src/api/exam-guest';
import { getGuestMyRecord } from '@client/src/api/exam-guest';

interface ExamPaperSelectProps {
  onSelectPaper: (
    paper: ExamPaperListItem,
    record: ExamRecord | null,
  ) => void;
  loading: boolean;
}

const ExamPaperSelect: React.FC<ExamPaperSelectProps> = ({
  onSelectPaper,
  loading,
}) => {
  const [papers, setPapers] = useState<ExamPaperListItem[]>([]);
  const [records, setRecords] = useState<Map<string, ExamRecord | null>>(
    new Map(),
  );
  const [fetching, setFetching] = useState<boolean>(true);
  const [notIdentified, setNotIdentified] = useState<boolean>(false);

  useEffect(() => {
    const fetchData = async () => {
      setFetching(true);
      try {
        const res = await getGuestMyPapers();
        if (!res.identified) {
          setNotIdentified(true);
          setFetching(false);
          return;
        }
        setPapers(res.items);

        const recordMap = new Map<string, ExamRecord | null>();
        await Promise.all(
          res.items.map(async (paper: ExamPaperListItem) => {
            try {
              const recordRes = await getGuestMyRecord(paper.id);
              recordMap.set(paper.id, recordRes.record);
            } catch {
              recordMap.set(paper.id, null);
            }
          }),
        );
        setRecords(recordMap);
      } catch {
        toast.error('加载考试列表失败');
      } finally {
        setFetching(false);
      }
    };

    void fetchData();
  }, []);

  const handleClick = (paper: ExamPaperListItem) => {
    if (loading) return;
    const record = records.get(paper.id) ?? null;
    onSelectPaper(paper, record);
  };

  if (fetching) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <Loader2 className="size-8 animate-spin text-primary" />
        <p className="mt-4 text-sm font-medium text-muted-foreground">
          正在加载试卷列表...
        </p>
      </div>
    );
  }

  if (notIdentified) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <LinkIcon className="size-12 text-muted-foreground/50" />
        <p className="mt-4 text-sm font-medium text-muted-foreground">
          请通过飞书通知中的链接进入考试
        </p>
      </div>
    );
  }

  if (papers.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <FileText className="size-12 text-muted-foreground/50" />
        <p className="mt-4 text-sm font-medium text-muted-foreground">
          暂无已分配给你的考试
        </p>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="serif-font flex items-center gap-2 text-2xl font-light tracking-tight text-foreground">
          <ClipboardCheck className="size-6 text-primary" />
          答题考试
        </h1>
        <p className="mt-1 text-sm font-medium text-muted-foreground">
          选择已发布的试卷开始答题，通过考试即可参与抽奖
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {papers.map((paper: ExamPaperListItem, index: number) => {
          const record = records.get(paper.id);
          const isCompleted = record?.status === 'completed';
          const isPassed = record?.isPassed === true;

          return (
            <motion.div
              key={paper.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              <Card
                className="rounded-3xl border border-slate-100 shadow-sm cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-2"
                onClick={() => handleClick(paper)}
              >
                <CardContent className="p-6">
                  <div className="mb-3 flex items-start justify-between gap-2">
                    <h3 className="line-clamp-2 text-base font-bold text-foreground">
                      {paper.name}
                    </h3>
                    {isCompleted && (
                      <Badge
                        variant={isPassed ? 'default' : 'destructive'}
                        className="shrink-0 rounded-full"
                      >
                        {isPassed ? '已通过' : '未通过'}
                      </Badge>
                    )}
                  </div>

                  <div className="mb-4 flex items-center gap-4 text-sm font-medium text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <FileText className="size-3.5" />
                      {paper.questionCount} 题
                    </span>
                    {isCompleted && record?.score !== undefined && (
                      <span className="font-mono font-bold text-foreground">
                        得分: {record.score}
                      </span>
                    )}
                  </div>

                  <Button
                    variant={isCompleted ? 'outline' : 'default'}
                    size="sm"
                    className="w-full rounded-2xl"
                    disabled={loading}
                  >
                    {isCompleted ? (
                      <>
                        <Check className="size-4" />
                        查看成绩
                      </>
                    ) : (
                      <>
                        <ClipboardCheck className="size-4" />
                        开始答题
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export { ExamPaperSelect };
