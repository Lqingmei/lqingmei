import React, { useState, useEffect, useCallback } from 'react';
import { Users, Loader2, Send, CheckCircle2, AlertCircle, UserSearch, X, ClipboardList } from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import { Button } from '@client/src/components/ui/button';
import { Label } from '@client/src/components/ui/label';
import { Badge } from '@client/src/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@client/src/components/ui/tabs';
import { UserSelect } from '@client/src/components/business-ui/user-select';
import { publishExam, getExamAssignments } from '@client/src/api/exam-assignment';
import { getExamPaperDetail } from '@client/src/api/exam-paper';
import { getResolvedRosterUsers, getRoster } from '@client/src/api/exam-roster';
import { batchSendExamNotifications } from '@client/src/utils/exam-notification';
import type { ExamPaperDetail } from '@shared/api.interface';
import { logger } from '@lark-apaas/client-toolkit/logger';

interface PublishDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  paperId: string | null;
  paperName: string;
  onPublished: () => void;
}

type PublishPhase = 'idle' | 'publishing' | 'notifying' | 'done';
type ImportMode = 'select' | 'roster';

const BATCH_SIZE = 200;

const PublishDialog: React.FC<PublishDialogProps> = ({
  open,
  onOpenChange,
  paperId,
  paperName,
  onPublished,
}) => {
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [paperDetail, setPaperDetail] = useState<ExamPaperDetail | null>(null);
  const [publishedVersion, setPublishedVersion] = useState<number | null>(null);
  const [loadingDetail, setLoadingDetail] = useState<boolean>(false);
  const [phase, setPhase] = useState<PublishPhase>('idle');
  const [notifyProgress, setNotifyProgress] = useState<{ current: number; total: number }>({ current: 0, total: 0 });
  const [sendResult, setSendResult] = useState<{ sent: number; failed: number } | null>(null);
  const [importMode, setImportMode] = useState<ImportMode>('select');
  const [rosterUserIds, setRosterUserIds] = useState<string[]>([]);
  const [rosterTotal, setRosterTotal] = useState<number>(0);
  const [rosterUnresolved, setRosterUnresolved] = useState<number>(0);
  const [loadingRoster, setLoadingRoster] = useState<boolean>(false);

  useEffect(() => {
    if (!open || !paperId) return;

    setSelectedUsers([]);
    setImportMode('select');
    setPhase('idle');
    setSendResult(null);
    setPublishedVersion(null);
    setLoadingDetail(true);

    Promise.all([
      getExamPaperDetail(paperId),
      getExamAssignments(),
    ])
      .then(([detail, assignments]) => {
        setPaperDetail(detail);
        const existing = assignments.items.find(
          (a) => a.examPaperId === paperId,
        );
        setPublishedVersion(existing?.publishedVersion ?? null);
      })
      .catch((err: unknown) => {
        toast.error('加载试卷信息失败');
        logger.error(err);
      })
      .finally(() => setLoadingDetail(false));
  }, [open, paperId]);

  const loadRoster = useCallback(async (): Promise<void> => {
    setLoadingRoster(true);
    try {
      const [resolved, all] = await Promise.all([
        getResolvedRosterUsers(),
        getRoster(),
      ]);
      setRosterUserIds(resolved.userIds);
      setRosterTotal(all.total);
      const unresolved = all.items.filter(
        (item) => item.status !== 'resolved',
      ).length;
      setRosterUnresolved(unresolved);
    } catch {
      toast.error('加载名单失败');
    } finally {
      setLoadingRoster(false);
    }
  }, []);

  const handleSwitchToRoster = (): void => {
    if (rosterTotal === 0 && !loadingRoster) {
      loadRoster();
    }
  };

  const handleSelectAllRoster = (): void => {
    setSelectedUsers(rosterUserIds);
    toast.success(`已选择名单中全部 ${rosterUserIds.length} 人`);
  };

  const handleClearUsers = (): void => {
    setSelectedUsers([]);
  };

  const handlePublish = async (): Promise<void> => {
    if (!paperId) return;
    if (selectedUsers.length === 0) {
      toast.error('请至少选择一名考试人员');
      return;
    }

    setPhase('publishing');
    try {
      await publishExam({
        examPaperId: paperId,
        assignedUsers: selectedUsers,
      });

      setPhase('notifying');
      const totalBatches = Math.ceil(selectedUsers.length / BATCH_SIZE);
      setNotifyProgress({ current: 0, total: totalBatches });

      const result = await batchSendExamNotifications(
        selectedUsers,
        paperName,
        paperDetail?.questionCount ?? 0,
        paperDetail?.passScore ?? 60,
        (progress) => setNotifyProgress(progress),
      );

      setSendResult({ sent: result.totalSent, failed: result.totalFailed });
      setPhase('done');

      if (result.totalFailed === 0) {
        toast.success(`考试已发布，飞书通知已发送给 ${result.totalSent} 人`);
      } else if (result.totalSent > 0) {
        toast.warning(`通知部分发送成功：${result.totalSent} 人已通知，${result.totalFailed} 人发送失败`);
      } else {
        toast.error('考试已发布，但飞书通知发送失败，请手动通知考生');
      }

      onPublished();
    } catch (err: unknown) {
      toast.error('发布失败');
      logger.error(err);
      setPhase('idle');
    }
  };

  const handleDone = (): void => {
    onOpenChange(false);
    setPhase('idle');
    setSendResult(null);
  };

  const isProcessing = phase === 'publishing' || phase === 'notifying';

  const getButtonText = (): string => {
    switch (phase) {
      case 'publishing': return '发布中...';
      case 'notifying': return `发送通知中 (${notifyProgress.current}/${notifyProgress.total})...`;
      case 'done': return '完成';
      default: return '发布考试';
    }
  };

  const handleDialogClose = (v: boolean): void => {
    if (!isProcessing) onOpenChange(v);
  };

  return (
    <Dialog open={open} onOpenChange={handleDialogClose}>
      <DialogContent className="max-w-2xl rounded-3xl">
        <DialogHeader>
          <DialogTitle className="serif-font">发布考试</DialogTitle>
        </DialogHeader>

        {loadingDetail ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="size-6 animate-spin text-primary" />
          </div>
        ) : phase === 'done' ? (
          <div className="space-y-4 py-4">
            <div className="flex flex-col items-center justify-center text-center">
              {sendResult && sendResult.failed === 0 ? (
                <>
                  <CheckCircle2 className="mb-3 size-12 text-success" />
                  <h3 className="text-lg font-bold text-foreground">发布成功</h3>
                  <p className="mt-2 text-sm font-medium text-muted-foreground">
                    考试已发布给 <span className="font-bold font-mono">{selectedUsers.length}</span> 名人员，飞书通知已全部发送成功
                  </p>
                </>
              ) : sendResult && sendResult.sent > 0 ? (
                <>
                  <AlertCircle className="mb-3 size-12 text-orange-500" />
                  <h3 className="text-lg font-bold text-foreground">部分成功</h3>
                  <p className="mt-2 text-sm font-medium text-muted-foreground">
                    考试已发布。通知发送：成功 <span className="font-bold font-mono">{sendResult.sent}</span> 人，失败 <span className="font-bold font-mono text-destructive">{sendResult.failed}</span> 人
                  </p>
                  <p className="mt-1 text-xs font-medium text-muted-foreground">
                    失败的考生请手动通知
                  </p>
                </>
              ) : (
                <>
                  <AlertCircle className="mb-3 size-12 text-destructive" />
                  <h3 className="text-lg font-bold text-foreground">通知发送失败</h3>
                  <p className="mt-2 text-sm font-medium text-muted-foreground">
                    考试已发布，但飞书通知发送失败，请手动通知考生
                  </p>
                </>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-5">
            <div className="rounded-2xl border border-border bg-muted/30 p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 shrink-0 flex items-center justify-center bg-primary/10 text-primary">
                  <Users className="size-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="truncate text-sm font-bold text-foreground">
                    {paperName}
                  </h3>
                  <div className="mt-1 flex items-center gap-2">
                    {paperDetail && (
                      <>
                        <Badge variant="secondary" className="rounded-full text-xs">
                          {paperDetail.questionCount} 题
                        </Badge>
                        <Badge variant="secondary" className="rounded-full text-xs">
                          及格分 {paperDetail.passScore}
                        </Badge>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {paperDetail && publishedVersion !== null && paperDetail.version > publishedVersion && (
              <div className="flex items-start gap-2.5 rounded-xl border border-border bg-orange-50 p-3">
                <AlertCircle className="mt-0.5 size-4 shrink-0 text-orange-500" />
                <p className="text-sm font-medium text-orange-700">
                  试卷内容已变更，重新发布后所有已完成的学员需要重新考试
                </p>
              </div>
            )}

            <Tabs
              value={importMode}
              onValueChange={(v) => {
                setImportMode(v as ImportMode);
                if (v === 'roster') handleSwitchToRoster();
              }}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="select" className="gap-1.5">
                  <UserSearch className="size-4" />
                  从通讯录选择
                </TabsTrigger>
                <TabsTrigger value="roster" className="gap-1.5">
                  <ClipboardList className="size-4" />
                  从名单导入
                </TabsTrigger>
              </TabsList>

              <TabsContent value="select" className="space-y-3 pt-2">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                      选择考试人员 <span className="text-destructive">*</span>
                    </Label>
                    {selectedUsers.length > 0 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleClearUsers}
                        className="h-auto px-2 py-1 text-xs font-medium text-destructive"
                      >
                        <X className="mr-1 size-3" />
                        清空 ({selectedUsers.length})
                      </Button>
                    )}
                  </div>
                  <p className="text-xs font-medium text-muted-foreground">
                    从飞书通讯录中选择需要参加考试的人员，支持批量选择
                  </p>
                  <UserSelect
                    multiple
                    value={selectedUsers}
                    onChange={setSelectedUsers}
                    placeholder="点击选择考试人员"
                    triggerType="button"
                  />
                  {selectedUsers.length > 0 && (
                    <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                      <span>已选择 {selectedUsers.length} 人</span>
                      {selectedUsers.length > BATCH_SIZE && (
                        <Badge variant="outline" className="rounded-full text-xs">
                          将分 {Math.ceil(selectedUsers.length / BATCH_SIZE)} 批发送通知
                        </Badge>
                      )}
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="roster" className="space-y-3 pt-2">
                {loadingRoster ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="size-6 animate-spin text-primary" />
                    <span className="ml-2 text-sm font-medium text-muted-foreground">加载名单中...</span>
                  </div>
                ) : rosterTotal === 0 ? (
                  <div className="rounded-3xl border border-dashed border-border p-8 text-center">
                    <ClipboardList className="mx-auto mb-3 size-10 text-muted-foreground/40" />
                    <p className="text-sm font-medium text-muted-foreground">
                      名单为空，请先在「考试名单」页面导入名单
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-3 rounded-2xl"
                      onClick={loadRoster}
                    >
                      重新加载
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">从名单导入</Label>
                        <p className="mt-1 text-xs font-medium text-muted-foreground">
                          已匹配 <span className="font-bold font-mono">{rosterUserIds.length}</span> 人
                          {rosterUnresolved > 0 && (
                            <span className="font-bold text-orange-500">
                              ，<span className="font-mono">{rosterUnresolved}</span> 人未匹配
                            </span>
                          )}
                        </p>
                      </div>
                      <Button size="sm" onClick={handleSelectAllRoster} className="rounded-2xl">
                        一键全选
                      </Button>
                    </div>

                    {rosterUnresolved > 0 && (
                      <div className="flex items-start gap-2 rounded-xl border border-border bg-orange-50 p-3">
                        <AlertCircle className="mt-0.5 size-4 shrink-0 text-orange-500" />
                        <p className="text-xs font-medium text-orange-700">
                          名单中有 {rosterUnresolved} 人未匹配飞书通讯录，无法接收飞书通知。请前往「考试名单」页面手动补匹配后再发布。
                        </p>
                      </div>
                    )}

                    {selectedUsers.length > 0 && (
                      <div className="rounded-2xl border border-border bg-muted/30 p-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="size-4 text-success" />
                            <span className="text-sm font-bold">
                              已选择 {selectedUsers.length} 人
                            </span>
                            {selectedUsers.length > BATCH_SIZE && (
                              <Badge variant="outline" className="rounded-full text-xs">
                                将分 {Math.ceil(selectedUsers.length / BATCH_SIZE)} 批发送
                              </Badge>
                            )}
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={handleClearUsers}
                            className="h-auto px-2 py-1 text-xs font-medium text-destructive"
                          >
                            <X className="mr-1 size-3" />
                            清空
                          </Button>
                        </div>
                      </div>
                    )}

                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={loadRoster}
                      className="text-xs font-medium text-muted-foreground"
                    >
                      刷新名单
                    </Button>
                  </div>
                )}
              </TabsContent>
            </Tabs>

            {isProcessing && (
              <div className="flex items-center gap-2 rounded-2xl border border-border bg-muted/30 p-3">
                <Loader2 className="size-4 animate-spin text-primary" />
                <span className="text-sm font-medium text-muted-foreground">
                  {phase === 'publishing' ? '正在保存考试发布信息...' : `正在发送飞书通知 (${notifyProgress.current}/${notifyProgress.total})...`}
                </span>
              </div>
            )}
          </div>
        )}

        <DialogFooter>
          {phase === 'done' ? (
            <Button onClick={handleDone} className="w-full rounded-2xl">
              完成
            </Button>
          ) : (
            <>
              <Button
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isProcessing}
                className="rounded-2xl"
              >
                取消
              </Button>
              <Button
                onClick={handlePublish}
                disabled={isProcessing || loadingDetail || selectedUsers.length === 0}
                className="rounded-2xl"
              >
                {isProcessing ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Send className="size-4" />
                )}
                {getButtonText()}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default PublishDialog;
