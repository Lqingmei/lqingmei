import React, { useState, useEffect, useCallback } from 'react';
import { Plus, FileText, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@client/src/components/ui/button';
import ExamPaperCard from './ExamPaperCard';
import ExamPaperEditDialog from './ExamPaperEditDialog';
import PublishDialog from './PublishDialog';
import {
  getExamPapers,
  deleteExamPaper,
} from '@client/src/api/exam-paper';
import type { ExamPaperListItem } from '@shared/api.interface';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { showConfirm } from '@lark-apaas/client-toolkit';

const ExamPaperPage: React.FC = () => {
  const [papers, setPapers] = useState<ExamPaperListItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [publishOpen, setPublishOpen] = useState<boolean>(false);
  const [publishPaperId, setPublishPaperId] = useState<string | null>(null);
  const [publishPaperName, setPublishPaperName] = useState<string>('');

  const fetchPapers = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getExamPapers(1, 100);
      setPapers(res.items);
    } catch (err: unknown) {
      toast.error('加载试卷列表失败');
      // eslint-disable-next-line no-console
      logger.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPapers();
  }, [fetchPapers]);

  const handleCreate = (): void => {
    setEditId(null);
    setDialogOpen(true);
  };

  const handleEdit = (id: string): void => {
    setEditId(id);
    setDialogOpen(true);
  };

  const handleDelete = async (id: string): Promise<void> => {
    if (!await showConfirm('确定删除该试卷吗？')) return;
    try {
      await deleteExamPaper(id);
      toast.success('试卷已删除');
      fetchPapers();
    } catch (err: unknown) {
      const msg =
        (err as { response?: { data?: { error?: { message?: string } } } })
          .response?.data?.error?.message ?? '删除失败';
      toast.error(msg);
      logger.error(err);
    }
  };

  const handleSaved = (): void => {
    fetchPapers();
  };

  const handlePublish = (id: string, name: string): void => {
    setPublishPaperId(id);
    setPublishPaperName(name);
    setPublishOpen(true);
  };

  return (
    <div className="space-y-6 px-6 md:px-12">
      {/* 顶部操作栏 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="flex items-center gap-2 serif-font text-3xl font-light text-foreground">
            <FileText className="size-5 text-primary" />
            试卷管理
          </h1>
          <p className="mt-1 text-sm font-medium text-muted-foreground">
            管理考试试卷，创建和编辑题目
          </p>
        </div>
        <Button onClick={handleCreate} className="gap-1.5 rounded-2xl">
          <Plus className="size-4" />
          新建试卷
        </Button>
      </div>

      {/* 内容区 */}
      {loading ? (
        <div className="flex items-center justify-center py-24">
          <Loader2 className="size-6 animate-spin text-primary" />
        </div>
      ) : papers.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-border bg-white shadow-sm p-12">
          <FileText className="mb-3 size-10 text-muted-foreground" />
          <p className="text-base font-medium text-foreground">暂无试卷</p>
          <p className="mt-1 text-sm font-medium text-muted-foreground">
            点击「新建试卷」创建第一份试卷
          </p>
          <Button onClick={handleCreate} className="mt-4 gap-1.5 rounded-2xl">
            <Plus className="size-4" />
            新建试卷
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {papers.map((paper: ExamPaperListItem) => (
            <ExamPaperCard
              key={paper.id}
              paper={paper}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onPublish={handlePublish}
            />
          ))}
        </div>
      )}

      <ExamPaperEditDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        editId={editId}
        onSaved={handleSaved}
      />

      <PublishDialog
        open={publishOpen}
        onOpenChange={setPublishOpen}
        paperId={publishPaperId}
        paperName={publishPaperName}
        onPublished={() => {}}
      />
    </div>
  );
};

export default ExamPaperPage;
