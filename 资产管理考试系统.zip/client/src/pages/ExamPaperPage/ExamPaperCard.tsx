import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Pencil, Trash2, Check, Send } from 'lucide-react';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import type { ExamPaperListItem } from '@shared/api.interface';
import dayjs from 'dayjs';

interface ExamPaperCardProps {
  paper: ExamPaperListItem;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
  onPublish: (id: string, name: string) => void;
}

const ExamPaperCard: React.FC<ExamPaperCardProps> = ({
  paper,
  onEdit,
  onDelete,
  onPublish,
}) => {
  const handleEdit = (): void => {
    onEdit(paper.id);
  };

  const handlePublish = (): void => {
    onPublish(paper.id, paper.name);
  };

  const handleDelete = (): void => {
    onDelete(paper.id);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: 'easeOut' }}
      className="group relative"
    >
      <Card className="rounded-3xl border border-slate-100 shadow-sm transition-all duration-300 hover:shadow-xl hover:-translate-y-2">
        <CardContent className="p-8">
          <div className="flex items-start gap-3">
            <div className="h-10 w-10 shrink-0 flex items-center justify-center bg-primary/10 text-primary">
              <FileText className="size-5" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="truncate text-sm font-bold text-foreground">
                {paper.name}
              </h3>
              <p className="mt-1 text-sm font-medium text-muted-foreground">
                <span className="font-bold font-mono">{paper.questionCount}</span> 道题目
              </p>
            </div>
          </div>

          <div className="mt-4 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <Check className="size-3.5 text-primary" />
            <span>更新于 {dayjs(paper.updatedAt).format('YYYY-MM-DD HH:mm')}</span>
          </div>

          <div className="mt-4 flex items-center gap-2 opacity-0 transition-opacity group-hover:opacity-100">
            <Button
              variant="outline"
              size="sm"
              onClick={handleEdit}
              className="gap-1.5 rounded-2xl"
            >
              <Pencil className="size-3.5" />
              编辑
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={handlePublish}
              className="gap-1.5 rounded-2xl"
            >
              <Send className="size-3.5" />
              发布
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDelete}
              className="gap-1.5 rounded-2xl text-destructive hover:text-destructive"
            >
              <Trash2 className="size-3.5" />
              删除
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ExamPaperCard;
