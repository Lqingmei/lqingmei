import React from 'react';
import { Trash2, Check } from 'lucide-react';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import { Button } from '@client/src/components/ui/button';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import type { Question, QuestionType } from '@shared/api.interface';

const OPTION_LABELS: string[] = ['A', 'B', 'C', 'D'];

const QUESTION_TYPES: { value: QuestionType; label: string }[] = [
  { value: 'single', label: '单选题' },
  { value: 'multiple', label: '多选题' },
  { value: 'judge', label: '判断题' },
];

interface QuestionEditorProps {
  question: Question;
  qIndex: number;
  canRemove: boolean;
  onTypeChange: (qIndex: number, newType: QuestionType) => void;
  onTitleChange: (qIndex: number, value: string) => void;
  onOptionChange: (qIndex: number, oIndex: number, value: string) => void;
  onCorrectAnswerChange: (qIndex: number, value: number) => void;
  onToggleCorrect: (qIndex: number, oIndex: number) => void;
  onScoreChange: (qIndex: number, value: number) => void;
  onExplanationChange: (qIndex: number, value: string) => void;
  onRemove: (qIndex: number) => void;
}

const QuestionEditor: React.FC<QuestionEditorProps> = ({
  question,
  qIndex,
  canRemove,
  onTypeChange,
  onTitleChange,
  onOptionChange,
  onCorrectAnswerChange,
  onToggleCorrect,
  onScoreChange,
  onExplanationChange,
  onRemove,
}) => {
  const qType: QuestionType = question.type ?? 'single';
  const correctArr: number[] = Array.isArray(question.correctAnswer)
    ? question.correctAnswer
    : [];

  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-sm font-bold text-blue-600">
            第 {qIndex + 1} 题
          </span>
          <Select
            value={qType}
            onValueChange={(val: string) =>
              onTypeChange(qIndex, val as QuestionType)
            }
          >
            <SelectTrigger className="h-7 w-24 rounded-xl">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {QUESTION_TYPES.map((qt) => (
                <SelectItem key={qt.value} value={qt.value}>
                  {qt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">分值</span>
            <Input
              type="number"
              min={1}
              value={question.score ?? 10}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                onScoreChange(qIndex, parseInt(e.target.value, 10) || 1)
              }
              className="h-7 w-16 rounded-xl text-center font-bold font-mono"
            />
          </div>
        </div>
        {canRemove && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onRemove(qIndex)}
            className="gap-1 text-destructive hover:text-destructive"
          >
            <Trash2 className="size-3.5" />
            删除
          </Button>
        )}
      </div>

      <div className="space-y-3">
        <Input
          value={question.title}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            onTitleChange(qIndex, e.target.value)
          }
          placeholder="请输入题干"
          className="rounded-xl"
        />

        {qType === 'judge' ? (
          <div className="flex items-center gap-4 rounded-xl border border-border bg-muted/30 px-4 py-2">
            {question.options.map((opt: string, oIndex: number) => (
              <div key={oIndex} className="flex items-center gap-2">
                <span className="font-mono text-sm font-bold text-muted-foreground">
                  {OPTION_LABELS[oIndex]}
                </span>
                <span className="text-sm font-medium text-foreground">{opt}</span>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {question.options.map((opt: string, oIndex: number) => (
              <div key={oIndex} className="flex items-center gap-2">
                <span className="font-mono text-sm font-bold text-muted-foreground">
                  {OPTION_LABELS[oIndex]}
                </span>
                <Input
                  value={opt}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    onOptionChange(qIndex, oIndex, e.target.value)
                  }
                  placeholder={`选项 ${OPTION_LABELS[oIndex]}`}
                  className="flex-1 rounded-xl"
                />
                {qType === 'multiple' && (
                  <button
                    type="button"
                    onClick={() => onToggleCorrect(qIndex, oIndex)}
                    className={`flex size-6 shrink-0 items-center justify-center rounded-lg border border-border transition-colors ${
                      correctArr.includes(oIndex)
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-card text-transparent hover:bg-accent'
                    }`}
                    aria-label={`标记选项 ${OPTION_LABELS[oIndex]} 为正确答案`}
                  >
                    <Check className="size-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        {qType === 'multiple' ? (
          <p className="text-xs font-medium text-muted-foreground">
            点击选项右侧方框标记正确答案（可多选）
          </p>
        ) : (
          <div className="flex items-center gap-2">
            <Label className="shrink-0 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">正确答案</Label>
            <Select
              value={String(question.correctAnswer)}
              onValueChange={(val: string) =>
                onCorrectAnswerChange(qIndex, parseInt(val, 10))
              }
            >
              <SelectTrigger className="w-32 rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {question.options.map((_: string, idx: number) => (
                  <SelectItem key={idx} value={String(idx)}>
                    {qType === 'judge'
                      ? idx === 0
                        ? '正确'
                        : '错误'
                      : OPTION_LABELS[idx]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        <div className="space-y-1.5">
          <Label className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">解析</Label>
          <Textarea
            value={question.explanation ?? ''}
            onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
              onExplanationChange(qIndex, e.target.value)
            }
            placeholder="请输入答案解析（选填）"
            className="min-h-[60px] rounded-xl"
            rows={2}
          />
        </div>
      </div>
    </div>
  );
};

export default QuestionEditor;
