import React, { useState, useEffect, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, Plus, Loader2 } from 'lucide-react';
import * as XLSX from 'xlsx';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import type {
  Question,
  QuestionType,
  ExamPaperDetail,
  CreateExamPaperRequest,
  UpdateExamPaperRequest,
} from '@shared/api.interface';
import {
  createExamPaper,
  updateExamPaper,
  getExamPaperDetail,
} from '@client/src/api/exam-paper';
import { logger } from '@lark-apaas/client-toolkit/logger';
import QuestionEditor from './QuestionEditor';

interface ExamPaperEditDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editId: string | null;
  onSaved: () => void;
}

const DEFAULT_QUESTION_SCORE = 10;

const createEmptyQuestion = (type: QuestionType = 'single'): Question => {
  if (type === 'judge') {
    return { type, title: '', options: ['正确', '错误'], correctAnswer: 0, score: DEFAULT_QUESTION_SCORE, explanation: '' };
  }
  if (type === 'multiple') {
    return { type, title: '', options: ['', '', '', ''], correctAnswer: [], score: DEFAULT_QUESTION_SCORE, explanation: '' };
  }
  return { type, title: '', options: ['', '', '', ''], correctAnswer: 0, score: DEFAULT_QUESTION_SCORE, explanation: '' };
};

const ensureQuestionScores = (questions: Question[]): Question[] => {
  const hasScores = questions.some((q: Question) => q.score !== undefined);
  if (hasScores) return questions;
  const defaultScore = questions.length > 0 ? Math.floor(100 / questions.length) : DEFAULT_QUESTION_SCORE;
  return questions.map((q: Question) => ({ ...q, score: defaultScore }));
};

const ExamPaperEditDialog: React.FC<ExamPaperEditDialogProps> = ({
  open,
  onOpenChange,
  editId,
  onSaved,
}) => {
  const [name, setName] = useState<string>('');
  const [passScore, setPassScore] = useState<number>(60);
  const [questions, setQuestions] = useState<Question[]>([createEmptyQuestion()]);
  const [nameError, setNameError] = useState<string>('');
  const [questionError, setQuestionError] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);

  const totalScore: number = questions.reduce(
    (sum: number, q: Question) => sum + (q.score ?? 0),
    0,
  );

  useEffect(() => {
    if (!open) return;

    if (editId) {
      setLoading(true);
      getExamPaperDetail(editId)
        .then((detail: ExamPaperDetail) => {
          setName(detail.name);
          setPassScore(detail.passScore);
          setQuestions(
            detail.questions.length > 0
              ? ensureQuestionScores(
                  detail.questions.map((q: Question) => ({
                    ...q,
                    type: q.type ?? 'single',
                  })),
                )
              : [createEmptyQuestion()],
          );
        })
        .catch((err: unknown) => {
          toast.error('加载试卷详情失败');
          logger.error(err);
        })
        .finally(() => setLoading(false));
    } else {
      setName('');
      setPassScore(60);
      setQuestions([createEmptyQuestion()]);
    }
    setNameError('');
    setQuestionError('');
  }, [open, editId]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e: ProgressEvent<FileReader>) => {
      try {
        const data = e.target?.result;
        if (file.name.endsWith('.json')) {
          const parsed = JSON.parse(data as string);
          if (Array.isArray(parsed) && parsed.length > 0) {
            const mapped: Question[] = parsed.map(
              (item: Record<string, unknown>) => {
                const type = (item.type as QuestionType) ?? 'single';
                const score = Number(item.score ?? DEFAULT_QUESTION_SCORE);
                if (type === 'judge') {
                  return {
                    type,
                    title: String(item.title ?? ''),
                    options: ['正确', '错误'],
                    correctAnswer: Number(item.correctAnswer ?? 0),
                    score,
                  };
                }
                const correctAnswer =
                  type === 'multiple'
                    ? Array.isArray(item.correctAnswer)
                      ? (item.correctAnswer as number[])
                      : [Number(item.correctAnswer ?? 0)]
                    : Number(item.correctAnswer ?? 0);
                return {
                  type,
                  title: String(item.title ?? ''),
                  options: Array.isArray(item.options)
                    ? (item.options as string[]).map((o: unknown) => String(o))
                    : ['', '', '', ''],
                  correctAnswer,
                  score,
                };
              },
            );
            setQuestions(mapped);
            toast.success(`已导入 ${mapped.length} 道题目`);
          } else {
            toast.error('JSON 格式错误：需要一个题目数组');
          }
        } else {
          const workbook = XLSX.read(data, { type: 'array' });
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const rows: Record<string, unknown>[] = XLSX.utils.sheet_to_json(sheet);
          if (rows.length === 0) {
            toast.error('Excel 文件为空');
            return;
          }
          const mapped: Question[] = rows.map((row: Record<string, unknown>) => {
            const typeStr = String(row.type ?? row['题型'] ?? '单选题');
            const type: QuestionType = typeStr.includes('多')
              ? 'multiple'
              : typeStr.includes('判')
                ? 'judge'
                : 'single';
            const title = String(row.title ?? row['题干'] ?? '');
            const score = Number(row.score ?? row['分值'] ?? DEFAULT_QUESTION_SCORE);
            if (type === 'judge') {
              const correctStr = String(row.correctAnswer ?? row['正确答案'] ?? 'A');
              return {
                type,
                title,
                options: ['正确', '错误'],
                correctAnswer:
                  correctStr.includes('B') ||
                  correctStr.includes('错') ||
                  correctStr === '1'
                    ? 1
                    : 0,
                score,
              };
            }
            const options = [
              String(row.optionA ?? row['选项A'] ?? row['A'] ?? ''),
              String(row.optionB ?? row['选项B'] ?? row['B'] ?? ''),
              String(row.optionC ?? row['选项C'] ?? row['C'] ?? ''),
              String(row.optionD ?? row['选项D'] ?? row['D'] ?? ''),
            ];
            const correctStr = String(row.correctAnswer ?? row['正确答案'] ?? 'A');
            if (type === 'multiple') {
              const letters = correctStr.match(/[A-Da-d]/g) ?? [];
              const correctAnswer = letters.map(
                (l: string) => l.toUpperCase().charCodeAt(0) - 65,
              );
              return { type, title, options, correctAnswer, score };
            }
            const correctMap: Record<string, number> = {
              A: 0, B: 1, C: 2, D: 3,
              '0': 0, '1': 1, '2': 2, '3': 3,
            };
            const correctAnswer = correctMap[correctStr] ?? 0;
            return { type, title, options, correctAnswer, score };
          });
          setQuestions(mapped);
          toast.success(`已导入 ${mapped.length} 道题目`);
        }
      } catch {
        toast.error('文件解析失败，请检查格式');
      }
    };
    if (file.name.endsWith('.json')) {
      reader.readAsText(file);
    } else {
      reader.readAsArrayBuffer(file);
    }
  }, []);

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    accept: {
      'application/json': ['.json'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls'],
    },
    maxFiles: 1,
  });

  const handleAddQuestion = (): void => {
    setQuestions((prev) => [...prev, createEmptyQuestion()]);
  };

  const handleRemoveQuestion = (index: number): void => {
    setQuestions((prev) => prev.filter((_, i: number) => i !== index));
  };

  const handleTypeChange = (qIndex: number, newType: QuestionType): void => {
    setQuestions((prev) =>
      prev.map((q: Question, i: number) => {
        if (i !== qIndex) return q;
        const score = q.score ?? DEFAULT_QUESTION_SCORE;
        if (newType === 'judge') {
          return { ...q, type: newType, options: ['正确', '错误'], correctAnswer: 0, score };
        }
        if (newType === 'multiple') {
          return { ...q, type: newType, options: ['', '', '', ''], correctAnswer: [], score };
        }
        return { ...q, type: newType, options: ['', '', '', ''], correctAnswer: 0, score };
      }),
    );
  };

  const handleTitleChange = (qIndex: number, value: string): void => {
    setQuestions((prev) =>
      prev.map((q: Question, i: number) =>
        i === qIndex ? { ...q, title: value } : q,
      ),
    );
  };

  const handleOptionChange = (qIndex: number, oIndex: number, value: string): void => {
    setQuestions((prev) =>
      prev.map((q: Question, i: number) => {
        if (i !== qIndex) return q;
        const newOptions = [...q.options];
        newOptions[oIndex] = value;
        return { ...q, options: newOptions };
      }),
    );
  };

  const handleCorrectAnswerChange = (qIndex: number, value: number): void => {
    setQuestions((prev) =>
      prev.map((q: Question, i: number) =>
        i === qIndex ? { ...q, correctAnswer: value } : q,
      ),
    );
  };

  const handleToggleCorrect = (qIndex: number, oIndex: number): void => {
    setQuestions((prev) =>
      prev.map((q: Question, i: number) => {
        if (i !== qIndex) return q;
        const current = Array.isArray(q.correctAnswer) ? q.correctAnswer : [];
        const newArr = current.includes(oIndex)
          ? current.filter((idx: number) => idx !== oIndex)
          : [...current, oIndex];
        return { ...q, correctAnswer: newArr };
      }),
    );
  };

  const handleScoreChange = (qIndex: number, value: number): void => {
    setQuestions((prev) =>
      prev.map((q: Question, i: number) =>
        i === qIndex ? { ...q, score: value } : q,
      ),
    );
  };

  const handleExplanationChange = (qIndex: number, value: string): void => {
    setQuestions((prev) =>
      prev.map((q: Question, i: number) =>
        i === qIndex ? { ...q, explanation: value } : q,
      ),
    );
  };

  const validate = (): boolean => {
    let valid = true;
    if (!name.trim()) {
      setNameError('试卷名称不能为空');
      valid = false;
    } else {
      setNameError('');
    }

    if (questions.length === 0) {
      setQuestionError('至少需要 1 道题目');
      valid = false;
    } else {
      const hasInvalid = questions.some((q: Question) => {
        if (!q.title.trim()) return true;
        if (q.type === 'judge') return false;
        if (q.options.some((o: string) => !o.trim())) return true;
        if (q.type === 'multiple') {
          const arr = Array.isArray(q.correctAnswer) ? q.correctAnswer : [];
          return arr.length === 0;
        }
        return false;
      });
      if (hasInvalid) {
        setQuestionError('请完整填写题干和选项，多选题至少选择一个正确答案');
        valid = false;
      } else {
        setQuestionError('');
      }
    }
    return valid;
  };

  const handleSave = async (): Promise<void> => {
    if (!validate()) return;

    setSaving(true);
    try {
      if (editId) {
        const payload: UpdateExamPaperRequest = {
          name: name.trim(),
          questions,
          passScore,
        };
        await updateExamPaper(editId, payload);
        toast.success('试卷已更新');
      } else {
        const payload: CreateExamPaperRequest = {
          name: name.trim(),
          questions,
          passScore,
        };
        await createExamPaper(payload);
        toast.success('试卷已创建');
      }
      onSaved();
      onOpenChange(false);
    } catch (err: unknown) {
      toast.error(editId ? '更新失败' : '创建失败');
      logger.error(err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto rounded-3xl">
        <DialogHeader>
          <DialogTitle className="serif-font">{editId ? '编辑试卷' : '新建试卷'}</DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="size-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-5">
            <div className="space-y-2">
              <Label className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                试卷名称 <span className="text-destructive">*</span>
              </Label>
              <Input
                value={name}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
                placeholder="请输入试卷名称"
                className="rounded-xl"
              />
              {nameError && (
                <p className="text-sm text-destructive">{nameError}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                及格分数
                <span className="ml-2 font-medium text-muted-foreground">
                  （总分 {totalScore} 分）
                </span>
              </Label>
              <Input
                type="number"
                value={passScore}
                min={0}
                max={totalScore}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setPassScore(parseInt(e.target.value, 10) || 0)
                }
                className="w-32 rounded-xl font-bold font-mono"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">批量导入题目（Excel / JSON）</Label>
              <div
                {...getRootProps()}
                className="flex cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-muted/30 p-4 text-center transition-colors hover:border-blue-600"
              >
                <input {...getInputProps()} />
                <Upload className="mb-1.5 size-5 text-muted-foreground" />
                <p className="text-sm font-medium text-muted-foreground">
                  点击或拖拽文件至此处导入
                </p>
                <p className="mt-0.5 text-xs font-medium text-muted-foreground">
                  支持 .xlsx / .xls / .json 格式
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                  题目列表 <span className="text-destructive">*</span>
                  <span className="ml-2 font-medium text-muted-foreground">
                    （共 {questions.length} 题）
                  </span>
                </Label>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleAddQuestion}
                  className="gap-1.5 rounded-2xl"
                >
                  <Plus className="size-3.5" />
                  添加题目
                </Button>
              </div>

              {questionError && (
                <p className="text-sm text-destructive">{questionError}</p>
              )}

              {questions.map((q: Question, qIndex: number) => (
                <QuestionEditor
                  key={qIndex}
                  question={q}
                  qIndex={qIndex}
                  canRemove={questions.length > 1}
                  onTypeChange={handleTypeChange}
                  onTitleChange={handleTitleChange}
                  onOptionChange={handleOptionChange}
                  onCorrectAnswerChange={handleCorrectAnswerChange}
                  onToggleCorrect={handleToggleCorrect}
                  onScoreChange={handleScoreChange}
                  onExplanationChange={handleExplanationChange}
                  onRemove={handleRemoveQuestion}
                />
              ))}
            </div>
          </div>
        )}

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={saving}
            className="rounded-2xl"
          >
            取消
          </Button>
          <Button onClick={handleSave} disabled={saving || loading} className="rounded-2xl">
            {saving && <Loader2 className="size-4 animate-spin" />}
            保存
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ExamPaperEditDialog;
