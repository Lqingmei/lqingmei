import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import { Textarea } from '@client/src/components/ui/textarea';
import { Input } from '@client/src/components/ui/input';
import { Mail, Save, Loader2, Eye } from 'lucide-react';
import { toast } from 'sonner';
import {
  getNotificationTemplate,
  updateNotificationTemplate,
} from '@client/src/api/notification-template';
import type { NotificationTemplate } from '@shared/api.interface';

const PLACEHOLDERS = [
  { name: '{examName}', desc: '考试名称' },
  { name: '{questionCount}', desc: '题目数量' },
  { name: '{passScore}', desc: '及格分数' },
] as const;

const PREVIEW_EXAM_NAME = '资产管理制度考试';
const PREVIEW_QUESTION_COUNT = 20;
const PREVIEW_PASS_SCORE = 60;

function replacePlaceholders(
  template: string,
  examName: string,
  questionCount: number,
  passScore: number,
): string {
  return template
    .replace(/\{examName\}/g, examName)
    .replace(/\{questionCount\}/g, String(questionCount))
    .replace(/\{passScore\}/g, String(passScore));
}

const NotificationTemplatePage: React.FC = () => {
  const [template, setTemplate] = useState<NotificationTemplate | null>(null);
  const [titleTemplate, setTitleTemplate] = useState('');
  const [descriptionTemplate, setDescriptionTemplate] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchTemplate = async () => {
      try {
        const data = await getNotificationTemplate();
        setTemplate(data);
        setTitleTemplate(data.titleTemplate);
        setDescriptionTemplate(data.descriptionTemplate);
      } catch {
        toast.error('加载通知模版失败');
      } finally {
        setLoading(false);
      }
    };
    void fetchTemplate();
  }, []);

  const handleSave = useCallback(async () => {
    if (!titleTemplate.trim()) {
      toast.error('标题模版不能为空');
      return;
    }
    if (!descriptionTemplate.trim()) {
      toast.error('正文模版不能为空');
      return;
    }

    setSaving(true);
    try {
      const updated = await updateNotificationTemplate({
        titleTemplate: titleTemplate.trim(),
        descriptionTemplate: descriptionTemplate.trim(),
      });
      setTemplate(updated);
      toast.success('通知模版已保存');
    } catch {
      toast.error('保存失败，请稍后重试');
    } finally {
      setSaving(false);
    }
  }, [titleTemplate, descriptionTemplate]);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="size-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const hasChanges =
    titleTemplate !== (template?.titleTemplate ?? '') ||
    descriptionTemplate !== (template?.descriptionTemplate ?? '');

  return (
    <div className="mx-auto max-w-3xl px-6 md:px-12">
      <div className="mb-6">
        <h1 className="serif-font flex items-center gap-2 text-3xl font-light tracking-tight text-foreground">
          <Mail className="size-6 text-primary" />
          通知模版
        </h1>
        <p className="mt-1 text-sm font-medium text-muted-foreground">
          配置发送给学员的飞书考试通知内容，支持占位符自动替换
        </p>
      </div>

      <Card className="report-card rounded-3xl border border-slate-100 shadow-sm transition-all duration-300 hover:shadow-xl">
        <CardContent className="p-8">
          <div className="mb-6 flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-black uppercase tracking-[0.15em] text-blue-600">
              可用占位符
            </span>
            {PLACEHOLDERS.map((p) => (
              <Badge
                key={p.name}
                variant="outline"
                className="rounded-full font-mono text-[10px] font-bold"
              >
                {p.name}
                <span className="ml-1 font-sans font-medium text-muted-foreground">
                  {p.desc}
                </span>
              </Badge>
            ))}
          </div>

          <div className="mb-5">
            <label className="mb-2 block text-[11px] font-black uppercase tracking-[0.15em] text-muted-foreground">
              标题模版
            </label>
            <Input
              value={titleTemplate}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setTitleTemplate(e.target.value)
              }
              placeholder="考试通知：{examName}"
              className="rounded-xl font-medium"
            />
          </div>

          <div className="mb-5">
            <label className="mb-2 block text-[11px] font-black uppercase tracking-[0.15em] text-muted-foreground">
              正文模版
            </label>
            <Textarea
              value={descriptionTemplate}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setDescriptionTemplate(e.target.value)
              }
              placeholder="您被分配参加考试**《{examName}》**..."
              className="min-h-[160px] rounded-xl font-medium leading-relaxed"
            />
            <p className="mt-1.5 text-[10px] font-medium text-muted-foreground">
              支持飞书 Markdown 格式（加粗、链接等）
            </p>
          </div>

          <div className="mb-6 border-t border-border pt-4">
            <div className="mb-3 flex items-center gap-1.5">
              <Eye className="size-3.5 text-muted-foreground" />
              <span className="text-[11px] font-black uppercase tracking-[0.15em] text-muted-foreground">
                预览效果
              </span>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-muted/30 p-4">
              <p className="text-sm font-bold text-foreground">
                {replacePlaceholders(
                  titleTemplate || '（标题为空）',
                  PREVIEW_EXAM_NAME,
                  PREVIEW_QUESTION_COUNT,
                  PREVIEW_PASS_SCORE,
                )}
              </p>
              <p className="mt-2 whitespace-pre-wrap text-xs font-medium leading-relaxed text-muted-foreground">
                {replacePlaceholders(
                  descriptionTemplate || '（正文为空）',
                  PREVIEW_EXAM_NAME,
                  PREVIEW_QUESTION_COUNT,
                  PREVIEW_PASS_SCORE,
                )}
              </p>
            </div>
          </div>

          <div className="flex justify-end">
            <Button
              onClick={handleSave}
              disabled={saving || !hasChanges}
            >
              {saving ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Save className="size-4" />
              )}
              保存模版
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default NotificationTemplatePage;
