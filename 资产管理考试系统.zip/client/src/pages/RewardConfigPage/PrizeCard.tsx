import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Trash2, Pencil, Package } from 'lucide-react';
import { Card } from '@client/src/components/ui/card';
import { Image } from '@client/src/components/ui/image';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@client/src/components/ui/alert-dialog';
import type { Prize } from '@shared/api.interface';

interface PrizeCardProps {
  prize: Prize;
  onDelete: (id: string) => void;
  onEdit: (prize: Prize) => void;
}

const DELETE_BTN_CLASS =
  'bg-destructive text-white hover:bg-destructive/90';

const PrizeCard: React.FC<PrizeCardProps> = ({ prize, onDelete, onEdit }) => {
  const [confirmOpen, setConfirmOpen] = useState(false);

  const handleDelete = () => {
    setConfirmOpen(false);
    onDelete(prize.id);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
    >
      <Card className="relative overflow-hidden rounded-3xl border border-slate-100 p-4 shadow-sm transition-all duration-300 hover:-translate-y-2 hover:shadow-xl">
        <div className="absolute right-2 top-2 z-10 flex gap-1">
          <button
            onClick={() => onEdit(prize)}
            className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 text-primary transition-transform hover:scale-110"
            aria-label="编辑奖品"
          >
            <Pencil className="size-3.5" />
          </button>
          <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
            <AlertDialogTrigger asChild>
              <button
                className="flex h-7 w-7 items-center justify-center rounded-full bg-destructive/10 text-destructive transition-transform hover:scale-110"
                aria-label="删除奖品"
              >
                <Trash2 className="size-3.5" />
              </button>
            </AlertDialogTrigger>
          <AlertDialogContent className="rounded-3xl">
            <AlertDialogHeader>
              <AlertDialogTitle>确认删除奖品</AlertDialogTitle>
              <AlertDialogDescription>
                确定要删除「{prize.name}」吗？此操作不可撤销。
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>取消</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                className={DELETE_BTN_CLASS}
              >
                确认删除
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
          </AlertDialog>
        </div>

        <div className="mb-3 flex h-32 items-center justify-center overflow-hidden rounded-2xl border border-slate-200 bg-muted/30">
          {prize.imageUrl ? (
            <Image
              src={prize.imageUrl}
              alt={prize.name}
              className="h-full w-full object-cover"
            />
          ) : (
            <Package className="size-12 text-muted-foreground/40" />
          )}
        </div>

        <p
          className="truncate text-sm font-bold text-foreground"
          title={prize.name}
        >
          {prize.name}
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          数量{' '}
          <span className="font-bold text-foreground">
            × {prize.quantity}
          </span>
        </p>
      </Card>
    </motion.div>
  );
};

export default PrizeCard;
