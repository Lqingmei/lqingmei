import React, { useState, useRef, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Loader2, X, ImageIcon } from 'lucide-react';
import { toast } from 'sonner';
import { getDataloom } from '@lark-apaas/client-toolkit/dataloom';
import { getDefaultBucketId } from '@lark-apaas/client-toolkit/tools/storage';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import { Image } from '@client/src/components/ui/image';
import { createPrize, updatePrize } from '@client/src/api/prize';
import type { Prize } from '@shared/api.interface';

const prizeSchema = z.object({
  name: z
    .string()
    .min(1, '奖品名称不能为空')
    .max(255, '名称不能超过255个字符'),
  quantity: z.coerce
    .number()
    .int('数量必须为整数')
    .min(1, '数量至少为1'),
});

type PrizeFormData = z.infer<typeof prizeSchema>;

interface AddPrizeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  prize?: Prize | null;
}

const AddPrizeDialog: React.FC<AddPrizeDialogProps> = ({
  open,
  onOpenChange,
  onSuccess,
  prize,
}) => {
  const isEditMode = !!prize;
  const [imageUrl, setImageUrl] = useState<string | null | undefined>(undefined);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | undefined>(undefined);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const form = useForm<PrizeFormData>({
    resolver: zodResolver(prizeSchema),
    defaultValues: { name: '', quantity: 1 },
  });

  useEffect(() => {
    if (!open) return;
    if (prize) {
      form.reset({ name: prize.name, quantity: prize.quantity });
      setImageUrl(prize.imageUrl ?? null);
      setPreviewUrl(prize.imageUrl ?? undefined);
    } else {
      form.reset({ name: '', quantity: 1 });
      setImageUrl(undefined);
      setPreviewUrl(undefined);
    }
  }, [open, prize, form]);

  const resetForm = () => {
    form.reset({ name: '', quantity: 1 });
    if (previewUrl && previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(previewUrl);
    }
    setImageUrl(undefined);
    setPreviewUrl(undefined);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleOpenChange = (value: boolean) => {
    if (!value) {
      resetForm();
    }
    onOpenChange(value);
  };

  const handleFileSelect = async (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file: File | undefined = e.target.files?.[0];
    if (!file) return;

    const objectUrl: string = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);

    setUploading(true);
    try {
      const dataloom = await getDataloom();
      const { data, error } = await dataloom.storage
        .from(getDefaultBucketId())
        .uploadFile(file);

      if (error || !data) {
        throw new Error(error?.message ?? '上传失败');
      }

      setImageUrl(data.download_url);
      toast.success('图片上传成功');
    } catch (err) {
      logger.error(`图片上传失败: ${String(err)}`);
      toast.error('图片上传失败');
      URL.revokeObjectURL(objectUrl);
      setPreviewUrl(prize?.imageUrl ?? undefined);
      setImageUrl(prize?.imageUrl ?? null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveImage = () => {
    if (previewUrl && previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(previewUrl);
    }
    setImageUrl(isEditMode ? null : undefined);
    setPreviewUrl(undefined);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const onSubmit = async (data: PrizeFormData) => {
    setSubmitting(true);
    try {
      if (isEditMode && prize) {
        await updatePrize(prize.id, {
          name: data.name,
          quantity: data.quantity,
          imageUrl: imageUrl,
        });
        toast.success('奖品已更新');
      } else {
        await createPrize({
          name: data.name,
          quantity: data.quantity,
          imageUrl: imageUrl ?? undefined,
        });
        toast.success('奖品添加成功');
      }
      resetForm();
      onOpenChange(false);
      onSuccess();
    } catch (err) {
      logger.error(`${isEditMode ? '更新' : '添加'}奖品失败: ${String(err)}`);
      toast.error(isEditMode ? '更新奖品失败' : '添加奖品失败');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="rounded-3xl">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold tracking-tight">
            {isEditMode ? '编辑奖品' : '新增奖品'}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="space-y-4"
          >
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium">
                    奖品名称{' '}
                    <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input placeholder="请输入奖品名称" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium">
                    数量 <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={1}
                      placeholder="请输入数量"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-2">
              <Label className="text-sm font-medium">奖品图片（可选）</Label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
              {previewUrl ? (
                <div className="relative inline-block">
                  <Image
                    src={previewUrl}
                    alt="预览"
                    className="h-32 w-32 rounded-2xl border border-slate-200 object-cover"
                  />
                  <button
                    type="button"
                    onClick={handleRemoveImage}
                    className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-destructive text-white"
                    aria-label="移除图片"
                  >
                    <X className="size-3.5" />
                  </button>
                  {uploading && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                      <Loader2 className="size-6 animate-spin text-white" />
                    </div>
                  )}
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                  className="flex h-32 w-full items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-muted/30 transition-colors hover:bg-muted/50"
                >
                  <div className="flex flex-col items-center gap-2 text-muted-foreground">
                    {uploading ? (
                      <Loader2 className="size-6 animate-spin" />
                    ) : (
                      <ImageIcon className="size-6" />
                    )}
                    <span className="text-xs">
                      {uploading ? '上传中...' : '点击上传图片'}
                    </span>
                  </div>
                </button>
              )}
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
                disabled={submitting}
              >
                取消
              </Button>
              <Button type="submit" disabled={submitting || uploading}>
                {submitting ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    提交中...
                  </>
                ) : isEditMode ? (
                  '确认修改'
                ) : (
                  '确认添加'
                )}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default AddPrizeDialog;
