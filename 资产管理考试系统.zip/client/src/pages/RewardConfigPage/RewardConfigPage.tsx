import React, { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Gift, Plus, Loader2, Package, Percent, Save } from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Progress } from '@client/src/components/ui/progress';
import { Input } from '@client/src/components/ui/input';
import { cn } from '@/lib/utils';
import { getPrizes, deletePrize } from '@client/src/api/prize';
import { getLotteryConfig, updateLotteryConfig } from '@client/src/api/lottery';
import type { Prize } from '@shared/api.interface';
import PrizeCard from './PrizeCard';
import AddPrizeDialog from './AddPrizeDialog';

const MAX_COUNT = 24;

const RewardConfigPage: React.FC = () => {
  const [prizes, setPrizes] = useState<Prize[]>([]);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [editingPrize, setEditingPrize] = useState<Prize | null>(null);
  const [winProbability, setWinProbability] = useState<number>(50);
  const [configLoading, setConfigLoading] = useState<boolean>(true);
  const [savingConfig, setSavingConfig] = useState<boolean>(false);

  const isFull: boolean = totalCount >= MAX_COUNT;
  const progress: number = (totalCount / MAX_COUNT) * 100;

  const fetchPrizes = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getPrizes();
      setPrizes(res.items);
      setTotalCount(res.totalCount);
    } catch (err) {
      logger.error(`获取奖品列表失败: ${String(err)}`);
      toast.error('获取奖品列表失败');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPrizes();
  }, [fetchPrizes]);

  const fetchConfig = useCallback(async () => {
    setConfigLoading(true);
    try {
      const res = await getLotteryConfig();
      setWinProbability(Math.round(res.winProbability * 100));
    } catch (err) {
      logger.error(`获取抽奖配置失败: ${String(err)}`);
    } finally {
      setConfigLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchConfig();
  }, [fetchConfig]);

  const handleSaveProbability = async () => {
    if (winProbability < 1 || winProbability > 100) {
      toast.error('中奖概率必须在 1% 到 100% 之间');
      return;
    }
    setSavingConfig(true);
    try {
      await updateLotteryConfig({ winProbability: winProbability / 100 });
      toast.success('中奖概率已更新');
    } catch (err) {
      logger.error(`更新抽奖配置失败: ${String(err)}`);
      toast.error('更新失败，请重试');
    } finally {
      setSavingConfig(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deletePrize(id);
      toast.success('奖品已删除');
      fetchPrizes();
    } catch (err) {
      logger.error(`删除奖品失败: ${String(err)}`);
      const msg =
        (err as { response?: { data?: { error?: { message?: string } } } })
          .response?.data?.error?.message ?? '删除奖品失败';
      toast.error(msg);
    }
  };

  const handleAddSuccess = () => {
    fetchPrizes();
  };

  const handleEdit = (prize: Prize) => {
    setEditingPrize(prize);
    setDialogOpen(true);
  };

  const handleDialogChange = (open: boolean) => {
    setDialogOpen(open);
    if (!open) {
      setEditingPrize(null);
    }
  };

  return (
    <div className="space-y-6 px-6 md:px-12">
      {/* Page header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-primary/10">
            <Gift className="size-5 text-primary" />
          </div>
          <div>
            <h1 className="serif-font text-3xl font-light tracking-tight text-foreground">
              奖励配置
            </h1>
            <p className="text-sm font-medium text-muted-foreground">
              配置考试奖励奖品，上限 {MAX_COUNT} 个
            </p>
          </div>
        </div>
        <Button
          onClick={() => { setEditingPrize(null); setDialogOpen(true); }}
          disabled={isFull}
          data-ai-section-type="button"
        >
          <Plus className="size-4" />
          {isFull ? '已达上限' : '新增奖品'}
        </Button>
      </div>

      {/* Lottery probability config */}
      <Card data-ai-section-type="card-stat" className="rounded-3xl border border-slate-100 shadow-sm transition-all duration-300 hover:shadow-xl">
        <CardContent className="p-6">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-2xl bg-primary/10">
                <Percent className="size-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-bold text-foreground">
                  中奖概率设置
                </p>
                <p className="text-xs font-medium text-muted-foreground">
                  满分用户抽奖时的中奖概率
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {configLoading ? (
                <Loader2 className="size-5 animate-spin text-muted-foreground" />
              ) : (
                <>
                  <div className="relative">
                    <Input
                      type="number"
                      min={1}
                      max={100}
                      value={winProbability}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        setWinProbability(Number(e.target.value))
                      }
                      className="w-24 rounded-xl pr-7 text-right font-mono"
                    />
                    <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                      %
                    </span>
                  </div>
                  <Button
                    size="sm"
                    onClick={handleSaveProbability}
                    disabled={savingConfig}
                    data-ai-section-type="button"
                  >
                    {savingConfig ? (
                      <Loader2 className="size-4 animate-spin" />
                    ) : (
                      <Save className="size-4" />
                    )}
                    保存
                  </Button>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quota dashboard */}
      <Card data-ai-section-type="card-stat" className="rounded-3xl border border-slate-100 shadow-sm transition-all duration-300 hover:shadow-xl">
        <CardContent className="p-6">
          <div className="mb-4 flex items-end justify-between">
            <div>
              <p className="text-sm font-bold text-muted-foreground">
                奖品配额
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                {isFull
                  ? '已配满全部奖品'
                  : `还可配置 ${MAX_COUNT - totalCount} 个奖品`}
              </p>
            </div>
            <div className="text-right">
              <div className="flex items-baseline gap-1.5">
                <motion.span
                  className="font-bold text-2xl text-foreground"
                >
                  {totalCount}
                </motion.span>
                <span className="text-lg font-medium text-muted-foreground">
                  / {MAX_COUNT}
                </span>
              </div>
            </div>
          </div>
          <Progress
            value={progress}
            className={cn(
              'h-5 rounded-full',
              isFull
                ? '[&>[data-slot=progress-indicator]]:bg-success'
                : '[&>[data-slot=progress-indicator]]:bg-primary',
            )}
          />
        </CardContent>
      </Card>

      {/* Prize grid */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="size-8 animate-spin text-muted-foreground" />
        </div>
      ) : prizes.length === 0 ? (
        <Card className="rounded-3xl border border-slate-100 shadow-sm transition-all duration-300 hover:shadow-xl">
          <CardContent className="flex flex-col items-center justify-center py-20">
            <Package className="mb-4 size-12 text-muted-foreground/40" />
            <p className="text-sm font-medium text-muted-foreground">
              暂无奖品，点击「新增奖品」开始配置
            </p>
          </CardContent>
        </Card>
      ) : (
        <div
          className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4"
          data-ai-section-type="card-list"
        >
          <AnimatePresence mode="popLayout">
            {prizes.map((prize: Prize) => (
              <PrizeCard
                key={prize.id}
                prize={prize}
                onDelete={handleDelete}
                onEdit={handleEdit}
              />
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Add prize dialog */}
      <AddPrizeDialog
        open={dialogOpen}
        onOpenChange={handleDialogChange}
        onSuccess={handleAddSuccess}
        prize={editingPrize}
      />
    </div>
  );
};

export default RewardConfigPage;
