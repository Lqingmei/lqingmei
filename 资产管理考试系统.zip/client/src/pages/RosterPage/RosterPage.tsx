import React, { useState, useEffect, useCallback } from 'react';
import { UserPlus, Trash2, Upload, Loader2, Users, Search } from 'lucide-react';
import { toast } from 'sonner';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import { Input } from '@client/src/components/ui/input';
import { Card, CardContent } from '@client/src/components/ui/card';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@client/src/components/ui/alert-dialog';
import { UserDisplay } from '@client/src/components/business-ui/user-display';
import { UserSelect } from '@client/src/components/business-ui/user-select';
import ImportRosterDialog from './ImportRosterDialog';
import {
  getRoster,
  deleteRosterItem,
  clearRoster,
  updateRosterItem,
  addRosterItem,
} from '@client/src/api/exam-roster';
import type { ExamRosterItem } from '@shared/api.interface';

const RosterPage: React.FC = () => {
  const [roster, setRoster] = useState<ExamRosterItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [importOpen, setImportOpen] = useState<boolean>(false);
  const [addUserValue, setAddUserValue] = useState<string | null>(null);
  const [adding, setAdding] = useState<boolean>(false);
  const [editingCenterId, setEditingCenterId] = useState<string | null>(null);

  const fetchRoster = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const res = await getRoster();
      setRoster(res.items);
    } catch {
      toast.error('获取名单失败');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRoster();
  }, [fetchRoster]);

  const handleDelete = async (id: string): Promise<void> => {
    try {
      await deleteRosterItem(id);
      setRoster((prev) => prev.filter((r) => r.id !== id));
      toast.success('已删除');
    } catch {
      toast.error('删除失败');
    }
  };

  const handleClear = async (): Promise<void> => {
    try {
      await clearRoster();
      setRoster([]);
      toast.success('名单已清空');
    } catch {
      toast.error('清空失败');
    }
  };

  const handleAddUser = async (
    userId: string,
    name: string,
  ): Promise<void> => {
    setAdding(true);
    try {
      await addRosterItem({ name, userId });
      toast.success(`已添加 ${name} 到名单`);
      setAddUserValue(null);
      fetchRoster();
    } catch (err) {
      const msg =
        (err as { response?: { data?: { error?: { message?: string } } } })
          .response?.data?.error?.message ?? '添加失败';
      toast.error(msg);
    } finally {
      setAdding(false);
    }
  };

  const handleUpdateCenter = async (
    id: string,
    center: string,
  ): Promise<void> => {
    try {
      const updated = await updateRosterItem(id, { center });
      setRoster((prev) =>
        prev.map((r) => (r.id === id ? updated : r)),
      );
      setEditingCenterId(null);
    } catch {
      toast.error('更新失败');
    }
  };

  const handleImportSaved = (): void => {
    setImportOpen(false);
    fetchRoster();
  };

  const handleManualMatch = async (
    id: string,
    userId: string,
  ): Promise<void> => {
    try {
      const updated = await updateRosterItem(id, {
        userId,
        status: 'resolved',
      });
      setRoster((prev) =>
        prev.map((r) => (r.id === id ? updated : r)),
      );
      toast.success('已匹配');
    } catch {
      toast.error('匹配失败');
    }
  };

  const resolvedCount = roster.filter((r) => r.status === 'resolved').length;
  const duplicateCount = roster.filter((r) => r.status === 'duplicate').length;
  const notFoundCount = roster.filter((r) => r.status === 'not_found').length;

  const renderStatusBadge = (status: ExamRosterItem['status']): React.ReactNode => {
    switch (status) {
      case 'resolved':
        return <Badge className="bg-success">已匹配</Badge>;
      case 'duplicate':
        return <Badge variant="destructive">重名待选</Badge>;
      case 'not_found':
        return (
          <div className="flex items-center gap-1">
            <Badge variant="secondary">未找到</Badge>
          </div>
        );
      default:
        return <Badge variant="outline">待解析</Badge>;
    }
  };

  return (
    <div className="space-y-6 px-6 md:px-12">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="serif-font text-3xl font-light tracking-tight text-foreground">考试名单</h1>
          <p className="mt-1 text-sm font-medium text-muted-foreground">
            预先导入考试人员名单，发布考试时可一键选择
          </p>
        </div>
        <div className="flex items-center gap-2">
          {roster.length > 0 && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Trash2 className="mr-1 size-4" />
                  清空
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="rounded-3xl">
                <AlertDialogHeader>
                  <AlertDialogTitle>确认清空名单</AlertDialogTitle>
                  <AlertDialogDescription>
                    确定要清空所有名单数据吗？此操作不可撤销。
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>取消</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleClear}
                    className="bg-destructive text-white hover:bg-destructive/90"
                  >
                    确认清空
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
          <Button size="sm" onClick={() => setImportOpen(true)}>
            <Upload className="mr-1 size-4" />
            导入名单
          </Button>
        </div>
      </div>

      {roster.length > 0 && (
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-muted/30 px-4 py-2">
            <Users className="size-4 text-primary" />
            <span className="text-sm font-medium">共 {roster.length} 人</span>
          </div>
          {resolvedCount > 0 && (
            <Badge className="bg-success">已匹配 {resolvedCount}</Badge>
          )}
          {duplicateCount > 0 && (
            <Badge variant="destructive">重名 {duplicateCount}</Badge>
          )}
          {notFoundCount > 0 && (
            <Badge variant="secondary">未找到 {notFoundCount}</Badge>
          )}
        </div>
      )}

      <Card data-ai-section-type="card-stat" className="rounded-3xl border border-slate-100 shadow-sm transition-all duration-300 hover:shadow-xl">
        <CardContent className="p-6">
          <div className="flex items-center gap-3">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-2xl bg-primary/10">
              <Search className="size-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="mb-1 text-sm font-bold text-foreground">
                搜索添加人员
              </p>
              <div className="max-w-md">
                <UserSelect
                  multiple={false}
                  triggerType="search"
                  valueType="string"
                  value={addUserValue}
                  onChange={(val) => setAddUserValue(val as string | null)}
                  onSelect={(user) => {
                    if (user?.id && user?.name) {
                      handleAddUser(user.id, user.name);
                    }
                  }}
                  disabled={adding}
                  placeholder="输入姓名搜索飞书用户..."
                />
              </div>
            </div>
            {adding && <Loader2 className="size-5 animate-spin text-muted-foreground" />}
          </div>
        </CardContent>
      </Card>

      <Card className="rounded-3xl border border-slate-100 shadow-sm transition-all duration-300 hover:shadow-xl">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">#</TableHead>
                <TableHead>姓名</TableHead>
                <TableHead>所属中心</TableHead>
                <TableHead>匹配用户</TableHead>
                <TableHead>状态</TableHead>
                <TableHead className="w-20">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} className="py-12 text-center text-muted-foreground">
                    <Loader2 className="mx-auto size-6 animate-spin" />
                  </TableCell>
                </TableRow>
              ) : roster.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <UserPlus className="size-12 text-muted-foreground/40" />
                      <p className="text-sm text-muted-foreground">
                        暂无名单数据，点击「导入名单」开始
                      </p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                roster.map((item: ExamRosterItem, index: number) => (
                  <TableRow
                    key={item.id}
                    className={index % 2 === 0 ? 'bg-muted/30' : ''}
                  >
                    <TableCell className="text-muted-foreground">
                      {index + 1}
                    </TableCell>
                    <TableCell className="font-bold">
                      {item.name}
                    </TableCell>
                    <TableCell>
                      {editingCenterId === item.id ? (
                        <Input
                          autoFocus
                          defaultValue={item.center}
                          onBlur={(e: React.FocusEvent<HTMLInputElement>) => {
                            const value = e.target.value.trim();
                            if (value !== item.center) {
                              handleUpdateCenter(item.id, value);
                            } else {
                              setEditingCenterId(null);
                            }
                          }}
                          onKeyDown={(e: React.KeyboardEvent) => {
                            if (e.key === 'Enter') {
                              (e.target as HTMLInputElement).blur();
                            }
                            if (e.key === 'Escape') {
                              setEditingCenterId(null);
                            }
                          }}
                          className="h-8 w-28 rounded-xl text-xs"
                        />
                      ) : (
                        <button
                          onClick={() => setEditingCenterId(item.id)}
                          className="text-muted-foreground hover:text-foreground"
                        >
                          {item.center || '—'}
                        </button>
                      )}
                    </TableCell>
                    <TableCell>
                      {item.userId ? (
                        <UserDisplay value={[item.userId]} size="small" />
                      ) : item.status === 'not_found' || item.status === 'duplicate' ? (
                        <div className="w-[200px]">
                          <UserSelect
                            multiple={false}
                            triggerType="search"
                            valueType="string"
                            value={null}
                            onChange={(val) => {
                              if (val) {
                                handleManualMatch(item.id, val as string);
                              }
                            }}
                            placeholder="搜索姓名手动匹配"
                          />
                        </div>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell>{renderStatusBadge(item.status)}</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(item.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <ImportRosterDialog
        open={importOpen}
        onOpenChange={setImportOpen}
        onSaved={handleImportSaved}
      />
    </div>
  );
};

export default RosterPage;
