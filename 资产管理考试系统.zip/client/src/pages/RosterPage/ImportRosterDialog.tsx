import React, { useState, useCallback } from 'react';
import { Upload, Loader2, CheckCircle2, AlertCircle, FileSpreadsheet } from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@client/src/components/ui/tabs';
import { Textarea } from '@client/src/components/ui/textarea';
import { UserDisplay } from '@client/src/components/business-ui/user-display';
import { UserSelect } from '@client/src/components/business-ui/user-select';
import { searchUsers } from '@client/src/components/business-ui/api/users/service';
import { saveRoster } from '@client/src/api/exam-roster';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type { RosterStatus } from '@shared/api.interface';

interface ImportRosterDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved: () => void;
}

interface ParsedItem {
  name: string;
  center: string;
  userId?: string;
  status: RosterStatus;
  matches: SearchResult[];
}

interface SearchResult {
  userId: string;
  name: string;
}

const CONCURRENCY = 5;

const ImportRosterDialog: React.FC<ImportRosterDialogProps> = ({
  open,
  onOpenChange,
  onSaved,
}) => {
  const [activeTab, setActiveTab] = useState<string>('paste');
  const [importText, setImportText] = useState<string>('');
  const [parsing, setParsing] = useState<boolean>(false);
  const [parsedItems, setParsedItems] = useState<ParsedItem[]>([]);
  const [saving, setSaving] = useState<boolean>(false);

  const parseLines = (text: string): { name: string; center: string }[] => {
    return text
      .split(/[\n\r]+/)
      .map((line) => line.trim())
      .filter((line) => line.length > 0)
      .map((line) => {
        const parts = line.split(/[,，]/);
        return {
          name: parts[0]?.trim() ?? '',
          center: parts[1]?.trim() ?? '',
        };
      })
      .filter((item) => item.name.length > 0);
  };

  const searchOneName = async (name: string): Promise<SearchResult[]> => {
    try {
      const response = await searchUsers({ query: name, pageSize: 20 });
      const userList = response?.data?.userList || [];
      return userList
        .map((u: Record<string, unknown>) => {
          const rawName = u.name as { zh_cn?: string; en_us?: string } | undefined;
          return {
            userId: String(u.userID ?? ''),
            name: rawName?.zh_cn || rawName?.en_us || '',
          };
        })
        .filter((u: SearchResult) => u.userId);
    } catch (err) {
      logger.error('searchUsers failed', { name, error: err });
      return [];
    }
  };

  const handleParse = useCallback(async (): Promise<void> => {
    const lines = parseLines(importText);
    if (lines.length === 0) {
      toast.error('请输入至少一个姓名');
      return;
    }

    setParsing(true);
    setParsedItems([]);

    const results: ParsedItem[] = [];

    for (let i = 0; i < lines.length; i += CONCURRENCY) {
      const batch = lines.slice(i, i + CONCURRENCY);
      const batchResults = await Promise.all(
        batch.map(async (line) => {
          const matches = await searchOneName(line.name);
          let status: RosterStatus = 'not_found';
          let userId: string | undefined;

          if (matches.length === 1) {
            status = 'resolved';
            userId = matches[0].userId;
          } else if (matches.length > 1) {
            status = 'duplicate';
          }

          return { name: line.name, center: line.center, userId, status, matches } as ParsedItem;
        }),
      );
      results.push(...batchResults);
    }

    setParsedItems(results);
    setParsing(false);

    const resolved = results.filter((r) => r.status === 'resolved').length;
    const duplicate = results.filter((r) => r.status === 'duplicate').length;
    const notFound = results.filter((r) => r.status === 'not_found').length;
    toast.success(
      `解析完成：${resolved} 已匹配，${duplicate} 重名待选，${notFound} 未找到`,
    );
  }, [importText]);

  const handleResolveDuplicate = (index: number, userId: string): void => {
    setParsedItems((prev) =>
      prev.map((item, i) =>
        i === index
          ? { ...item, userId, status: 'resolved' as RosterStatus }
          : item,
      ),
    );
  };

  const handleManualMatchNotFound = (
    index: number,
    userId: string,
  ): void => {
    setParsedItems((prev) =>
      prev.map((item, i) =>
        i === index
          ? { ...item, userId, status: 'resolved' as RosterStatus }
          : item,
      ),
    );
  };

  const handleSave = async (): Promise<void> => {
    if (parsedItems.length === 0) {
      toast.error('请先解析名单');
      return;
    }

    setSaving(true);
    try {
      const result = await saveRoster(
        parsedItems.map((item) => ({
          name: item.name,
          userId: item.userId,
          status: item.status,
          center: item.center,
        })),
      );
      if (result.skipped > 0) {
        toast.success(`已导入 ${result.inserted} 人，跳过 ${result.skipped} 名重复人员`);
      } else {
        toast.success(`已导入 ${result.inserted} 人`);
      }
      setImportText('');
      setParsedItems([]);
      onSaved();
    } catch {
      toast.error('保存失败');
    } finally {
      setSaving(false);
    }
  };

  const handleFileUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
  ): Promise<void> => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const xlsx = await import('xlsx');
      const arrayBuffer = await file.arrayBuffer();
      const workbook = xlsx.read(arrayBuffer);
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows = xlsx.utils.sheet_to_json<Record<string, unknown>>(sheet, {
        header: 1,
      });

      const lines: string[] = [];
      for (const row of rows) {
        const firstCell = row[0];
        if (firstCell && String(firstCell).trim()) {
          const name = String(firstCell).trim();
          const center = row[1] ? String(row[1]).trim() : '';
          lines.push(center ? `${name},${center}` : name);
        }
      }

      if (lines.length === 0) {
        toast.error('未在文件中找到姓名数据');
        return;
      }

      setImportText(lines.join('\n'));
      setActiveTab('paste');
      toast.success(`已从文件读取 ${lines.length} 个姓名，点击「解析」继续`);
    } catch {
      toast.error('文件解析失败');
    }

    e.target.value = '';
  };

  const resolvedCount = parsedItems.filter((r) => r.status === 'resolved').length;
  const duplicateCount = parsedItems.filter((r) => r.status === 'duplicate').length;
  const notFoundCount = parsedItems.filter((r) => r.status === 'not_found').length;

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!saving) onOpenChange(v); }}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto rounded-3xl">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold tracking-tight">导入考试名单</DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="paste">粘贴姓名</TabsTrigger>
            <TabsTrigger value="excel">Excel导入</TabsTrigger>
          </TabsList>

          <TabsContent value="paste" className="space-y-3">
            <p className="text-xs font-medium text-muted-foreground">
              每行一条记录，可用逗号附加所属中心，如：张伟,广州中心
            </p>
            <Textarea
              placeholder={'张伟,广州中心\n李明,肇庆中心\n王强'}
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              rows={6}
            />
            <Button
              onClick={handleParse}
              disabled={!importText.trim() || parsing}
              size="sm"
            >
              {parsing ? (
                <Loader2 className="mr-1 size-4 animate-spin" />
              ) : (
                <Upload className="mr-1 size-4" />
              )}
              解析名单
            </Button>
          </TabsContent>

          <TabsContent value="excel" className="space-y-3">
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 p-8">
              <FileSpreadsheet className="mb-3 size-12 text-muted-foreground/40" />
              <p className="mb-2 text-sm font-medium text-muted-foreground">
                上传 Excel 文件，第一列为姓名，第二列为所属中心
              </p>
              <label>
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Button size="sm" asChild>
                  <span>选择文件</span>
                </Button>
              </label>
            </div>
          </TabsContent>
        </Tabs>

        {parsedItems.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              {resolvedCount > 0 && (
                <Badge className="bg-success">
                  <CheckCircle2 className="mr-1 size-3" />
                  已匹配 {resolvedCount}
                </Badge>
              )}
              {duplicateCount > 0 && (
                <Badge variant="destructive">
                  <AlertCircle className="mr-1 size-3" />
                  重名 {duplicateCount}
                </Badge>
              )}
              {notFoundCount > 0 && (
                <Badge variant="secondary">未找到 {notFoundCount}</Badge>
              )}
            </div>

            <div className="max-h-64 overflow-y-auto rounded-2xl border border-slate-200">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-muted">
                  <tr>
                    <th className="px-3 py-2 text-left font-bold">姓名</th>
                    <th className="px-3 py-2 text-left font-bold">所属中心</th>
                    <th className="px-3 py-2 text-left font-bold">匹配用户</th>
                    <th className="px-3 py-2 text-left font-bold">状态</th>
                  </tr>
                </thead>
                <tbody>
                  {parsedItems.map((item, index) => (
                    <tr key={index} className="border-t border-border">
                      <td className="px-3 py-2 font-bold">{item.name}</td>
                      <td className="px-3 py-2 text-muted-foreground">{item.center || '—'}</td>
                      <td className="px-3 py-2">
                        {item.status === 'resolved' && item.userId ? (
                          <UserDisplay value={[item.userId]} size="small" />
                        ) : item.status === 'duplicate' ? (
                          <div className="space-y-1">
                            {item.matches.slice(0, 5).map((m) => (
                              <button
                                key={m.userId}
                                onClick={() => handleResolveDuplicate(index, m.userId)}
                                className="block w-full px-2 py-1 text-left text-xs hover:bg-accent"
                              >
                                <UserDisplay value={[m.userId]} size="small" />
                              </button>
                            ))}
                            {item.matches.length > 5 && (
                              <span className="text-xs text-muted-foreground">
                                还有 {item.matches.length - 5} 条...
                              </span>
                            )}
                          </div>
                        ) : (
                          <div className="w-[200px]">
                            <UserSelect
                              multiple={false}
                              triggerType="search"
                              valueType="string"
                              value={null}
                              onChange={(val) => {
                                if (val) {
                                  handleManualMatchNotFound(index, val as string);
                                }
                              }}
                              placeholder="搜索手动匹配"
                            />
                          </div>
                        )}
                      </td>
                      <td className="px-3 py-2">
                        {item.status === 'resolved' && (
                          <Badge className="bg-success">已匹配</Badge>
                        )}
                        {item.status === 'duplicate' && (
                          <Badge variant="destructive">点击选择</Badge>
                        )}
                        {item.status === 'not_found' && (
                          <Badge variant="secondary">未找到</Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={saving}
          >
            取消
          </Button>
          <Button
            onClick={handleSave}
            disabled={parsedItems.length === 0 || saving}
          >
            {saving && <Loader2 className="mr-1 size-4 animate-spin" />}
            保存名单
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ImportRosterDialog;
