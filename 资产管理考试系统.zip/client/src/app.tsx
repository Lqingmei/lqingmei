import React from 'react';
import { Route, Routes } from 'react-router-dom';

import Layout from './components/Layout';
import ExamLayout from './components/ExamLayout';
import ProtectedRoute from './components/ProtectedRoute';
import ExamPaperPage from './pages/ExamPaperPage/ExamPaperPage';
import RosterPage from './pages/RosterPage/RosterPage';
import RewardConfigPage from './pages/RewardConfigPage/RewardConfigPage';
import ExamPage from './pages/ExamPage/ExamPage';
import StatisticsPage from './pages/StatisticsPage/StatisticsPage';
import NotificationTemplatePage from './pages/NotificationTemplatePage/NotificationTemplatePage';
import NotFound from './pages/NotFound/NotFound';

const RoutesComponent = () => {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<ProtectedRoute><ExamPaperPage /></ProtectedRoute>} />
        <Route path="roster" element={<ProtectedRoute><RosterPage /></ProtectedRoute>} />
        <Route path="reward-config" element={<ProtectedRoute><RewardConfigPage /></ProtectedRoute>} />
        <Route path="notification-template" element={<ProtectedRoute><NotificationTemplatePage /></ProtectedRoute>} />
      </Route>
      <Route element={<ExamLayout />}>
        <Route path="exam" element={<ExamPage />} />
        <Route path="statistics" element={<ProtectedRoute requireAdmin={false}><StatisticsPage /></ProtectedRoute>} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default RoutesComponent;
